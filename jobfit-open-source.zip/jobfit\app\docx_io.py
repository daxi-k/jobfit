# -*- coding: utf-8 -*-
"""docx 读写：把简历解析成结构化档案，并按定制结果渲染 ATS 友好的一页简历。"""
import io
import math
import os
import re
import struct

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.shared import Emu

BULLET_CHARS = "▪•·●○◆◇■□▫◦‣–—*"

SECTION_ALIASES = {
    "education": ["教育背景", "教育经历", "教育", "学历背景"],
    "skills": ["专业技能", "技能特长", "技能", "专业能力", "技术栈", "技能清单", "技能证书", "个人技能"],
    "projects": ["项目经历", "项目经验", "主要项目", "科研经历", "项目", "科研项目"],
    "internships": ["实习经历", "工作经历", "实践经历", "实习", "工作"],
    "campus": ["校内实践", "校园经历", "社团经历", "学生工作", "校园实践", "社会实践"],
    "awards": ["荣誉奖项", "获奖情况", "奖项", "荣誉", "奖学金"],
    "certificates": ["证书", "认证", "资格证书", "语言能力", "技能证书"],
    "self": ["自我评价", "个人评价", "自我介绍", "个人总结", "自我描述"],
    "summary": ["个人简介", "职业概况", "个人概述"],
}
TITLES = {
    "education": "教育背景",
    "skills": "专业技能",
    "projects": "项目经历",
    "internships": "实习经历",
    "campus": "校内实践",
    "labs": "课程与实验",
    "awards": "荣誉奖项",
    "certificates": "证书与语言",
    "self": "自我评价",
    "summary": "个人概述",
}
EXACT = {alias: key for key, aliases in SECTION_ALIASES.items() for alias in aliases}
_ALIASES_SORTED = sorted(
    ((alias, key) for key, aliases in SECTION_ALIASES.items() for alias in aliases),
    key=lambda x: -len(x[0]),
)

PERIOD_RE = re.compile(
    r"((?:19|20)\d{2}\s*[./年]?\s*(?:0?[1-9]|1[0-2])?\s*月?"
    r"(?:\s*[–—\-~～至]+\s*(?:至今|现在|(?:19|20)\d{2}\s*[./年]?\s*(?:0?[1-9]|1[0-2])?\s*月?))?"
    r"|至今)"
)
PHONE_RE = re.compile(r"(?<!\d)(1[3-9]\d{9})(?!\d)")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
ROLE_WORDS = ("项目负责人", "负责人", "小组组长", "组长", "队长", "小组成员", "组员", "成员", "主要成员",
              "开发者", "设计者", "主导", "参与", "独立完成")


# ---------------------------------------------------------------- 读取

def _iter_blocks(doc):
    body = doc.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, doc)
        elif child.tag == qn("w:tbl"):
            yield Table(child, doc)


def read_docx_bytes(blob):
    """从内存里的 docx 提取纯文本（实验报告、课程清单用）。"""
    doc = Document(io.BytesIO(blob))
    lines = []
    for block in _iter_blocks(doc):
        if isinstance(block, Paragraph):
            if block.text.strip():
                lines.append(block.text.strip())
        else:
            for row in block.rows:
                cells = [" ".join(p.text.strip() for p in c.paragraphs if p.text.strip()) for c in row.cells]
                cells = [c for c in cells if c]
                if cells:
                    lines.append(" | ".join(cells))
    return "\n".join(lines)


def read_docx(path):
    doc = Document(path)
    paragraphs, tables = [], []
    for block in _iter_blocks(doc):
        if isinstance(block, Paragraph):
            text = block.text.strip()
            if text:
                style = block.style.name if block.style is not None else ""
                paragraphs.append({"text": text, "style": style})
        else:
            rows = []
            for row in block.rows:
                cells = [" ".join(p.text.strip() for p in c.paragraphs if p.text.strip()) for c in row.cells]
                rows.append(cells)
            if any(any(c for c in row) for row in rows):
                tables.append(rows)
    raw_lines = [p["text"] for p in paragraphs]
    for table in tables:
        for row in table:
            raw_lines.append(" | ".join(row))
    return {
        "paragraphs": paragraphs,
        "tables": tables,
        "raw_text": "\n".join(raw_lines),
        "inline_shapes": len(doc.inline_shapes),
    }


# ---------------------------------------------------------------- 解析

def _norm(text):
    return re.sub(r"\s+", "", text or "").strip("：:·|｜")


def match_section(line):
    key = _norm(line)
    if not key or len(key) > 14:
        return None
    if key in EXACT:
        return EXACT[key]
    for alias, sec in _ALIASES_SORTED:
        if len(alias) >= 3 and key == alias:
            return sec
    for alias, sec in _ALIASES_SORTED:
        if len(alias) >= 4 and key.startswith(alias) and len(key) <= len(alias) + 2:
            return sec
    return None


def _is_bullet(line):
    s = line.lstrip()
    return bool(s) and s[0] in BULLET_CHARS


def _clean_bullet(line):
    s = line.strip()
    while s and s[0] in BULLET_CHARS:
        s = s[1:].strip()
    return s


def _split_columns(line):
    parts = re.split(r"\t+|\s{2,}|｜|\|", line.strip())
    return [p.strip() for p in parts if p.strip()]


TODO_RE = re.compile(r"[（(]\s*(?:月份?|时间|日期)?待补\s*[)）]|[（(]\s*待定\s*[)）]|月份?待补")


def _strip_todo(text):
    return TODO_RE.sub("", text or "")


def _find_period(text):
    m = PERIOD_RE.search(text)
    if not m:
        return ""
    return re.sub(r"\s+", "", m.group(1))


def _period_span(text):
    """返回 (去掉时间段后的文本, 规整时间段)。"""
    clean = _strip_todo(text)
    m = PERIOD_RE.search(clean)
    if not m:
        return clean, ""
    period = re.sub(r"\s+", "", m.group(1))
    return (clean[:m.start()] + " " + clean[m.end():]).strip(), period


def _clean_period_text(text):
    """把 '2025（月份待补）' 这类脏数据转成可读文本。"""
    t = text.strip()
    t = re.sub(r"[（(]\s*月份?待补\s*[)）]", "", t)
    t = re.sub(r"[（(]\s*待定\s*[)）]", "", t)
    t = t.strip(" ·|｜\t")
    return t


def _split_header(line):
    """'标题   ｜ 角色\t时间' -> (title, role, period)。"""
    text = _strip_todo(line).strip()
    if "｜" in text:
        title, rest = text.split("｜", 1)
    elif "|" in text:
        title, rest = text.split("|", 1)
    else:
        stripped, period = _period_span(text)
        title, rest = stripped, period
    rest, period = _period_span(rest)
    role = re.sub(r"[\t·,，;；/]+", " ", rest).strip()
    role = re.sub(r"\s{2,}", " ", role).strip(" ·|｜-")
    title = re.sub(r"[\t]+", " ", title).strip(" ·|｜")
    return title.strip(), role, period


def _looks_like_entry(line):
    if _is_bullet(line) or not line.strip():
        return False
    if "｜" in line or "|" in line:
        return True
    if PERIOD_RE.search(line) and len(line) <= 90 and not line.rstrip().endswith("。"):
        return True
    return False


def _parse_entries(lines):
    entries, cur = [], None
    for line in lines:
        if _is_bullet(line):
            if cur is None:
                cur = {"title": "", "role": "", "period": "", "bullets": [], "tags": []}
            cur["bullets"].append(_clean_bullet(line))
            continue
        if _looks_like_entry(line):
            if cur:
                entries.append(cur)
            title, role, period = _split_header(line)
            cur = {"title": title, "role": role, "period": period, "bullets": [], "tags": []}
            continue
        if cur is None:
            stripped, period = _period_span(line)
            cur = {"title": stripped.strip(" ·|｜"), "role": "", "period": period, "bullets": [], "tags": []}
        else:
            # 续行：标题还没闭合时并入标题，否则并入条目正文
            if not cur["bullets"] and not cur["title"]:
                cur["title"] = line.strip()
            elif not cur["bullets"] and len(line) < 50 and not PERIOD_RE.search(line):
                cur["title"] = (cur["title"] + " " + line.strip()).strip()
            else:
                cur["bullets"].append(line.strip())
    if cur:
        entries.append(cur)
    # 清理空条目
    out = []
    for e in entries:
        e["title"] = re.sub(r"\s{2,}", " ", e["title"]).strip(" ·|｜")
        if e["title"] or e["bullets"]:
            out.append(e)
    return out


def _parse_education(lines):
    entries, cur = [], None
    for line in lines:
        if _is_bullet(line):
            line = _clean_bullet(line)
        stripped, period = _period_span(line)
        is_school = bool(re.search(r"(大学|学院|学校|研究院|University|College)", line))
        if is_school:
            if cur:
                entries.append(cur)
            cols = _split_columns(stripped)
            cur = {"school": cols[0] if cols else stripped.strip(), "major": "", "degree": "",
                   "period": period, "detail": "", "gpa": ""}
            if len(cols) > 1:
                cur["major"] = cols[1]
            continue
        if cur is None:
            cur = {"school": "", "major": "", "degree": "", "period": period, "detail": "", "gpa": ""}
        text = stripped.strip(" ·|｜")
        if not text:
            continue
        if re.search(r"GPA|绩点", text, re.I):
            cur["gpa"] = text
            continue
        # 「专业名（本科） · 主修课程：…」
        if re.search(r"主修课程|核心课程|相关课程", text):
            left, detail = re.split(r"[·|｜]?\s*(?:主修|核心|相关)课程[：:]?", text, maxsplit=1)
            _apply_edu_left(cur, left)
            cur["detail"] = detail.strip(" ：:；;")
            continue
        degree_m = re.search(r"[（(](本科|硕士|博士|专科|研究生|学士|在读)[)）]", text)
        if degree_m:
            cur["degree"] = degree_m.group(1)
            text = text.replace(degree_m.group(0), " ").strip()
        if not cur["major"] and re.search(r"(工程|科学|技术|管理|学|专业)$", text) and len(text) <= 24:
            cur["major"] = re.sub(r"^专业[：:]?", "", text).strip(" ·|｜")
            continue
        cur["detail"] = (cur["detail"] + "；" + text).strip("；") if cur["detail"] else text
    if cur:
        entries.append(cur)
    for e in entries:
        e["major"] = re.sub(r"[（(](本科|硕士|博士|专科)[)）]", "", e["major"]).strip(" ·|｜")
        e["major"] = re.sub(r"^专业[：:]\s*", "", e["major"]).strip()
    return [e for e in entries if e.get("school") or e.get("major")]


def _apply_edu_left(cur, left):
    left = left.strip(" ·|｜")
    degree_m = re.search(r"[（(](本科|硕士|博士|专科|研究生|学士|在读)[)）]", left)
    if degree_m:
        cur["degree"] = degree_m.group(1)
        left = left.replace(degree_m.group(0), " ").strip()
    left = re.sub(r"^专业[：:]\s*", "", left).strip(" ·|｜")
    if left and not cur["major"]:
        cur["major"] = left


def _parse_skills(lines):
    skills = []
    for line in lines:
        text = _clean_bullet(line)
        if not text:
            continue
        m = re.match(r"^([^：:]{2,12})[：:]\s*(.+)$", text)
        if m:
            skills.append({"label": m.group(1).strip(), "text": m.group(2).strip()})
        else:
            skills.append({"label": "技能", "text": text})
    return skills


def _extract_basics(paragraphs, raw_text):
    name, headline, objective = "", "", ""
    if paragraphs:
        first = paragraphs[0]["text"]
        cols = [c for c in re.split(r"\t+|\s{2,}", first.strip()) if c.strip()]
        if cols:
            cand = cols[0].replace(" ", "")
            if re.fullmatch(r"[\u4e00-\u9fa5·]{2,4}", cand):
                name = cand
                headline = " ".join(cols[1:]).strip()
            else:
                headline = first.strip()
    phone = PHONE_RE.search(raw_text)
    email = EMAIL_RE.search(raw_text)
    m = re.search(r"求职(?:方向|意向)[：: ]\s*([^\s｜|，,。]+(?:[ /、·]+[^\s｜|，,。]+)*)", raw_text)
    if m:
        objective = m.group(1).strip()
    grad = re.search(r"((?:19|20)\d{2})\s*届", raw_text)
    graduation = grad.group(1) if grad else ""
    location = ""
    m = re.search(r"(?:现居|所在地|城市)[：: ]\s*([\u4e00-\u9fa5]{2,8})", raw_text)
    if m:
        location = m.group(1)
    return {
        "name": name,
        "headline": headline,
        "phone": phone.group(1) if phone else "",
        "email": email.group(0) if email else "",
        "location": location,
        "objective": objective,
        "graduation": graduation,
    }


def parse_resume(blocks):
    paragraphs = blocks.get("paragraphs") or []
    texts = [p["text"] for p in paragraphs]
    headings = []
    for idx, text in enumerate(texts):
        key = match_section(text)
        if key:
            headings.append((idx, key))

    first_heading = headings[0][0] if headings else len(texts)
    pre = texts[:first_heading]
    raw_text = blocks.get("raw_text") or "\n".join(texts)

    basics = _extract_basics([{"text": t} for t in pre] or paragraphs, raw_text)
    if not basics["name"]:
        basics["name"] = ""
    if not basics["graduation"]:
        for p in paragraphs:
            m = re.search(r"((?:19|20)\d{2})\s*届", p["text"])
            if m:
                basics["graduation"] = m.group(1)
                break

    sections = {}
    for pos, (idx, key) in enumerate(headings):
        end = headings[pos + 1][0] if pos + 1 < len(headings) else len(texts)
        sections[key] = [t for t in texts[idx + 1:end] if t.strip()]

    education = _parse_education(sections.get("education", []))
    if not education:
        for line in pre:
            if re.search(r"(大学|学院|学校)", line):
                education = _parse_education([line])
                break
    skills = _parse_skills(sections.get("skills", []))
    projects = _parse_entries(sections.get("projects", []))
    internships = _parse_entries(sections.get("internships", []))
    campus = _parse_entries(sections.get("campus", []))
    awards = [{"text": _clean_bullet(t), "period": ""} for t in sections.get("awards", []) if _clean_bullet(t)]
    certificates = [{"text": _clean_bullet(t), "period": ""} for t in sections.get("certificates", []) if _clean_bullet(t)]
    self_eval = " ".join(t.strip() for t in sections.get("self", []) if t.strip())
    summary = " ".join(t.strip() for t in sections.get("summary", []) if t.strip())

    profile = dict(basics)
    if education:
        last = education[-1].get("period", "")
        m = re.search(r"((?:19|20)\d{2})[./年]?\s*(0?[1-9]|1[0-2])?\s*$", last.split("–")[-1].split("-")[-1])
        if m:
            year = m.group(1)
            profile["graduation"] = f"{year}.{int(m.group(2)):02d}" if m.group(2) else year
    profile.update({
        "headline": basics["headline"] or (basics["objective"] or "电子信息工程"),
        "links": re.findall(r"https?://[^\s｜|，,]+", raw_text)[:5],
        "education": education,
        "skills": skills,
        "internships": internships,
        "projects": projects,
        "campus": campus,
        "awards": awards,
        "certificates": certificates,
        "self_eval": self_eval or summary,
        "raw_text": raw_text,
        "source_file": "",
        "gaps": [],
    })
    profile["gaps"] = detect_gaps(profile)
    return profile


def detect_gaps(profile):
    gaps = []
    raw = profile.get("raw_text", "")
    if "待补" in raw or "待定" in raw or re.search(r"20\d{2}[^\d]{0,3}月?份待", raw):
        gaps.append({"level": "high", "text": "项目/实践时间缺月份，投递前建议补全（HR 对时间空档敏感）"})
    for group in ("projects", "internships", "campus"):
        for e in profile.get(group) or []:
            if not e.get("period"):
                gaps.append({"level": "mid", "text": f"「{e.get('title', '未命名')}」缺少起止时间"})
    if not profile.get("internships"):
        gaps.append({"level": "mid", "text": "暂无实习经历：校招可用「企业项目/竞赛/实验室经历」替代，并强化项目细节"})
    if not profile.get("awards") and not profile.get("certificates"):
        gaps.append({"level": "low", "text": "未填写荣誉/证书（奖学金、四六级、竞赛等都可以写）"})
    if not profile.get("skills"):
        gaps.append({"level": "high", "text": "没有技能条目，ATS 关键词匹配会吃亏"})
    if not profile.get("phone") or not profile.get("email"):
        gaps.append({"level": "high", "text": "联系方式不完整"})
    return gaps[:6]


# ---------------------------------------------------------------- 结构化 -> 渲染数据

def profile_to_resume(profile):
    return {
        "headline": profile.get("headline", ""),
        "summary": "",
        "education": [{k: e.get(k, "") for k in ("school", "major", "degree", "period", "detail", "gpa")}
                      for e in (profile.get("education") or [])],
        "skills": [dict(s) for s in (profile.get("skills") or [])],
        "internships": [_entry_for_render(e) for e in (profile.get("internships") or [])],
        "projects": [_entry_for_render(e) for e in (profile.get("projects") or [])],
        "campus": [_entry_for_render(e) for e in (profile.get("campus") or [])],
        "awards": [a.get("text", "") for a in (profile.get("awards") or []) if a.get("text")],
        "certificates": [c.get("text", "") for c in (profile.get("certificates") or []) if c.get("text")],
        "self_eval": profile.get("self_eval", ""),
    }


def _entry_for_render(e):
    meta_bits = [e.get("role", ""), e.get("period", "")]
    return {
        "title": e.get("title", ""),
        "meta": " · ".join([b for b in meta_bits if b]),
        "role": e.get("role", ""),
        "period": e.get("period", ""),
        "bullets": list(e.get("bullets") or []),
    }


# ---------------------------------------------------------------- 渲染 docx

DENSITY = {
    "normal": {"size": 10.0, "small": 9.5, "head": 10.5, "name": 19.0, "line": 1.3,
               "top": 1.5, "bottom": 1.4, "side": 1.9, "space": 1.0},
    "compact": {"size": 9.5, "small": 9.0, "head": 10.0, "name": 18.0, "line": 1.18,
                "top": 1.2, "bottom": 1.1, "side": 1.6, "space": 0.5},
}


def _set_run(run, size, bold=False, color=None, east="宋体", ascii_font="Times New Roman", spacing=None):
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), east)
    if ascii_font:
        rfonts.set(qn("w:ascii"), ascii_font)
        rfonts.set(qn("w:hAnsi"), ascii_font)
    if spacing:
        sp = OxmlElement("w:spacing")
        sp.set(qn("w:val"), str(spacing))
        rpr.append(sp)


def _spaced(text):
    chars = list(text)
    out = []
    for i, ch in enumerate(chars):
        out.append(ch)
        if i != len(chars) - 1:
            out.append(" ")
    return "".join(out)


def _bottom_border(paragraph, sz=6, color="444444"):
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(sz))
    bottom.set(qn("w:space"), "2")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)
    p_pr.insert_element_before(
        p_bdr, "w:shd", "w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap", "w:overflowPunct",
        "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN", "w:bidi", "w:adjustRightInd", "w:snapToGrid",
        "w:spacing", "w:ind", "w:contextualSpacing", "w:mirrorIndents", "w:suppressOverlap", "w:jc",
        "w:textDirection", "w:textAlignment", "w:textboxTightWrap", "w:outlineLvl", "w:divId",
        "w:cnfStyle", "w:rPr", "w:sectPr", "w:pPrChange",
    )


def _no_borders(table):
    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement("w:" + edge)
        el.set(qn("w:val"), "none")
        el.set(qn("w:sz"), "0")
        el.set(qn("w:space"), "0")
        borders.append(el)
    tblPr.append(borders)
    mar = OxmlElement("w:tblCellMar")
    for side in ("top", "left", "bottom", "right"):
        el = OxmlElement("w:" + side)
        el.set(qn("w:w"), "0")
        el.set(qn("w:type"), "dxa")
        mar.append(el)
    tblPr.append(mar)
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")
    tblPr.append(layout)


def _image_size(path):
    """读图片像素宽高：优先 Pillow，其次 PNG/JPEG 文件头，最后按证件照 3:4 估。"""
    try:
        from PIL import Image
        with Image.open(path) as im:
            return int(im.size[0]), int(im.size[1])
    except Exception:
        pass
    try:
        with open(path, "rb") as fh:
            head = fh.read(32)
            if head[:8] == b"\x89PNG\r\n\x1a\n":
                w, h = struct.unpack(">II", head[16:24])
                return int(w), int(h)
            if head[:2] == b"\xff\xd8":
                data = head + fh.read(400000)
                i = 2
                while i + 9 < len(data):
                    if data[i] != 0xFF:
                        i += 1
                        continue
                    marker = data[i + 1]
                    if marker in (0xD8, 0xD9, 0x01) or 0xD0 <= marker <= 0xD7:
                        i += 2
                        continue
                    seg = struct.unpack(">H", data[i + 2:i + 4])[0]
                    if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                                  0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                        h, w = struct.unpack(">HH", data[i + 5:i + 9])
                        return int(w), int(h)
                    i += 2 + seg
    except Exception:
        pass
    return 300, 400


def _photo_path(profile):
    name = (profile.get("photo") or "").strip()
    if not name:
        return None
    try:
        import config
        path = os.path.join(config.UP_DIR, os.path.basename(name))
    except Exception:
        return None
    return path if os.path.exists(path) else None


def render_docx(profile, resume, out_path, density="normal"):
    cfg = DENSITY.get(density, DENSITY["normal"])
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin, sec.bottom_margin = Cm(cfg["top"]), Cm(cfg["bottom"])
    sec.left_margin = sec.right_margin = Cm(cfg["side"])
    usable = 21.0 - 2 * cfg["side"]

    normal = doc.styles["Normal"]
    normal.font.name = "宋体"
    normal.font.size = Pt(cfg["size"])
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), "宋体")

    def para(space_before=0, space_after=0, line=cfg["line"]):
        p = doc.add_paragraph()
        pf = p.paragraph_format
        pf.space_before = Pt(space_before)
        pf.space_after = Pt(space_after)
        pf.line_spacing = line
        return p

    # ---- 抬头（有证件照时：左文右照的无边框两栏，照片贴右页边）
    headline = (resume.get("headline") or profile.get("headline") or "").strip()

    contact = []
    if profile.get("phone"):
        contact.append(profile["phone"])
    if profile.get("email"):
        contact.append(profile["email"])
    intent = (resume.get("headline") or profile.get("objective") or "").strip()
    if intent:
        contact.append("求职意向 " + intent)
    if profile.get("location"):
        contact.append(profile["location"])
    for link in (profile.get("links") or [])[:2]:
        contact.append(link)

    def fill_header(container, first=None, name_size=None):
        p_name = first if first is not None else container.add_paragraph()
        pf = p_name.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(1.5)
        pf.line_spacing = cfg["line"]
        _set_run(p_name.add_run(profile.get("name") or ""), name_size or cfg["name"], bold=True,
                 color="111111", ascii_font="宋体", spacing=80)
        if headline:
            _set_run(p_name.add_run("    " + headline), cfg["head"] + 1, bold=False, color="333333",
                     ascii_font="宋体")
        p_c = container.add_paragraph()
        pf2 = p_c.paragraph_format
        pf2.space_before = Pt(0)
        pf2.space_after = Pt(0)
        pf2.line_spacing = cfg["line"]
        _set_run(p_c.add_run("  ｜  ".join(contact)), cfg["small"], color="444444")

    photo = _photo_path(profile)
    if photo:
        w_px, h_px = _image_size(photo)
        img_w = 2.2  # cm
        img_h = img_w * h_px / max(1, w_px)
        if img_h > 3.0:
            img_h = 3.0
            img_w = img_h * w_px / max(1, h_px)
        gap = 0.3
        left_w = usable - img_w - gap
        table = doc.add_table(rows=1, cols=2)
        table.autofit = False
        _no_borders(table)
        table.alignment = WD_TABLE_ALIGNMENT.RIGHT
        for idx, w in ((0, left_w), (1, img_w + gap)):
            table.columns[idx].width = Cm(w)
        cells = table.rows[0].cells
        cells[0].width = Cm(left_w)
        cells[1].width = Cm(img_w + gap)
        cells[0].vertical_alignment = WD_ALIGN_VERTICAL.TOP
        cells[1].vertical_alignment = WD_ALIGN_VERTICAL.TOP
        fill_header(cells[0], first=cells[0].paragraphs[0])
        p_photo = cells[1].paragraphs[0]
        p_photo.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_photo.paragraph_format.space_before = Pt(0)
        p_photo.paragraph_format.space_after = Pt(0)
        p_photo.paragraph_format.line_spacing = 1.0
        p_photo.add_run().add_picture(photo, width=Cm(img_w), height=Cm(img_h))
    else:
        fill_header(doc)

    rule = para(0, 3)
    rule.paragraph_format.line_spacing = 0.6
    _set_run(rule.add_run(""), 1)
    _bottom_border(rule, sz=10, color="222222")

    # ---- 章节
    def heading(key):
        p = para(7 * cfg["space"] + 1, 2.5 * cfg["space"])
        p.paragraph_format.keep_with_next = True
        _set_run(p.add_run(_spaced(TITLES[key])), cfg["head"], bold=True, color="111111", spacing=30,
                 ascii_font="宋体")
        _bottom_border(p, sz=6, color="666666")
        return p

    def entry(title, role="", period="", meta=""):
        p = para(2 * cfg["space"], 1, cfg["line"])
        p.paragraph_format.keep_with_next = True
        p.paragraph_format.tab_stops.add_tab_stop(Cm(usable), WD_TAB_ALIGNMENT.RIGHT)
        _set_run(p.add_run(title or ""), cfg["size"] + 0.5, bold=True, color="111111")
        tail = role or ""
        if meta and not tail:
            tail = meta
        if tail:
            _set_run(p.add_run("  ｜ " + tail), cfg["size"] - 0.5, color="333333")
        if period:
            _set_run(p.add_run("\t" + fmt_period(period)), cfg["small"], color="555555")
        return p

    def bullet(text):
        p = para(0.6 * cfg["space"], 0.6 * cfg["space"], cfg["line"])
        pf = p.paragraph_format
        pf.left_indent = Cm(0.44)
        pf.first_line_indent = Cm(-0.44)
        _set_run(p.add_run("▪ "), cfg["size"], color="333333")
        _set_run(p.add_run(text), cfg["size"], color="1a1a1a")
        return p

    def body(text, indent=False):
        p = para(0.5, 0.5, cfg["line"])
        if indent:
            p.paragraph_format.first_line_indent = Cm(0.0)
        _set_run(p.add_run(text), cfg["size"], color="1a1a1a")
        return p

    summary = (resume.get("summary") or "").strip()
    if summary:
        heading("summary")
        body(summary)

    education = resume.get("education") or []
    if education:
        heading("education")
        for e in education:
            p = para(1.5, 0.5)
            p.paragraph_format.tab_stops.add_tab_stop(Cm(usable), WD_TAB_ALIGNMENT.RIGHT)
            school = e.get("school") or ""
            _set_run(p.add_run(school), cfg["size"] + 0.5, bold=True)
            major_bits = [b for b in (e.get("major"), e.get("degree")) if b]
            if major_bits:
                _set_run(p.add_run("  " + " · ".join(major_bits)), cfg["size"])
            if e.get("period"):
                _set_run(p.add_run("\t" + fmt_period(e["period"])), cfg["small"], color="555555")
            if e.get("detail"):
                p2 = para(0, 0.5)
                _set_run(p2.add_run("主修课程：" + e["detail"]), cfg["small"], color="333333")
            if e.get("gpa"):
                p3 = para(0, 0.5)
                _set_run(p3.add_run(e["gpa"]), cfg["small"], color="333333")

    skills = resume.get("skills") or []
    if skills:
        heading("skills")
        for s in skills:
            p = para(0.6, 0.6)
            pf = p.paragraph_format
            pf.left_indent = Cm(0.44)
            pf.first_line_indent = Cm(-0.44)
            _set_run(p.add_run("▪ "), cfg["size"])
            if s.get("label"):
                _set_run(p.add_run(s["label"] + "："), cfg["size"], bold=True)
            _set_run(p.add_run(s.get("text", "")), cfg["size"])

    for group, key in (("internships", "internships"), ("projects", "projects"), ("campus", "campus")):
        items = [i for i in (resume.get(group) or []) if i.get("title") or i.get("bullets")]
        if not items:
            continue
        heading(key)
        for e in items:
            entry(e.get("title", ""), e.get("role", ""), e.get("period", ""), e.get("meta", ""))
            for b in e.get("bullets") or []:
                bullet(b)

    labs = [e for e in (resume.get("labs") or []) if e.get("title") or e.get("bullets")]
    courses = [c for c in (resume.get("courses") or []) if c]
    if labs or courses:
        heading("labs")
        if courses:
            p = para(0.8, 0.8)
            _set_run(p.add_run("相关课程："), cfg["size"], bold=True)
            _set_run(p.add_run("、".join(courses)), cfg["size"])
        for e in labs:
            entry(e.get("title", ""), e.get("course", ""))
            for b in e.get("bullets") or []:
                bullet(b)

    awards = [a for a in (resume.get("awards") or []) if a]
    if awards:
        heading("awards")
        for a in awards:
            p = para(0.5, 0.5)
            pf = p.paragraph_format
            pf.left_indent = Cm(0.44)
            pf.first_line_indent = Cm(-0.44)
            _set_run(p.add_run("▪ "), cfg["size"])
            _set_run(p.add_run(a if isinstance(a, str) else a.get("text", "")), cfg["size"])

    certs = [c for c in (resume.get("certificates") or []) if c]
    if certs:
        heading("certificates")
        p = para(0.5, 0.5)
        _set_run(p.add_run("；".join(c if isinstance(c, str) else c.get("text", "") for c in certs)), cfg["size"])

    self_eval = (resume.get("self_eval") or "").strip()
    if self_eval:
        heading("self")
        body(self_eval)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    doc.save(out_path)
    info = estimate_pages(out_path, density)
    info["path"] = out_path
    info["size_kb"] = round(os.path.getsize(out_path) / 1024, 1)
    return info


# ---------------------------------------------------------------- 页数估算

def _text_units(text, size):
    units = 0.0
    for ch in text or "":
        units += 2.0 if ord(ch) > 0x2E80 else 1.0
    return units * (10.0 / max(size, 1))


def estimate_pages(docx_path, density="normal"):
    cfg = DENSITY.get(density, DENSITY["normal"])
    doc = Document(docx_path)
    usable_width = 21.0 - 2 * cfg["side"]
    usable_height_pt = (29.7 - cfg["top"] - cfg["bottom"]) / 2.54 * 72.0
    units_per_line = usable_width / (0.3528 * 10.0 / 10.0) / 2.0 * 2.0  # 10pt 一个汉字宽 0.3528cm
    units_per_line = usable_width / 0.1764  # 单位宽 = 半个汉字
    total_height, chars, bullets = 0.0, 0, 0
    for p in doc.paragraphs:
        text = p.text or ""
        if not text.strip():
            total_height += 6.0
            continue
        chars += len(text)
        if text.lstrip().startswith("▪"):
            bullets += 1
        size = cfg["size"]
        if p.runs:
            sizes = [r.font.size.pt for r in p.runs if r.font.size]
            if sizes:
                size = max(sizes)
        lines = max(1, math.ceil(_text_units(text, size) / units_per_line))
        total_height += lines * (size * 1.32) + 8.0
    # 证件照按实际高度占版面（表格里的文字不进 doc.paragraphs，这里也不重复计）
    for shape in doc.inline_shapes:
        total_height += shape.height.pt + 4.0
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                chars += len(cell.text or "")
    pages = total_height / usable_height_pt
    return {
        "pages": round(pages, 2),
        "chars": chars,
        "bullets": bullets,
        "density": density,
    }


def safe_filename(text, fallback="resume"):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', "-", text or "").strip(" -")
    s = re.sub(r"\s{2,}", " ", s)
    return (s or fallback)[:70]


def fmt_period(text):
    """统一时间段的排版：2023.09 – 2027.06 / 2024 – 至今。"""
    t = (text or "").strip()
    if not t:
        return ""
    t = re.sub(r"\s*[–—]\s*", " – ", t)
    t = re.sub(r"\s*-\s*(?=(?:19|20)\d{2}|至今)", " – ", t)
    return t