'use strict';

/* ============================================================
   简历工坊 JobFit — 前端（无框架，单文件）
   ============================================================ */

const S = {
  state: null,
  editProfile: null,
  currentJobId: '',
  currentRun: null,
  editing: false,
  dirtyResume: false,
  busyTimer: null,
  busyTick: null,
  renderToken: 0,
  gaps: { jobId: '', data: null, checks: {} },
};

const STATUSES = ['待投', '已投递', '已查看', '笔试', '面试', 'Offer', '已拒', '已归档'];
const STATUS_CLASS = {
  '待投': 'line', '已投递': 'info', '已查看': 'info', '笔试': 'warn',
  '面试': 'warn', 'Offer': 'ok', '已拒': 'danger', '已归档': 'line',
};
const SOURCES = ['Boss直聘', '实习僧', '牛客', '51job', '智联招聘', '猎聘', '公司官网', '其他'];

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clone = (o) => JSON.parse(JSON.stringify(o ?? null));
const nz = (v) => (v === undefined || v === null ? '' : v);

function toast(msg, type = 'ok') {
  const el = document.createElement('div');
  el.className = 'toast ' + (type === 'err' ? 'err' : 'ok');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(6px)'; el.style.transition = 'all .2s'; }, 2600);
  setTimeout(() => el.remove(), 2900);
}

async function api(path, opts = {}) {
  const init = { method: opts.method || 'GET', headers: {} };
  if (opts.body !== undefined) {
    init.headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(opts.body);
  }
  let res;
  try {
    res = await fetch(path, init);
  } catch (e) {
    markOffline();
    throw new Error('连不上本地服务。请确认「简历工坊」窗口还开着（双击 run.bat），然后刷新页面。');
  }
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { error: text }; }
  if (!res.ok) throw new Error(data.error || `请求失败（HTTP ${res.status}）`);
  markOnline();
  return data;
}

function markOffline() {
  const bar = $('#offline-bar');
  if (bar) bar.hidden = false;
}
function markOnline() {
  const bar = $('#offline-bar');
  if (bar && !bar.hidden) bar.hidden = true;
}

function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts * 1000);
  return `${d.getMonth() + 1}月${d.getDate()}日`;
}
function fmtDateTime(ts) {
  if (!ts) return '';
  const d = new Date(ts * 1000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
function greeting() {
  const h = new Date().getHours();
  if (h < 6) return '凌晨好';
  if (h < 12) return '上午好';
  if (h < 14) return '中午好';
  if (h < 18) return '下午好';
  return '晚上好';
}
function scoreClass(n) {
  if (n >= 85) return 'ok';
  if (n >= 70) return 'warn';
  return 'danger';
}
function scoreText(n) {
  if (n >= 85) return '匹配度很好，可以直接投';
  if (n >= 70) return '小修后就可以投';
  if (n >= 55) return '还有明显短板，先补关键词';
  return '差距较大，建议换更匹配的岗位';
}
function initials(name) { return (name || '简').trim().slice(0, 1); }
function setPath(obj, path, value) {
  const parts = String(path).split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i];
    const next = parts[i + 1];
    if (cur[k] === undefined || cur[k] === null) cur[k] = /^\d+$/.test(next) ? [] : {};
    cur = cur[k];
  }
  cur[parts[parts.length - 1]] = value;
}
function getPath(obj, path) {
  return String(path).split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

/* ============================================================
   启动 / 路由
   ============================================================ */

async function loadState() {
  S.state = await api('/api/state');
}

function routeInfo() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [name, qs] = raw.split('?');
  const params = new URLSearchParams(qs || '');
  return { name: name || 'dashboard', params };
}

function setActive(name) {
  $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.route === name));
}

async function boot() {
  $('#view').innerHTML = `<div class="empty"><div class="busy-ring"></div><p>正在加载…</p></div>`;
  try {
    await loadState();
  } catch (e) {
    markOffline();
    $('#view').innerHTML = `<div class="card"><div class="card-body">
      <h2>服务没连上</h2>
      <p class="muted" style="margin-top:8px">${esc(e.message)}</p>
      <ol class="small muted" style="margin:12px 0 0 18px;line-height:2">
        <li>回到项目文件夹，双击 <span class="mono">run.bat</span>（macOS / Linux 用 <span class="mono">./run.sh</span>），保持那个窗口开着</li>
        <li>窗口里会打印「地址：http://127.0.0.1:8765/」，用这个地址打开</li>
        <li>如果窗口一闪而过，多半是没装 Python 或 <span class="mono">python-docx</span>，窗口里会给出要执行的命令</li>
      </ol>
      <div class="row" style="margin-top:14px"><button class="btn primary" data-action="reload-page">重新连接</button></div>
    </div></div>`;
    return;
  }
  render();
}

function render() {
  const { name, params } = routeInfo();
  setActive(name);
  if (name === 'dashboard') viewDashboard();
  else if (name === 'profile') viewProfile();
  else if (name === 'jobs') viewJobs();
  else if (name === 'tailor') viewTailor(params);
  else if (name === 'materials') viewMaterials();
  else if (name === 'gaps') viewGaps(params);
  else if (name === 'tracker') viewTracker();
  else if (name === 'settings') viewSettings();
  else viewDashboard();
}

window.addEventListener('hashchange', () => { if (!$('#modal').hidden) closeModal(); render(); });

/* ============================================================
   概览
   ============================================================ */

function statCard(k, v, suffix = '') {
  return `<div class="stat"><div class="k">${esc(k)}</div><div class="v">${esc(v)}${suffix ? `<small>${esc(suffix)}</small>` : ''}</div></div>`;
}

function viewDashboard() {
  const st = S.state;
  const p = st.profile;
  if (!p) return dashboardEmpty();
  const stats = st.stats || {};
  const apps = st.applications || [];
  const interviews = apps.filter((a) => ['笔试', '面试'].includes(a.status)).length;
  const runs = (st.runs || []).slice(0, 6);
  const suggestions = buildSuggestions();

  $('#view').innerHTML = `
    <div class="page-head">
      <div>
        <h1>${greeting()}，${esc(p.name || '同学')}</h1>
        <p class="sub">${esc(p.headline || '')}${p.graduation ? ' · ' + esc(String(p.graduation).slice(0, 4)) + ' 届' : ''}${p.education && p.education[0] ? ' · ' + esc(p.education[0].school || '') : ''}</p>
      </div>
      <div class="head-actions">
        <button class="btn" data-action="import-resume">重新导入简历</button>
        <button class="btn primary" data-action="add-job">添加岗位</button>
      </div>
    </div>

    <div class="grid-4">
      ${statCard('岗位库', stats.jobs || 0)}
      ${statCard('已投递', stats.applications || 0)}
      ${statCard('笔试 / 面试', interviews)}
      ${statCard('平均匹配度', stats.avg_score || '—', stats.avg_score ? '分' : '')}
    </div>

    <div class="grid-2" style="margin-top:18px">
      <div class="card">
        <div class="card-head"><h2>接下来做什么</h2><span class="hint">按收益排序</span></div>
        <div class="card-body">
          ${suggestions.length ? `<div class="stack">${suggestions.map((s) => `
            <div class="spread" style="gap:14px;align-items:flex-start">
              <div style="min-width:0">
                <div style="font-weight:600;font-size:13.5px">${esc(s.title)}</div>
                <div class="muted small" style="margin-top:2px">${esc(s.desc)}</div>
              </div>
              <button class="btn sm" data-action="${s.action}" ${s.id ? `data-id="${esc(s.id)}"` : ''}>${esc(s.label)}</button>
            </div>`).join('<div class="divider" style="margin:2px 0"></div>')}</div>`
        : `<p class="muted small">档案和岗位都很完整了，直接去投吧。</p>`}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h2>最近定制</h2><a class="btn ghost sm" href="#/tailor">去定制</a></div>
        <div class="card-body tight">
          ${runs.length ? runs.map((r) => {
            const job = (st.jobs || []).find((j) => j.id === r.job_id) || {};
            return `<div class="spread" style="padding:9px 0;border-bottom:1px solid var(--line-2)">
              <div style="min-width:0">
                <div style="font-size:13px;font-weight:550" class="truncate">${esc(job.title || r.headline || '未命名岗位')}</div>
                <div class="muted small">${esc(job.company || '')} · ${fmtDate(r.created_at)}</div>
              </div>
              <div class="row" style="gap:8px">
                <span class="pill ${scoreClass(r.score)}">${r.score ?? '—'} 分</span>
                <a class="btn sm ghost" href="/api/runs/${r.id}/download">下载</a>
              </div>
            </div>`;
          }).join('') : `<p class="muted small" style="padding:8px 0">还没有生成过定制简历。</p>`}
        </div>
      </div>
    </div>

    <div class="card" style="margin-top:18px">
      <div class="card-head"><h2>档案提示</h2><a class="btn ghost sm" href="#/profile">编辑档案</a></div>
      <div class="card-body">
        ${(p.gaps && p.gaps.length) ? `<div class="gap-list">${p.gaps.map((g) => `
          <div class="gap-item ${esc(g.level)}"><span class="dot"></span><span>${esc(g.text)}</span></div>`).join('')}</div>`
        : `<p class="muted small">档案没有明显缺口。</p>`}
      </div>
    </div>`;
}

function dashboardEmpty() {
  $('#view').innerHTML = `
    <div class="page-head">
      <div>
        <h1>简历工坊</h1>
        <p class="sub">导入一次简历，之后每个岗位都能生成一版针对性的投递材料。</p>
      </div>
    </div>
    <div class="card"><div class="card-body">
      <div class="dropzone" id="dropzone" data-action="import-resume">
        <div class="dz-ico">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5"/><path d="M4 16.5V19a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 20 19v-2.5"/></svg>
        </div>
        <h3>把你的简历 docx 拖进来</h3>
        <p>支持 .docx；只在本机解析，不上传任何服务器</p>
      </div>
      <div class="row" style="justify-content:center;margin-top:16px">
        <button class="btn" data-action="new-blank">没有 docx？从空白档案开始</button>
      </div>
      <div class="stack" style="margin-top:26px;max-width:560px;margin-left:auto;margin-right:auto">
        <div class="spread"><span class="muted small">1 · 导入档案</span><span class="small">docx / 手动填写</span></div>
        <div class="spread"><span class="muted small">2 · 贴入岗位 JD</span><span class="small">Boss / 实习僧 / 官网都行</span></div>
        <div class="spread"><span class="muted small">3 · 生成定制简历</span><span class="small">改写 + 打分 + 防编造</span></div>
        <div class="spread"><span class="muted small">4 · 下载并投递</span><span class="small">投递包 + 状态追踪</span></div>
      </div>
    </div></div>`;
}

function buildSuggestions() {
  const out = [];
  const st = S.state;
  const p = st.profile;
  if (!st.settings.has_key) {
    out.push({ title: '配置 DeepSeek API Key', desc: '现在只能用离线排序；配上 Key 才会按岗位真正改写措辞', action: 'go-settings', label: '去设置' });
  }
  (p.gaps || []).slice(0, 2).forEach((g) => out.push({ title: g.text, desc: '档案补全后，所有岗位的定制质量都会提高', action: 'go-profile', label: '补全' }));
  const jobsNoRun = (st.jobs || []).filter((j) => !(st.runs || []).some((r) => r.job_id === j.id));
  jobsNoRun.slice(0, 2).forEach((j) => out.push({
    title: `为「${j.title || '未命名岗位'}」生成定制简历`,
    desc: j.company ? `${j.company} · 已入库但还没生成过简历` : '已入库但还没生成过简历',
    action: 'tailor-job', id: j.id, label: '生成',
  }));
  if (!out.length) out.push({ title: '继续加岗位', desc: '把今天看到的 JD 都存进来，集中处理效率更高', action: 'add-job', label: '添加岗位' });
  return out.slice(0, 4);
}

/* ============================================================
   档案
   ============================================================ */

function viewProfile() {
  const p = S.state.profile;
  if (!p) {
    $('#view').innerHTML = `
      <div class="page-head"><div><h1>我的档案</h1><p class="sub">简历只解析一次，之后所有岗位共用这份事实库。</p></div></div>
      <div class="card"><div class="card-body">
        <div class="dropzone" id="dropzone" data-action="import-resume">
          <div class="dz-ico"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5"/><path d="M4 16.5V19a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 20 19v-2.5"/></svg></div>
          <h3>拖入或点击选择简历 docx</h3>
          <p>${S.state.settings.has_key ? '会用大模型做结构化解析，30 秒左右' : '当前是规则解析；配置 API Key 后可智能解析'}</p>
        </div>
        <div class="row" style="margin-top:14px">
          <button class="btn" data-action="new-blank">从空白档案开始</button>
          <span class="muted small">旧版 .doc 请先在 Word 里另存为 .docx</span>
        </div>
      </div></div>`;
    return;
  }
  if (!S.editProfile) S.editProfile = clone(p);
  const d = S.editProfile;
  const edu = d.education || [];
  const skills = d.skills || [];
  const projects = d.projects || [];
  const internships = d.internships || [];
  const campus = d.campus || [];
  const awards = (d.awards || []).map((a) => (typeof a === 'string' ? a : a.text || '')).filter(Boolean);
  const certs = (d.certificates || []).map((c) => (typeof c === 'string' ? c : c.text || '')).filter(Boolean);

  const field = (label, path, value, ph = '') =>
    `<label class="field"><span>${esc(label)}</span><input type="text" data-path="${path}" value="${esc(value)}" placeholder="${esc(ph)}"></label>`;
  const area = (label, path, value, rows = 3, type = '') =>
    `<label class="field"><span>${esc(label)}</span><textarea rows="${rows}" data-path="${path}" ${type ? `data-type="${type}"` : ''} placeholder="">${esc(value)}</textarea></label>`;

  const entryCards = (group, items, titleText) => `
    ${items.map((e, i) => `
      <div class="entry-card">
        <div class="entry-head">
          <b>${esc(titleText)} ${i + 1}</b>
          <button class="icon-btn" data-action="del-entry" data-group="${group}" data-index="${i}" title="删除">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 7h14M9 7V5h6v2M8 7l1 13h6l1-13"/></svg>
          </button>
        </div>
        <div class="entry-fields">
          ${field('标题 / 项目名', `${group}.${i}.title`, e.title)}
          ${field('角色', `${group}.${i}.role`, e.role)}
          ${field('时间', `${group}.${i}.period`, e.period, '2025.03 – 2025.06')}
        </div>
        <div style="margin-top:10px">
          ${area('要点（一行一条）', `${group}.${i}.bullets`, (e.bullets || []).join('\n'), 4, 'bullets')}
        </div>
      </div>`).join('')}
    <button class="btn sm" data-action="add-entry" data-group="${group}" style="margin-top:10px">+ 添加${esc(titleText)}</button>`;

  $('#view').innerHTML = `
    <div class="page-head">
      <div><h1>我的档案</h1><p class="sub">这是所有定制简历的唯一事实来源；改这里，所有岗位都会跟着更新。</p></div>
      <div class="head-actions">
        <button class="btn" data-action="import-resume">重新导入 docx</button>
        <button class="btn primary" data-action="save-profile">保存修改</button>
      </div>
    </div>

    <div class="card">
      <div class="card-body" style="display:flex;gap:18px;align-items:flex-start">
        <div class="avatar-box">
          ${d.photo
            ? `<img class="avatar-img" src="/api/profile/photo?v=${encodeURIComponent(d.photo)}" alt="人像照">`
            : `<div class="avatar-fallback" style="width:54px;height:54px;border-radius:16px;background:var(--ink);color:#fff;display:grid;place-items:center;font-size:22px;font-family:serif">${esc(initials(d.name))}</div>`}
          <div class="avatar-actions">
            <button class="btn sm" data-action="pick-photo">${d.photo ? '更换' : '上传人像照'}</button>
            ${d.photo ? '<button class="btn sm" data-action="del-photo">删除</button>' : ''}
          </div>
        </div>
        <input type="file" id="photo-input" accept="image/png,image/jpeg" hidden>
        <div style="flex:1;min-width:0">
          <div class="row" style="gap:10px">
            <h2 style="font-size:18px">${esc(d.name || '未命名')}</h2>
            <span class="pill">${esc(d.headline || '未填求职方向')}</span>
          </div>
          <div class="muted small" style="margin-top:6px">
            ${[d.phone, d.email, d.graduation ? d.graduation + ' 毕业' : '', d.location].filter(Boolean).map(esc).join('　·　') || '联系方式还没填'}
          </div>
          ${d.source_file ? `<div class="faint small" style="margin-top:6px">来源：${esc(d.source_file)}</div>` : ''}
          <div class="faint small" style="margin-top:8px">
            ${d.photo ? '人像照会放在每份简历的右上角（约 2.2cm 宽，贴右页边）。' : '还没上传人像照：上传后会固定放在每份简历右上角；不上传也能正常生成。建议用正面免冠、纯色背景的证件照。'}
          </div>
        </div>
      </div>
    </div>

    ${(d.gaps && d.gaps.length) ? `<div class="card"><div class="card-head"><h2>档案缺口</h2><span class="hint">补全后匹配度会更高</span></div>
      <div class="card-body"><div class="gap-list">${d.gaps.map((g) => `<div class="gap-item ${esc(g.level)}"><span class="dot"></span><span>${esc(g.text)}</span></div>`).join('')}</div></div></div>` : ''}

    <form id="profile-form" onsubmit="return false">
      <div class="section-title"><h2>基本信息</h2><div class="line"></div></div>
      <div class="card"><div class="card-body">
        <div class="form-grid">
          ${field('姓名', 'name', d.name)}
          ${field('求职方向 / 标题', 'headline', d.headline, '硬件工程师 / FPGA 开发')}
          ${field('手机', 'phone', d.phone)}
          ${field('邮箱', 'email', d.email)}
          ${field('毕业时间', 'graduation', d.graduation, '2027.06')}
          ${field('现居城市', 'location', d.location)}
          <div class="full">${field('求职意向（投递表单会用）', 'objective', d.objective, '硬件工程师 / 硬件测试（实习 · 校招）')}</div>
          <div class="full">${area('自我评价', 'self_eval', d.self_eval, 4)}</div>
        </div>
      </div></div>

      <div class="section-title"><h2>教育背景</h2><div class="line"></div>
        <button class="btn sm" data-action="add-entry" data-group="education">+ 添加</button></div>
      ${edu.map((e, i) => `
        <div class="entry-card">
          <div class="entry-head"><b>教育经历 ${i + 1}</b>
            <button class="icon-btn" data-action="del-entry" data-group="education" data-index="${i}">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 7h14M9 7V5h6v2M8 7l1 13h6l1-13"/></svg>
            </button>
          </div>
          <div class="entry-fields">
            ${field('学校', `education.${i}.school`, e.school)}
            ${field('专业', `education.${i}.major`, e.major)}
            ${field('学历', `education.${i}.degree`, e.degree, '本科')}
          </div>
          <div class="form-grid" style="margin-top:10px">
            ${field('就读时间', `education.${i}.period`, e.period, '2023.09 – 2027.06')}
            ${field('GPA / 排名（可空）', `education.${i}.gpa`, e.gpa)}
            <div class="full">${area('主修课程', `education.${i}.detail`, e.detail, 2)}</div>
          </div>
        </div>`).join('') || `<div class="card"><div class="card-body muted small">还没有教育经历</div></div>`}

      <div class="section-title"><h2>专业技能</h2><div class="line"></div>
        <button class="btn sm" data-action="add-entry" data-group="skills">+ 添加</button></div>
      <div class="card"><div class="card-body stack">
        ${skills.map((s, i) => `
          <div class="entry-card">
            <div class="entry-head"><b>技能组 ${i + 1}</b>
              <button class="icon-btn" data-action="del-entry" data-group="skills" data-index="${i}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 7h14M9 7V5h6v2M8 7l1 13h6l1-13"/></svg>
              </button>
            </div>
            <div class="entry-fields" style="grid-template-columns:1fr 3fr">
              ${field('组名', `skills.${i}.label`, s.label, '硬件设计')}
              <div></div>
            </div>
            <div style="margin-top:10px">${area('内容', `skills.${i}.text`, s.text, 2)}</div>
          </div>`).join('') || `<p class="muted small">还没有技能条目</p>`}
      </div></div>

      <div class="section-title"><h2>项目经历</h2><div class="line"></div></div>
      ${entryCards('projects', projects, '项目')}

      <div class="section-title"><h2>实习经历</h2><div class="line"></div></div>
      ${entryCards('internships', internships, '实习')}

      <div class="section-title"><h2>校内实践</h2><div class="line"></div></div>
      ${entryCards('campus', campus, '实践')}

      <div class="grid-2" style="margin-top:26px">
        <div class="card"><div class="card-head"><h2>荣誉奖项</h2></div><div class="card-body">
          ${area('一行一条', 'awards', awards.join('\n'), 4, 'lines')}
        </div></div>
        <div class="card"><div class="card-head"><h2>证书 / 语言</h2></div><div class="card-body">
          ${area('一行一条', 'certificates', certs.join('\n'), 4, 'lines')}
        </div></div>
      </div>

      <div class="row" style="justify-content:flex-end;margin-top:18px">
        <span class="muted small" style="margin-right:auto">修改后记得保存；保存后建议重新生成各岗位简历。</span>
        <button class="btn primary" data-action="save-profile">保存修改</button>
      </div>
    </form>`;
}

function collectProfile() {
  const p = clone(S.editProfile);
  $$('[data-path]').forEach((el) => {
    const path = el.dataset.path;
    const type = el.dataset.type;
    if (type === 'bullets') {
      setPath(p, path, el.value.split('\n').map((s) => s.trim()).filter(Boolean));
    } else if (type === 'lines') {
      setPath(p, path, el.value.split('\n').map((s) => s.trim()).filter(Boolean).map((text) => ({ text, period: '' })));
    } else {
      setPath(p, path, el.value.trim());
    }
  });
  return p;
}

async function saveProfile() {
  const p = collectProfile();
  if (!p.name) { toast('姓名不能为空', 'err'); return; }
  try {
    const res = await api('/api/profile', { method: 'PUT', body: { profile: p } });
    S.editProfile = null;
    await loadState();
    toast('档案已保存');
    render();
  } catch (e) { toast(e.message, 'err'); }
}

/* ============================================================
   岗位库
   ============================================================ */

function viewJobs() {
  const jobs = S.state.jobs || [];
  const head = `
    <div class="page-head">
      <div><h1>岗位库</h1><p class="sub">把 JD 存进来，解析出关键词，再决定投不投。</p></div>
      <div class="head-actions">
        <input id="job-search" type="text" placeholder="搜索岗位 / 公司" style="width:200px">
        <button class="btn primary" data-action="add-job">+ 添加岗位</button>
      </div>
    </div>`;

  if (!jobs.length) {
    $('#view').innerHTML = head + `
      <div class="card"><div class="empty">
        <div class="ico">◇</div>
        <h3>还没有岗位</h3>
        <p>从 Boss、实习僧或公司官网复制岗位描述，粘进来即可。系统会解析出关键词、硬性要求和职责。</p>
        <button class="btn primary" data-action="add-job">添加第一个岗位</button>
      </div></div>`;
    return;
  }

  const rows = jobs.map((j) => {
    const kw = (j.parsed && j.parsed.keywords) || [];
    const hasRun = (S.state.runs || []).some((r) => r.job_id === j.id);
    return `<div class="job-card" data-job-card data-search="${esc(((j.title || '') + ' ' + (j.company || '') + ' ' + (j.jd_text || '')).toLowerCase())}">
      <div style="min-width:0">
        <div class="row" style="gap:8px">
          <span class="job-title truncate">${esc(j.title || '未命名岗位')}</span>
          <span class="pill ${STATUS_CLASS[j.status] || 'line'}">${esc(j.status || '待投')}</span>
          ${hasRun ? '<span class="chip hit">已生成简历</span>' : ''}
        </div>
        <div class="job-meta">
          <span>${esc(j.company || '公司未填')}</span>
          ${j.source ? `<span>${esc(j.source)}</span>` : ''}
          ${j.parsed && j.parsed.seniority ? `<span>${esc(j.parsed.seniority)}</span>` : ''}
          <span>${fmtDate(j.created_at)} 入库</span>
          ${j.url ? `<a href="${esc(j.url)}" target="_blank" rel="noopener" style="text-decoration:underline;text-underline-offset:2px">原岗位页</a>` : ''}
        </div>
        ${kw.length ? `<div class="chips" style="margin-top:10px">${kw.slice(0, 9).map((k) => `<span class="chip">${esc(k)}</span>`).join('')}</div>` : ''}
        <div class="jd-snippet">${esc((j.jd_text || '').replace(/\s+/g, ' ').slice(0, 160))}</div>
      </div>
      <div class="job-actions">
        <button class="btn sm" data-action="edit-job" data-id="${j.id}">编辑</button>
        <button class="btn sm" data-action="parse-job" data-id="${j.id}">解析 JD</button>
        <button class="btn sm primary" data-action="tailor-job" data-id="${j.id}">定制简历</button>
        <button class="btn sm" data-action="open-pack" data-id="${j.id}">投递包</button>
        <button class="btn sm danger" data-action="delete-job" data-id="${j.id}">删除</button>
      </div>
    </div>`;
  }).join('');

  $('#view').innerHTML = head + `<div class="card" id="job-list">${rows}</div>`;
  const search = $('#job-search');
  if (search) search.addEventListener('input', () => {
    const q = search.value.trim().toLowerCase();
    $$('[data-job-card]').forEach((el) => { el.style.display = !q || (el.dataset.search || '').includes(q) ? '' : 'none'; });
  });
}

function openJobModal(job) {
  const j = job || {};
  openModal(`
    <div class="modal-head">
      <div><h2>${job ? '编辑岗位' : '添加岗位'}</h2><p>粘入完整 JD，解析结果会用于关键词匹配与改写。</p></div>
      <button class="icon-btn" data-action="close-modal">✕</button>
    </div>
    <form id="job-form">
      <div class="modal-body">
        <div class="form-grid">
          <label class="field"><span>岗位名称</span><input type="text" name="title" value="${esc(j.title || '')}" placeholder="硬件测试实习生"></label>
          <label class="field"><span>公司</span><input type="text" name="company" value="${esc(j.company || '')}" placeholder="可空，解析后自动补"></label>
          <label class="field"><span>来源平台</span>
            <select name="source">${SOURCES.map((s) => `<option ${j.source === s ? 'selected' : ''}>${s}</option>`).join('')}</select>
          </label>
          <label class="field"><span>岗位链接</span><input type="url" name="url" value="${esc(j.url || '')}" placeholder="https://..."></label>
          <label class="field full"><span>JD 文本 <b>*</b></span>
            <textarea name="jd_text" rows="10" placeholder="把岗位职责、任职要求整段粘进来…">${esc(j.jd_text || '')}</textarea>
          </label>
        </div>
        <label class="row small muted" style="margin-top:12px;gap:8px">
          <input type="checkbox" name="autoparse" checked style="width:auto"> 保存后立即解析 JD（提取关键词与硬性要求）
        </label>
        ${!S.state.settings.has_key ? `<div class="sticky-note" style="margin-top:12px">没有配置 API Key 时使用规则解析，关键词提取会简单一些。</div>` : ''}
      </div>
      <div class="modal-foot">
        <button type="button" class="btn" data-action="close-modal">取消</button>
        <button type="submit" class="btn primary">${job ? '保存' : '添加并解析'}</button>
      </div>
    </form>`);

  $('#job-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = {
      title: (fd.get('title') || '').trim(),
      company: (fd.get('company') || '').trim(),
      source: fd.get('source') || '',
      url: (fd.get('url') || '').trim(),
      jd_text: (fd.get('jd_text') || '').trim(),
      autoparse: !!fd.get('autoparse'),
    };
    if (!body.jd_text) { toast('JD 不能为空', 'err'); return; }
    try {
      closeModal();
      showBusy('正在解析岗位…', ['提取硬性要求', '识别技术关键词', '判断岗位侧重']);
      if (job) {
        await api(`/api/jobs/${job.id}`, { method: 'PUT', body });
        if (body.autoparse) await api(`/api/jobs/${job.id}/parse`, { method: 'POST' });
      } else {
        await api('/api/jobs', { method: 'POST', body });
      }
      await loadState();
      hideBusy();
      toast(job ? '岗位已更新' : '岗位已添加');
      render();
    } catch (err) { hideBusy(); toast(err.message, 'err'); }
  });
}

/* ============================================================
   定制简历
   ============================================================ */

function viewTailor(params) {
  const jobs = S.state.jobs || [];
  const jobId = params.get('job') || S.currentJobId || (jobs[0] && jobs[0].id) || '';
  if (jobId) S.currentJobId = jobId;
  const job = jobs.find((j) => j.id === jobId) || null;

  if (!jobs.length) {
    $('#view').innerHTML = `
      <div class="page-head"><div><h1>定制简历</h1><p class="sub">先有岗位，才有「针对性」。</p></div></div>
      <div class="card"><div class="empty"><div class="ico">◇</div>
        <h3>岗位库是空的</h3><p>先去添加一个岗位 JD，再回来生成定制简历。</p>
        <button class="btn primary" data-action="add-job">添加岗位</button></div></div>`;
    return;
  }

  const select = `<select id="job-select" style="max-width:340px">${jobs.map((j) => `<option value="${j.id}" ${j.id === jobId ? 'selected' : ''}>${esc(j.title || '未命名')}${j.company ? ' · ' + esc(j.company) : ''}</option>`).join('')}</select>`;

  const options = `
    <div class="card">
      <div class="card-head"><h2>生成设置</h2><span class="hint">${S.state.settings.has_key && !S.state.settings.mock ? (S.state.settings.key_ok === false ? 'Key 无效，生成会退回离线' : '大模型改写模式') : '离线规则模式'}</span></div>
      <div class="card-body">
        <div class="form-grid">
          <label class="field"><span>目标岗位</span>${select}</label>
          <label class="field"><span>本次侧重（可选）</span><input type="text" id="focus-input" placeholder="偏硬件测试 / 突出 FPGA / 强调板级调试"></label>
          <label class="field"><span>排版密度</span>
            <select id="density-select"><option value="normal">标准（推荐）</option><option value="compact">紧凑（内容多时）</option></select>
          </label>
          <label class="field"><span>每段项目几条 bullet</span>
            <select id="bullets-select"><option value="3">3 条</option><option value="4" selected>4 条</option><option value="5">5 条</option></select>
          </label>
        </div>
        <div class="row" style="margin-top:14px">
          <button class="btn primary" data-action="generate" data-id="${job ? job.id : ''}" ${job ? '' : 'disabled'}>生成定制简历</button>
          ${!S.state.settings.has_key ? `<span class="muted small">未配置 Key：只做排序与模板化，不会改写措辞</span>` : ''}
        </div>
        ${job && job.parsed ? `<div class="divider"></div>
          <div class="muted small" style="margin-bottom:8px">岗位关键词</div>
          <div class="chips">${(job.parsed.keywords || []).map((k) => `<span class="chip">${esc(k)}</span>`).join('') || '<span class="muted small">还没解析</span>'}</div>` : ''}
      </div>
    </div>`;

  $('#view').innerHTML = `
    <div class="page-head">
      <div><h1>定制简历</h1><p class="sub">同一份档案，按岗位重排证据、重写措辞、标注短板。</p></div>
      <div class="head-actions"><button class="btn" data-action="add-job">+ 添加岗位</button></div>
    </div>
    ${options}
    <div id="tailor-result" style="margin-top:18px"></div>`;

  if (job && !(S.currentRun && S.currentRun.job && S.currentRun.job.id === job.id)) {
    const latest = (S.state.runs || []).find((r) => r.job_id === job.id);
    if (latest) loadRun(latest.id);
    else $('#tailor-result').innerHTML = emptyResult();
  } else if (S.currentRun) {
    renderTailorResult();
  } else {
    $('#tailor-result').innerHTML = emptyResult();
  }
}

function emptyResult() {
  return `<div class="card"><div class="empty"><div class="ico">✎</div>
    <h3>还没有生成</h3>
    <p>点上面的「生成定制简历」：会按 JD 重排项目、改写 bullet、计算匹配度，并导出一份 ATS 友好的 DOCX。</p>
  </div></div>`;
}

async function loadRun(runId) {
  try {
    const res = await api(`/api/runs/${runId}`);
    S.currentRun = res.run.payload;
    S.currentRun.run_id = runId;
    S.currentJobId = res.run.job_id;
    renderTailorResult();
  } catch (e) { toast(e.message, 'err'); }
}

async function generate(jobId) {
  if (!jobId) return;
  const focus = $('#focus-input') ? $('#focus-input').value.trim() : '';
  const density = $('#density-select') ? $('#density-select').value : 'normal';
  const maxBullets = $('#bullets-select') ? Number($('#bullets-select').value) : 4;
  showBusy('正在改写简历…', ['解析岗位要求', '重排项目与技能', '重写项目要点', '检查是否编造事实', '排版导出 DOCX']);
  try {
    const res = await api(`/api/jobs/${jobId}/tailor`, { method: 'POST', body: { focus, density, max_bullets: maxBullets } });
    S.currentRun = res.payload;
    S.currentRun.run_id = res.run_id;
    S.currentJobId = jobId;
    S.editing = false;
    S.dirtyResume = false;
    await loadState();
    hideBusy();
    render();
    toast(`已生成，匹配度 ${res.payload.score.total} 分`);
  } catch (e) {
    hideBusy();
    toast(e.message, 'err');
  }
}

function renderTailorResult() {
  const box = $('#tailor-result');
  if (!box || !S.currentRun) return;
  const run = S.currentRun;
  const r = run.resume;
  const score = run.score || {};
  const jd = run.jd || {};
  const p = S.state.profile;

  const ring = scoreRing(score.total || 0);
  const bars = [
    ['关键词覆盖', score.coverage?.ratio || 0, Math.round((score.coverage?.ratio || 0) * 100) + '%'],
    ['证据匹配', score.evidence?.ratio || 0, Math.round((score.evidence?.ratio || 0) * 100) + '%'],
    ['ATS 规范', score.ats?.ratio || 0, Math.round((score.ats?.ratio || 0) * 100) + '%'],
    ['量化程度', score.quality?.ratio || 0, Math.round((score.quality?.ratio || 0) * 100) + '%'],
  ].map(([k, v, label]) => `
    <div class="bar-row"><span>${esc(k)}</span><div class="bar"><i class="${v < 0.6 ? 'warn' : ''}" style="width:${Math.round(v * 100)}%"></i></div><span class="val">${label}</span></div>`).join('');

  const hit = (score.coverage && score.coverage.hit) || [];
  const miss = (score.coverage && score.coverage.missing) || [];

  box.innerHTML = `
    <div class="toolbar" style="margin-bottom:12px">
      <span class="pill ${run.mode === 'llm' ? 'info' : run.llm_error ? 'warn' : 'line'}">${run.mode === 'llm' ? '大模型改写' : run.llm_error ? '离线兜底' : '离线规则'}</span>
      <span class="muted small">${esc(run.generated_at || '')}</span>
      <span class="muted small">${run.docx ? `约 ${run.docx.pages} 页 · ${run.docx.chars} 字` : ''}</span>
      <div style="margin-left:auto" class="toolbar">
        <button class="btn sm" data-action="toggle-edit">${S.editing ? '完成编辑' : '编辑文字'}</button>
        <button class="btn sm ${S.dirtyResume ? 'accent' : ''}" data-action="save-resume" ${S.dirtyResume ? '' : 'disabled'}>保存并重新导出</button>
        <a class="btn sm" href="/api/runs/${run.run_id}/download">下载 DOCX</a>
        <button class="btn sm" data-action="open-pack" data-id="${esc(run.job.id)}">投递包</button>
        <button class="btn sm primary" data-action="mark-applied" data-id="${esc(run.job.id)}">标记已投递</button>
      </div>
    </div>

    ${run.llm_error ? `<div class="sticky-note" style="margin-bottom:12px;border-color:#f0c9a8;background:#fff7ef">
      <b>这次是离线兜底：</b>${esc(run.llm_error)} · <a href="#/settings" style="text-decoration:underline">检查 Key / 网络</a>
    </div>` : ''}

    <div class="score-layout">
      <div class="card">
        <div class="card-head"><h2>简历预览</h2><span class="hint">${esc(run.job.title || '')}${run.job.company ? ' · ' + esc(run.job.company) : ''}</span></div>
        <div class="card-body" style="background:#f3f3ee">
          <div class="paper" id="paper">${paperHTML(r, p, S.editing)}</div>
          ${S.editing ? `<p class="muted small" style="margin-top:10px">点击正文可编辑；数字改动会重新触发防编造检查。</p>` : ''}
        </div>
      </div>

      <div class="stack">
        <div class="card"><div class="card-body">
          <div class="ring-wrap">
            ${ring}
            <div class="ring-meta">
              <div class="t">${esc(scoreText(score.total || 0))}</div>
              <div class="d">${hit.length} 个关键词命中${miss.length ? `，${miss.length} 个缺失` : '，覆盖完整'}</div>
            </div>
          </div>
          <div class="bars">${bars}</div>
        </div></div>

        <div class="card"><div class="card-head"><h2>关键词</h2><span class="hint">绿色=已覆盖</span></div>
          <div class="card-body"><div class="chips">
            ${hit.map((k) => `<span class="chip hit">${esc(k)}</span>`).join('')}
            ${miss.map((k) => `<span class="chip miss">${esc(k)}</span>`).join('')}
            ${!hit.length && !miss.length ? '<span class="muted small">岗位还没有关键词，先解析 JD</span>' : ''}
          </div></div>
        </div>

        ${(run.warnings || []).length ? `<div class="card"><div class="card-head"><h2>防编造检查</h2><span class="hint">${run.warnings.length} 条待确认</span></div>
          <div class="card-body">${run.warnings.map((w) => `<div class="warn-item ${w.level === 'high' ? 'high' : ''}">
            <b>${w.type === 'number' ? '数据出处' : w.type === 'term' ? '新增术语' : w.type === 'project' ? '项目名' : w.type === 'school' ? '学校名' : '提醒'}</b>
            ${esc(w.detail || '')}${w.text ? `<div class="small" style="margin-top:4px;opacity:.85">${esc(w.text)}</div>` : ''}
          </div>`).join('')}</div></div>` : `<div class="card"><div class="card-body"><div class="check"><span class="m rounded ok">✓</span><div><div style="font-size:13px">没有发现编造</div><div class="d">数字与专有名词都能在档案里找到出处</div></div></div></div></div>`}

        ${(run.resume.gap_notes || []).length ? `<div class="card"><div class="card-head"><h2>岗位短板</h2></div>
          <div class="card-body stack">${run.resume.gap_notes.map((g) => `<div class="small" style="color:var(--warn)">· ${esc(g)}</div>`).join('')}</div></div>` : ''}

        <div class="card"><div class="card-head"><h2>ATS 检查</h2></div>
          <div class="card-body"><div class="checks">
            ${(score.ats?.checks || []).map((c) => `<div class="check">
              <span class="m ${c.ok ? 'ok' : 'no'}">${c.ok ? '✓' : '×'}</span>
              <div><div>${esc(c.name)}</div><div class="d">${esc(c.detail || '')}</div></div>
            </div>`).join('')}
          </div></div>
        </div>
      </div>
    </div>`;
}

function scoreRing(total) {
  const r = 44;
  const c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, total)) / 100;
  const color = total >= 85 ? '#1a7f4b' : total >= 70 ? '#0f6b5c' : total >= 55 ? '#b45309' : '#b42318';
  return `<div class="ring">
    <svg width="104" height="104">
      <circle cx="52" cy="52" r="${r}" fill="none" stroke="#eef0ea" stroke-width="8"/>
      <circle cx="52" cy="52" r="${r}" fill="none" stroke="${color}" stroke-width="8" stroke-linecap="round"
        stroke-dasharray="${c * pct} ${c}" />
    </svg>
    <span class="num">${total}<small>分</small></span>
  </div>`;
}

function fmtPeriod(t) {
  return String(t || '').trim().replace(/\s*[–—]\s*/g, ' – ').replace(/\s*-\s*(?=(19|20)\d{2}|至今)/g, ' – ');
}

function paperHTML(r, p, editable) {
  const ed = (path) => editable ? `class="editable" contenteditable="true" data-edit-path="${path}"` : '';
  const sec = (title) => `<div class="r-sec">${esc(title)}</div>`;
  const contact = [p.phone, p.email, '求职意向 ' + (r.headline || p.objective || ''), p.location].filter(Boolean);
  const edu = (r.education || []).map((e, i) => `
    <div class="r-entry">
      <span class="t">${esc(e.school || '')}</span>
      <span class="r">${esc([e.major, e.degree].filter(Boolean).join(' · '))}</span>
      <span class="p">${esc(fmtPeriod(e.period))}</span>
    </div>
    ${e.detail ? `<div class="r-line"><span class="r-label">主修课程：</span><span ${ed(`education.${i}.detail`)}>${esc(e.detail)}</span></div>` : ''}
    ${e.gpa ? `<div class="r-line">${esc(e.gpa)}</div>` : ''}`).join('');

  const skills = (r.skills || []).map((s, i) => {
    const badge = s.ai ? '<span class="skill-badge">AI</span>' : '';
    return `<div class="r-bullet"><span class="r-label">${esc(s.label || '技能')}：${badge}</span><span ${ed(`skills.${i}.text`)}>${esc(s.text || '')}</span></div>`;
  }).join('');

  const entryBlock = (group, label, items) => items && items.length ? sec(label) + items.map((e, i) => `
    <div class="r-entry">
      <span class="t">${esc(e.title || '')}</span>
      ${e.role ? `<span class="r">｜ ${esc(e.role)}</span>` : ''}
      <span class="p">${esc(fmtPeriod(e.period))}</span>
    </div>
    ${(e.bullets || []).map((b, j) => `<div class="r-bullet"><span ${ed(`${group}.${i}.bullets.${j}`)}>${esc(b)}</span></div>`).join('')}`).join('') : '';

  return `
    <div class="r-top">
      <div class="r-top-main">
        <div>
          <span class="r-name">${esc(p.name || '')}</span><span class="r-headline">${esc(r.headline || '')}</span>
        </div>
        <div class="r-contact">${contact.map(esc).join('　｜　')}</div>
      </div>
      ${p.photo ? `<img class="r-photo" src="/api/profile/photo?v=${encodeURIComponent(p.photo)}" alt="人像照">` : ''}
    </div>
    <hr class="r-rule">
    ${r.summary ? sec('个人概述') + `<div class="r-line"><span ${ed('summary')}>${esc(r.summary)}</span></div>` : ''}
    ${edu ? sec('教育背景') + edu : ''}
    ${skills ? sec('专业技能') + skills : ''}
    ${entryBlock('internships', '实习经历', r.internships)}
    ${entryBlock('projects', '项目经历', r.projects)}
    ${entryBlock('campus', '校内实践', r.campus)}
    ${(r.labs || []).length ? sec('课程与实验') + ((r.courses || []).length ? `<div class="r-line"><span class="r-label">相关课程：</span>${esc(r.courses.join('、'))}</div>` : '') + r.labs.map((e, i) => `
      <div class="r-entry">
        <span class="t">${esc(e.title || '')}</span>
        ${e.course ? `<span class="r">｜ ${esc(e.course)}</span>` : ''}
      </div>
      ${(e.bullets || []).map((b, j) => `<div class="r-bullet"><span ${ed(`labs.${i}.bullets.${j}`)}>${esc(b)}</span></div>`).join('')}`).join('') : ''}
    ${(r.awards || []).length ? sec('荣誉奖项') + r.awards.map((a) => `<div class="r-bullet">${esc(a)}</div>`).join('') : ''}
    ${(r.certificates || []).length ? sec('证书与语言') + `<div class="r-line">${r.certificates.map(esc).join('；')}</div>` : ''}
    ${r.self_eval ? sec('自我评价') + `<div class="r-line"><span ${ed('self_eval')}>${esc(r.self_eval)}</span></div>` : ''}`;
}

async function saveResumeEdits() {
  if (!S.currentRun || !S.dirtyResume) return;
  const runId = S.currentRun.run_id;
  const resume = clone(S.currentRun.resume);
  $$('[data-edit-path]').forEach((el) => {
    const path = el.dataset.editPath;
    if (path && path.includes('.x')) return;
    setPath(resume, path, el.innerText.trim());
  });
  showBusy('正在重新校验…', ['重算匹配度', '检查编造', '重新导出 DOCX']);
  try {
    const res = await api(`/api/runs/${runId}/update`, { method: 'POST', body: { resume } });
    S.currentRun = res.payload;
    S.currentRun.run_id = runId;
    S.dirtyResume = false;
    hideBusy();
    renderTailorResult();
    toast('已保存并重新导出');
  } catch (e) { hideBusy(); toast(e.message, 'err'); }
}

/* ============================================================
   投递包
   ============================================================ */

async function openPack(jobId) {
  if (!jobId) { toast('先选择一个岗位', 'err'); return; }
  showBusy('正在准备投递包…');
  try {
    const res = await api(`/api/jobs/${jobId}/pack`);
    hideBusy();
    const pack = res.pack;
    const all = packText(pack);
    const fieldsHtml = (pack.fields || []).map((g) => `
      <div class="copy-group">
        <h4>${esc(g.group)}</h4>
        ${g.items.map((it) => `<div class="kv">
          <span class="k">${esc(it.label)}</span>
          <span class="v">${it.value ? esc(it.value) : `<span class="faint">${esc(it.hint || '待填')}</span>`}</span>
          ${it.value ? `<button class="icon-btn" data-action="copy" data-copy="${esc(it.value)}" title="复制">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/></svg>
          </button>` : ''}
        </div>`).join('')}
      </div>`).join('');

    openModal(`
      <div class="modal-head">
        <div><h2>投递包 · ${esc(pack.job.title || '岗位')}</h2><p>${esc(pack.job.company || '')}${pack.score ? ' · 匹配度 ' + pack.score + ' 分' : ''}</p></div>
        <button class="icon-btn" data-action="close-modal">✕</button>
      </div>
      <div class="modal-body">
        <div class="toolbar" style="margin-bottom:14px">
          <button class="btn sm primary" data-action="copy" data-copy="${esc(all)}">复制全部信息</button>
          ${pack.run_id ? `<a class="btn sm" href="/api/runs/${pack.run_id}/download">下载定制简历</a>` : ''}
          ${pack.job.url ? `<a class="btn sm" href="${esc(pack.job.url)}" target="_blank" rel="noopener">打开岗位页</a>` : ''}
        </div>
        ${fieldsHtml}
        ${pack.greeting ? `<div class="copy-group"><h4>开场白（招聘平台）</h4>
          <div class="letter">${esc(pack.greeting)}</div>
          <div class="row" style="margin-top:8px"><button class="btn sm" data-action="copy" data-copy="${esc(pack.greeting)}">复制</button></div>
        </div>` : ''}
        ${pack.cover_letter ? `<div class="copy-group"><h4>求职信</h4>
          <div class="letter">${esc(pack.cover_letter)}</div>
          <div class="row" style="margin-top:8px"><button class="btn sm" data-action="copy" data-copy="${esc(pack.cover_letter)}">复制</button></div>
        </div>` : ''}
        <div class="copy-group"><h4>这个平台的投递要点</h4>
          <div class="stack">${(pack.tips || []).map((t) => `<div class="small muted">· ${esc(t)}</div>`).join('')}</div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn" data-action="close-modal">关闭</button>
        <button class="btn primary" data-action="mark-applied" data-id="${esc(pack.job.id)}">标记已投递</button>
      </div>`, { wide: true });
  } catch (e) { hideBusy(); toast(e.message, 'err'); }
}

function packText(pack) {
  const lines = [`【应聘】${pack.job.company || ''} · ${pack.job.title || ''}`, ''];
  (pack.fields || []).forEach((g) => {
    lines.push(`— ${g.group} —`);
    g.items.forEach((it) => { if (it.value) lines.push(`${it.label}：${it.value}`); });
    lines.push('');
  });
  if (pack.greeting) lines.push('【开场白】', pack.greeting, '');
  if (pack.cover_letter) lines.push('【求职信】', pack.cover_letter);
  return lines.join('\n');
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('已复制');
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('已复制'); } catch (err) { toast('浏览器不允许复制，请手动选中', 'err'); }
    ta.remove();
  }
}

/* ============================================================
   投递追踪
   ============================================================ */

function viewTracker() {
  const apps = S.state.applications || [];
  const jobs = S.state.jobs || [];
  const jobMap = Object.fromEntries(jobs.map((j) => [j.id, j]));
  const rows = apps.map((a) => {
    const job = jobMap[a.job_id] || {};
    const run = (S.state.runs || []).find((r) => r.job_id === a.job_id);
    return `<tr>
      <td>
        <div style="font-weight:560">${esc(job.title || '未知岗位')}</div>
        <div class="muted small">${esc(job.company || '')}</div>
      </td>
      <td><span class="pill ${STATUS_CLASS[a.status] || 'line'}">${esc(a.status || '')}</span></td>
      <td class="num">${esc(a.applied_at || '')}</td>
      <td class="num">${run ? `<span class="pill ${scoreClass(run.score)}">${run.score} 分</span>` : '<span class="faint">—</span>'}</td>
      <td><div class="muted small" style="max-width:240px">${esc(a.note || '—')}</div></td>
      <td>
        <select data-action="change-status" data-id="${a.id}" data-job="${a.job_id}">
          ${STATUSES.map((s) => `<option ${a.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
      <td class="nowrap">
        <button class="btn sm ghost" data-action="edit-note" data-id="${a.id}" data-job="${a.job_id}">备注</button>
        ${job.id ? `<button class="btn sm ghost" data-action="open-pack" data-id="${job.id}">投递包</button>` : ''}
      </td>
    </tr>`;
  }).join('');

  $('#view').innerHTML = `
    <div class="page-head">
      <div><h1>投递追踪</h1><p class="sub">每投一个记一笔：投了什么、用哪版简历、现在到哪一步。</p></div>
      <div class="head-actions">
        <button class="btn" data-action="add-application">记录一次投递</button>
      </div>
    </div>
    ${apps.length ? `<div class="card"><table class="table">
      <thead><tr><th>岗位</th><th>状态</th><th>投递日期</th><th>匹配度</th><th>备注</th><th>更新状态</th><th></th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>` : `<div class="card"><div class="empty"><div class="ico">◎</div>
      <h3>还没有投递记录</h3><p>生成定制简历后点「标记已投递」，或在这里手动记一笔。</p>
      <div class="row" style="justify-content:center"><a class="btn" href="#/jobs">去岗位库</a>
      <button class="btn primary" data-action="add-application">手动记录</button></div>
    </div></div>`}`;
}

/* ============================================================
   差距补强
   ============================================================ */

function viewGaps(params) {
  const jobs = S.state.jobs || [];
  if (!jobs.length) {
    $('#view').innerHTML = `
      <div class="page-head"><div><h1>差距补强</h1><p class="sub">先把岗位放进岗位库，这里会告诉你差哪几条、怎么补。</p></div></div>
      <div class="card"><div class="card-body">
        <p class="muted">还没有岗位。去「岗位库」粘一条 JD，或者先做一次定制简历。</p>
        <div class="row" style="margin-top:12px"><button class="btn primary" data-action="add-job">添加岗位</button></div>
      </div></div>`;
    return;
  }
  const want = (params && params.get('job')) || S.gaps.jobId || jobs[0].id;
  S.gaps.jobId = want;
  $('#view').innerHTML = `
    <div class="page-head">
      <div><h1>差距补强</h1><p class="sub">JD 要但你没有的，列成能真做完的小项目。做完再写进档案——不填成果记录，系统不会写。</p></div>
      <div class="head-actions">
        <select id="gap-job" class="select">
          ${jobs.map((j) => `<option value="${esc(j.id)}" ${j.id === want ? 'selected' : ''}>${esc((j.title || '未命名岗位') + (j.company ? ' · ' + j.company : ''))}</option>`).join('')}
        </select>
      </div>
    </div>
    <div id="gap-body"><div class="card"><div class="card-body muted small">正在分析缺口…</div></div></div>`;
  const sel = $('#gap-job');
  if (sel) sel.addEventListener('change', () => loadGaps(sel.value));
  loadGaps(want);
}

async function loadGaps(jobId) {
  const body = $('#gap-body');
  if (!body) return;
  body.innerHTML = '<div class="card"><div class="card-body muted small">正在对照档案分析这个岗位的缺口…</div></div>';
  try {
    const res = await api(`/api/jobs/${encodeURIComponent(jobId)}/gaps`);
    S.gaps.jobId = jobId;
    S.gaps.data = res;
    renderGapsBody();
  } catch (e) {
    body.innerHTML = `<div class="card"><div class="card-body"><b>没拿到缺口清单</b>
      <p class="muted small" style="margin-top:8px">${esc(e.message)}</p></div></div>`;
  }
}

function renderGapsBody() {
  const body = $('#gap-body');
  const d = S.gaps.data;
  if (!body || !d) return;
  const plans = d.plans || [];
  const planOf = (req) => plans.find((p) => p.requirement === req);
  const gaps = d.gaps || [];
  const todo = gaps.filter((g) => g.strength !== 'strong');
  const covered = gaps.filter((g) => g.strength === 'strong');
  const badge = (s) => s === 'none'
    ? '<span class="pill warn">缺</span>'
    : (s === 'partial' ? '<span class="pill">部分</span>' : '<span class="pill ok">已覆盖</span>');

  const planCard = (plan) => {
    if (plan.status === 'done') {
      return `<div class="plan-card done">
        <div class="row between">
          <b>${esc(plan.plan.title || plan.requirement)}</b>
          <span class="pill ok">已写入档案 · ${esc(plan.period || '')}</span>
        </div>
        <p class="small muted" style="margin-top:6px">这条已经变成档案里的项目，生成简历时会自动带上。</p>
      </div>`;
    }
    const checked = S.gaps.checks[plan.id] || {};
    const taskList = (plan.plan.tasks || []).map((t, i) => `
      <li class="${checked[i] ? 'done' : ''}">
        <label class="row" style="gap:8px;align-items:flex-start;cursor:pointer">
          <input type="checkbox" data-action="tick-task" data-id="${plan.id}" data-i="${i}" ${checked[i] ? 'checked' : ''} style="margin-top:4px;width:auto">
          <span>${esc(t)}</span>
        </label>
      </li>`).join('');
    return `<div class="plan-card">
      <div class="row between">
        <b>${esc(plan.plan.title || plan.requirement)}</b>
        <button class="icon-btn" data-action="del-plan" data-id="${esc(plan.id)}" title="删掉这份计划">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 7h14M9 7V5h6v2M8 7l1 13h6l1-13"/></svg>
        </button>
      </div>
      <div class="row small muted" style="gap:10px;margin-top:6px">
        <span class="pill">≈ ${esc(plan.plan.hours || 8)} 小时</span>
        <span class="pill">${esc(plan.plan.level || '入门')}</span>
        <span>工具：${esc((plan.plan.tools || []).join('、'))}</span>
      </div>
      <ol class="plan-tasks">${taskList}</ol>
      <div class="plan-accept">
        <b class="small">做完的标准</b>
        <ul>${(plan.plan.acceptance || []).map((a) => `<li>${esc(a)}</li>`).join('')}</ul>
      </div>
      ${plan.plan.hint ? `<div class="plan-hint">做完后可以这样写（数字换成你实测的）：<i>${esc(plan.plan.hint)}</i></div>` : ''}
      <div class="row" style="margin-top:12px">
        <button class="btn" data-action="toggle-done" data-id="${esc(plan.id)}">我做完了，写入档案</button>
      </div>
      <div class="done-form" id="done-${esc(plan.id)}" hidden>
        <label class="field"><span>成果记录（必填，会变成简历条目）</span>
          <textarea id="ev-${esc(plan.id)}" rows="3" placeholder="写清楚你实际做了什么：用了什么板子/软件、跑了多少组、测到什么数、结果如何。编不出来就别写，面试会问。"></textarea>
        </label>
        <label class="field"><span>完成月份</span><input type="text" id="per-${esc(plan.id)}" placeholder="2026.11"></label>
        <button class="btn primary" data-action="complete-plan" data-id="${esc(plan.id)}">确认写入档案</button>
      </div>
    </div>`;
  };

  const rows = todo.map((g) => {
    const p = planOf(g.requirement);
    return `<div class="gap-row">
      <div class="gap-head">
        ${badge(g.strength)}
        <span class="gap-req">${esc(g.bare)}</span>
        ${p ? '' : `<button class="btn sm" data-action="make-plan" data-req="${esc(g.requirement)}" data-kind="${esc(g.kind)}">生成练习计划</button>`}
      </div>
      ${p ? planCard(p) : `<p class="small muted" style="margin:6px 0 0 0">建议：${esc(g.suggest || '做一个小项目并留下证据')}</p>`}
    </div>`;
  }).join('');

  body.innerHTML = `
    ${todo.length ? `<div class="section-title"><h2>要补的 ${todo.length} 条</h2><div class="line"></div></div>${rows}`
      : '<div class="card"><div class="card-body"><b>这个岗位没有明显缺口</b><p class="muted small" style="margin-top:6px">JD 的要求在你的档案里都能找到依据，直接去生成简历吧。</p></div></div>'}
    ${covered.length ? `<details class="covered-box"><summary>已覆盖的 ${covered.length} 条（不用补）</summary>
      <ul>${covered.map((g) => `<li>${esc(g.bare)}</li>`).join('')}</ul></details>` : ''}`;
}

/* ============================================================
   设置
   ============================================================ */

function viewMaterials() {
  const p = S.state.profile || {};
  const courses = p.courses || [];
  const mats = p.materials || [];
  $('#view').innerHTML = `
    <div class="page-head">
      <div>
        <h1>素材库</h1>
        <p class="sub">把课程清单和实验报告放进来。生成简历时按 JD 关键词自动挑最相关的 2 个实验 + 7 门课程，写进「课程与实验」一节。</p>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>课程清单</h2><span class="hint">顿号、逗号或换行分隔</span></div>
      <div class="card-body">
        <textarea id="courses-input" rows="3" placeholder="模拟电子技术、数字电路、信号与系统、FPGA 与 Verilog、单片机原理、通信原理、电磁场与电磁波">${esc(courses.join('、'))}</textarea>
        <div class="row" style="margin-top:12px">
          <button class="btn primary" data-action="save-courses">保存课程</button>
          <span class="muted small">${courses.length ? `已收录 ${courses.length} 门，会全部参与匹配` : '还没有课程清单'}</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>添加实验报告</h2><span class="hint">.docx / .txt / 直接粘贴</span></div>
      <div class="card-body">
        <div class="row" style="margin-bottom:12px">
          <input type="file" id="mat-file" accept=".docx,.txt" style="display:none">
          <button class="btn" data-action="pick-material">选择文件…</button>
          <span class="muted small" id="mat-file-name">读进来后可以直接改，再点解析</span>
        </div>
        <div class="form-grid">
          <label class="field"><span>实验名称</span>
            <input type="text" id="mat-title" placeholder="如：基于 74LS00 的四人表决电路">
          </label>
          <label class="field"><span>对应课程（可空）</span>
            <input type="text" id="mat-course" placeholder="数字电路">
          </label>
        </div>
        <label class="field" style="margin-top:10px"><span>报告正文（器件型号、仪器、参数、结果写得越具体越好）</span>
          <textarea id="mat-text" rows="8" placeholder="把实验报告正文粘进来，或先选一个 docx 文件自动读入…"></textarea>
        </label>
        <div class="row" style="margin-top:12px">
          <button class="btn primary" data-action="save-material">解析并保存</button>
          <span class="muted small">压成 2–3 条能写进简历的条目；数字和器件只取自原文</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>已收录实验</h2><span class="hint">${mats.length} 份</span></div>
      <div class="card-body">
        ${mats.length ? mats.map((m) => `
          <div style="padding:14px 0;border-top:1px solid var(--line-2)">
            <div class="row" style="justify-content:space-between;align-items:flex-start;gap:12px">
              <div><b>${esc(m.title || '未命名实验')}</b>${m.course ? `<span class="muted small"> · ${esc(m.course)}</span>` : ''}</div>
              <button class="btn sm" data-action="del-material" data-id="${esc(m.id)}">删除</button>
            </div>
            <ul class="small muted" style="margin:8px 0 0 18px;line-height:1.9">${(m.bullets || []).map((b) => `<li>${esc(b)}</li>`).join('')}</ul>
            ${(m.tags || []).length ? `<div class="row" style="margin-top:8px;gap:6px;flex-wrap:wrap">${m.tags.map((t) => `<span class="chip">${esc(t)}</span>`).join('')}</div>` : ''}
          </div>`).join('') : '<div class="empty"><p>还没有实验报告。放 1–2 份最相关的就够，太多反而稀释重点。</p></div>'}
      </div>
    </div>
  `;
  const f = $('#mat-file');
  if (f) f.addEventListener('change', () => uploadMaterial(f));
}

async function uploadMaterial(input) {
  const file = input && input.files && input.files[0];
  if (!file) return;
  const label = $('#mat-file-name');
  if (label) label.textContent = file.name;
  showBusy('正在读取报告…', ['读取文件', '抽取正文']);
  try {
    const b64 = await fileToBase64(file);
    const res = await api('/api/materials/import', { method: 'POST', body: { filename: file.name, data: b64 } });
    hideBusy();
    if ($('#mat-text')) $('#mat-text').value = res.text;
    if ($('#mat-title') && !$('#mat-title').value) $('#mat-title').value = res.title;
    const stem = file.name.replace(/\.[^.]+$/, '');
    if ($('#mat-course') && !$('#mat-course').value) $('#mat-course').value = stem.slice(0, 20);
    toast('已读入正文，检查后点「解析并保存」');
  } catch (e) {
    hideBusy();
    toast(e.message, 'err');
  } finally {
    input.value = '';
  }
}

async function uploadPhoto(file) {
  if (!file) return;
  if (file.size > 6 * 1024 * 1024) { toast('图片超过 6MB，先压一下再传', 'err'); return; }
  showBusy('正在上传人像照…');
  try {
    const b64 = await fileToBase64(file);
    const res = await api('/api/profile/photo', { method: 'POST', body: { data_b64: b64, filename: file.name } });
    await loadState();
    if (S.editProfile) S.editProfile.photo = res.photo;
    hideBusy();
    render();
    toast('人像照已保存，之后每份简历都会放在右上角');
  } catch (e) {
    hideBusy();
    toast(e.message, 'err');
  }
}

function viewSettings() {
  const s = S.state.settings || {};
  const paths = S.state.paths || {};
  const extPath = paths.extension || '';
  $('#view').innerHTML = `
    <div class="page-head"><div><h1>设置</h1><p class="sub">模型、数据与浏览器扩展。</p></div></div>

    <div class="card">
      <div class="card-head"><h2>大模型</h2><span class="hint">${s.has_key ? (s.key_ok === false ? 'Key 校验失败' : '已配置 Key') : '未配置 Key，仅离线模式'}</span></div>
      <div class="card-body">
        ${s.key_ok === false ? `<div class="sticky-note" style="margin-bottom:14px;border-color:#f1b0a8;background:#fff5f4;color:#8f1d14">
          上次测试没通过：接口判定这把 Key 无效。粘贴一把新的再点「测试连接」；在此之前生成会自动走离线兜底。
        </div>` : ''}
        <form id="settings-form">
          <div class="form-grid">
            <label class="field"><span>接口类型</span>
              <select name="provider">
                <option value="deepseek" ${s.provider === 'deepseek' ? 'selected' : ''}>DeepSeek（官方）</option>
                <option value="dashscope" ${s.provider === 'dashscope' ? 'selected' : ''}>阿里云百炼（通义千问）</option>
                <option value="custom" ${s.provider === 'custom' ? 'selected' : ''}>其他 OpenAI 兼容接口</option>
              </select>
            </label>
            <label class="field"><span>Base URL</span>
              <input type="text" name="base_url" value="${esc(s.base_url || 'https://api.deepseek.com')}">
            </label>
            <label class="field"><span>模型</span>
              <input type="text" name="model" value="${esc(s.model || 'deepseek-chat')}">
            </label>
            <label class="field"><span>API Key</span>
              <input type="password" name="api_key" placeholder="${s.has_key ? '已保存，留空则不修改' : 'sk-...'}" autocomplete="off">
            </label>
            <label class="field"><span>温度（0–1，改写建议 0.4）</span>
              <input type="number" name="temperature" min="0" max="1.5" step="0.1" value="${esc(s.temperature ?? 0.4)}">
            </label>
            <label class="row small" style="align-items:center;gap:8px;align-self:end;padding-bottom:8px">
              <input type="checkbox" name="mock" ${s.mock ? 'checked' : ''} style="width:auto"> 强制离线模式（不调用大模型）
            </label>
          </div>
          <div class="row" style="margin-top:16px">
            <button type="submit" class="btn primary">保存设置</button>
            <button type="button" class="btn" data-action="test-key">测试连接</button>
            <span class="muted small" id="test-result"></span>
          </div>
        </form>
        <div class="sticky-note" style="margin-top:14px">
          <div>Key 保存在本机 <code>data/settings.json</code>，不会随备份导出。调用时只发送「档案 + 岗位 JD」到你所填的接口。</div>
          <div style="margin-top:8px">DeepSeek：Base URL <code>https://api.deepseek.com</code>，模型 <code>deepseek-chat</code>。<br>
          阿里云百炼：Base URL <code>https://dashscope.aliyuncs.com/compatible-mode/v1</code>（要带 <code>/v1</code>），模型 <code>qwen-plus</code> 或 <code>qwen-max</code>；Key 用百炼控制台的「API-KEY」，不是阿里云 AccessKey（<code>LTAI…</code>）。</div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>数据</h2><span class="hint">全部在本机</span></div>
      <div class="card-body">
        <div class="kv"><span class="k">数据目录</span><span class="v mono">${esc(paths.data || '')}</span><span></span></div>
        <div class="kv"><span class="k">备份</span><span class="v">导出档案、岗位、定制记录与投递流水（不含 Key）</span>
          <a class="btn sm" href="/api/backup">导出 JSON</a></div>
        <div class="kv"><span class="k">生成的简历</span><span class="v mono">${esc(paths.output || '')}</span><span></span></div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>浏览器扩展（半自动投递）</h2><span class="hint">实验性</span></div>
      <div class="card-body">
        <p class="small muted">在招聘页面自动填充姓名/电话/学校/技能，并上传定制简历；发送与提交永远由你确认。</p>
        <ol class="small" style="margin:12px 0 12px 18px;line-height:2;color:var(--ink-2)">
          <li>打开 Edge 的 <span class="mono">edge://extensions</span>，开启「开发人员模式」</li>
          <li>点「加载解压缩的扩展」，选择 <span class="mono">${esc(extPath)}</span></li>
          <li>回到本页刷新，在岗位页点扩展图标即可填充</li>
        </ol>
        <div class="row">
          <button class="btn sm" data-action="copy" data-copy="${esc(extPath)}">复制扩展路径</button>
          <span class="muted small">扩展只访问 127.0.0.1，不会外传数据</span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>关于</h2></div>
      <div class="card-body small muted">
        ${esc(S.state.meta.app)} v${esc(S.state.meta.version)} · 本地运行 · 数据不出机（除调用大模型外）
      </div>
    </div>`;

  const preset = (v) => ({
    deepseek: { base: 'https://api.deepseek.com', model: 'deepseek-chat' },
    dashscope: { base: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
  })[v];
  $('#settings-form [name="provider"]').addEventListener('change', (e) => {
    const p = preset(e.target.value);
    if (!p) return;
    const form = $('#settings-form');
    form.base_url.value = p.base;
    form.model.value = p.model;
  });

  $('#settings-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = {
      provider: fd.get('provider'),
      base_url: (fd.get('base_url') || '').trim(),
      model: (fd.get('model') || '').trim(),
      temperature: Number(fd.get('temperature') || 0.4),
      mock: !!fd.get('mock'),
      keep_key: true,
    };
    const key = (fd.get('api_key') || '').trim();
    if (key) body.api_key = key;
    try {
      await api('/api/settings', { method: 'POST', body });
      await loadState();
      toast('设置已保存');
      render();
    } catch (err) { toast(err.message, 'err'); }
  });
}

/* ============================================================
   弹窗 / 忙碌层 / 帮助
   ============================================================ */

function openModal(html, opts = {}) {
  const modal = $('#modal');
  const card = $('#modal-card');
  card.className = 'modal-card' + (opts.wide ? ' wide' : '');
  card.innerHTML = html;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeModal() {
  $('#modal').hidden = true;
  $('#modal-card').innerHTML = '';
  document.body.style.overflow = '';
  if (S.pendingConfirm) {
    const resolve = S.pendingConfirm;
    S.pendingConfirm = null;
    resolve(false);
  }
}

function confirmDialog(opts) {
  return new Promise((resolve) => {
    S.pendingConfirm = resolve;
    openModal(`
      <div class="modal-head">
        <div><h2>${esc(opts.title || '确认')}</h2>${opts.desc ? `<p>${esc(opts.desc)}</p>` : ''}</div>
        <button class="icon-btn" data-action="close-modal">✕</button>
      </div>
      <div class="modal-foot">
        <button class="btn" data-action="close-modal">取消</button>
        <button class="btn ${opts.danger ? 'danger' : 'primary'}" data-confirm="1">${esc(opts.ok || '确定')}</button>
      </div>`);
  });
}

function showBusy(title, steps) {
  const busy = $('#busy');
  busy.hidden = false;
  $('#busy-title').textContent = title || '正在处理…';
  const t0 = Date.now();
  clearInterval(S.busyTimer);
  clearInterval(S.busyTick);
  S.busyTimer = setInterval(() => {
    $('#busy-timer').textContent = Math.round((Date.now() - t0) / 1000) + 's';
  }, 500);
  if (steps && steps.length) {
    let i = 0;
    $('#busy-sub').textContent = steps[0];
    S.busyTick = setInterval(() => {
      i = (i + 1) % steps.length;
      $('#busy-sub').textContent = steps[i];
    }, 3500);
  } else {
    $('#busy-sub').textContent = '首次调用大模型可能需要 20–40 秒';
  }
}
function hideBusy() {
  $('#busy').hidden = true;
  clearInterval(S.busyTimer);
  clearInterval(S.busyTick);
}

function openHelp() {
  openModal(`
    <div class="modal-head"><div><h2>怎么用</h2><p>四步走完一个岗位。</p></div>
      <button class="icon-btn" data-action="close-modal">✕</button></div>
    <div class="modal-body">
      <div class="stack" style="gap:14px">
        <div><b>1 · 导入档案</b><div class="muted small" style="margin-top:3px">「我的档案」导入 docx，系统解析成结构化事实库。所有改写只使用这里的内容。</div></div>
        <div><b>2 · 添加岗位</b><div class="muted small" style="margin-top:3px">把 JD 原文粘进「岗位库」，自动解析关键词、硬性要求、职责。</div></div>
        <div><b>3 · 生成定制简历</b><div class="muted small" style="margin-top:3px">「定制简历」里选岗位 → 生成。会得到匹配度、关键词覆盖、ATS 检查和编造检查。</div></div>
        <div><b>4 · 投递与记录</b><div class="muted small" style="margin-top:3px">下载 DOCX，用「投递包」复制填表信息与开场白；投完点「标记已投递」。</div></div>
      </div>
      <div class="divider"></div>
      <div class="small muted">
        <b>防编造</b>：生成后会把新简历里的数字、英文术语、项目名与档案逐项对照，对不上就标红，需要你确认或修改。<br><br>
        <b>隐私</b>：档案、岗位、记录都存在本机 data/。只有点「生成」且配置了 Key 时，才会把「档案 + JD」发给你设置的模型接口。<br><br>
        <b>投递</b>：工具不会替你自动点击提交。招聘平台的验证码与账号风控都要求人在场，半自动更稳。
      </div>
    </div>
    <div class="modal-foot"><button class="btn primary" data-action="close-modal">知道了</button></div>`);
}

/* ============================================================
   文件导入
   ============================================================ */

function fileToBase64(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(String(fr.result).split(',')[1] || '');
    fr.onerror = rej;
    fr.readAsDataURL(file);
  });
}

async function importFile(file) {
  if (!file) return;
  if (!/\.docx$/i.test(file.name)) { toast('请选择 .docx 文件（.doc 请先另存为 .docx）', 'err'); return; }
  showBusy('正在解析简历…', ['读取 docx', '识别章节', '抽取教育/项目/技能', '生成档案']);
  try {
    const b64 = await fileToBase64(file);
    const res = await api('/api/profile/import', {
      method: 'POST',
      body: { filename: file.name, data_b64: b64, mode: S.state.settings.has_key && !S.state.settings.mock ? 'llm' : 'heuristic' },
    });
    S.editProfile = null;
    await loadState();
    hideBusy();
    const warn = res.profile.import_warning;
    if (warn) toast(warn, 'err');
    else toast('档案已导入，检查一下内容');
    location.hash = '#/profile';
    render();
  } catch (e) { hideBusy(); toast(e.message, 'err'); }
}

/* ============================================================
   事件
   ============================================================ */

document.addEventListener('click', async (e) => {
  const confirmBtn = e.target.closest('[data-confirm]');
  if (confirmBtn) {
    const ok = confirmBtn.dataset.confirm === '1';
    const resolve = S.pendingConfirm;
    S.pendingConfirm = null;
    closeModal();
    if (resolve) resolve(ok);
    return;
  }
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const action = el.dataset.action;
  const id = el.dataset.id || '';

  if (action === 'close-modal') { closeModal(); return; }
  if (action === 'reload-page') { location.reload(); return; }
  if (action === 'open-help') { openHelp(); return; }
  if (action === 'import-resume') { $('#file-input').click(); return; }
  if (action === 'add-job') { openJobModal(null); return; }
  if (action === 'edit-job') {
    const job = (S.state.jobs || []).find((j) => j.id === id);
    if (job) openJobModal(job);
    return;
  }

  if (action === 'go-settings') { location.hash = '#/settings'; return; }
  if (action === 'go-profile') { location.hash = '#/profile'; return; }

  if (action === 'make-plan') {
    const req = el.dataset.req || '';
    showBusy('正在设计练习项目…', ['拆解缺口', '匹配你现有条件', '给出验收标准']);
    try {
      const res = await api('/api/practice', {
        method: 'POST',
        body: { job_id: S.gaps.jobId, requirement: req, kind: el.dataset.kind || '' },
      });
      hideBusy();
      const plans = (S.gaps.data.plans || []).filter((p) => p.id !== res.plan.id);
      S.gaps.data.plans = [res.plan].concat(plans);
      renderGapsBody();
      toast(res.created ? '计划已生成，照着做就行' : '这个缺口已经有计划了');
    } catch (err) { hideBusy(); toast(err.message, 'err'); }
    return;
  }

  if (action === 'toggle-done') {
    const box = $(`#done-${id}`);
    if (box) box.hidden = !box.hidden;
    return;
  }

  if (action === 'tick-task') {
    const planId = el.dataset.id;
    const i = el.dataset.i;
    S.gaps.checks[planId] = S.gaps.checks[planId] || {};
    S.gaps.checks[planId][i] = el.checked;
    const li = el.closest('li');
    if (li) li.classList.toggle('done', el.checked);
    return;
  }

  if (action === 'complete-plan') {
    const ev = ($(`#ev-${id}`) || {}).value || '';
    const per = ($(`#per-${id}`) || {}).value || '';
    if (ev.trim().length < 20) { toast('先写清楚你实际做了什么（至少 20 字）', 'err'); return; }
    showBusy('正在写回档案…', ['校验成果记录', '生成项目条目', '更新档案']);
    try {
      await api(`/api/practice/${encodeURIComponent(id)}/complete`, {
        method: 'POST', body: { evidence: ev, period: per },
      });
      await loadState();
      hideBusy();
      await loadGaps(S.gaps.jobId);
      toast('已写入档案，下次生成简历会自动带上这条');
    } catch (err) { hideBusy(); toast(err.message, 'err'); }
    return;
  }

  if (action === 'del-plan') {
    const ok = await confirmDialog({ title: '删掉这份练习计划？', body: '只是删计划，已写入档案的项目不受影响。', okText: '删除' });
    if (!ok) return;
    try {
      const res = await api(`/api/practice/${encodeURIComponent(id)}`, { method: 'DELETE' });
      S.gaps.data.plans = res.plans.filter((p) => p.job_id === S.gaps.jobId);
      renderGapsBody();
      toast('已删除');
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'save-courses') {
    const text = ($('#courses-input') || {}).value || '';
    try {
      const res = await api('/api/courses', { method: 'POST', body: { text } });
      await loadState();
      render();
      toast(`已保存 ${res.courses.length} 门课程`);
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'pick-material') { const f = $('#mat-file'); if (f) f.click(); return; }

  if (action === 'pick-photo') { const f = $('#photo-input'); if (f) f.click(); return; }

  if (action === 'del-photo') {
    const ok = await confirmDialog({ title: '删除人像照？', body: '之后生成的简历不再带照片，已生成的文档不受影响。', okText: '删除' });
    if (!ok) return;
    try {
      const res = await api('/api/profile/photo', { method: 'DELETE' });
      await loadState();
      if (S.editProfile) S.editProfile.photo = '';
      render();
      toast('已删除人像照');
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'save-material') {
    const text = (($('#mat-text') || {}).value || '').trim();
    if (text.length < 20) { toast('报告内容太短，再多粘一点', 'err'); return; }
    showBusy('正在解析实验报告…', ['抽取实验目的与做法', '识别器件与仪器', '压成简历条目']);
    try {
      await api('/api/materials', {
        method: 'POST',
        body: { text, title: (($('#mat-title') || {}).value || '').trim(), course: (($('#mat-course') || {}).value || '').trim() },
      });
      await loadState();
      hideBusy();
      render();
      toast('已加入素材库');
    } catch (err) { hideBusy(); toast(err.message, 'err'); }
    return;
  }

  if (action === 'del-material') {
    const ok = await confirmDialog({ title: '删除这份实验？', body: '只从素材库移除，已经生成的简历不受影响。', okText: '删除' });
    if (!ok) return;
    try {
      await api(`/api/materials/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await loadState();
      render();
      toast('已删除');
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'new-blank') {
    const blank = {
      name: '', headline: '', phone: '', email: '', location: '', objective: '', graduation: '',
      education: [{ school: '', major: '', degree: '本科', period: '', detail: '', gpa: '' }],
      skills: [], internships: [], projects: [], campus: [], awards: [], certificates: [],
      self_eval: '', raw_text: '', gaps: [],
    };
    try {
      const res = await api('/api/profile', { method: 'PUT', body: { profile: blank } });
      S.editProfile = null;
      await loadState();
      toast('已创建空白档案，去填写吧');
      location.hash = '#/profile';
      render();
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'save-profile') { saveProfile(); return; }

  if (action === 'add-entry') {
    S.editProfile = collectProfile();
    const g = el.dataset.group;
    if (g === 'education') S.editProfile.education.push({ school: '', major: '', degree: '本科', period: '', detail: '', gpa: '' });
    else if (g === 'skills') S.editProfile.skills.push({ label: '', text: '' });
    else (S.editProfile[g] = S.editProfile[g] || []).push({ title: '', role: '', period: '', bullets: [] });
    render();
    return;
  }

  if (action === 'del-entry') {
    S.editProfile = collectProfile();
    const g = el.dataset.group;
    const i = Number(el.dataset.index);
    if (Array.isArray(S.editProfile[g])) S.editProfile[g].splice(i, 1);
    render();
    return;
  }

  if (action === 'parse-job') {
    showBusy('正在解析 JD…');
    try {
      await api(`/api/jobs/${id}/parse`, { method: 'POST' });
      await loadState(); hideBusy(); toast('已解析'); render();
    } catch (err) { hideBusy(); toast(err.message, 'err'); }
    return;
  }

  if (action === 'tailor-job') { S.currentJobId = id; location.hash = `#/tailor?job=${id}`; return; }

  if (action === 'generate') { generate(id); return; }

  if (action === 'delete-job') {
    const job = (S.state.jobs || []).find((j) => j.id === id);
    if (!job) return;
    const ok = await confirmDialog({
      title: `删除「${job.title || '这个岗位'}」？`,
      desc: '相关的定制记录会一起删除；已生成的 docx 文件仍留在 data/output。',
      ok: '删除',
      danger: true,
    });
    if (!ok) return;
    try {
      await api(`/api/jobs/${id}`, { method: 'DELETE' });
      await loadState();
      if (S.currentJobId === id) { S.currentJobId = ''; S.currentRun = null; }
      toast('已删除'); render();
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'open-pack') { openPack(id); return; }

  if (action === 'mark-applied') {
    const jobId = id || (S.currentRun && S.currentRun.job && S.currentRun.job.id);
    const runId = S.currentRun && S.currentRun.run_id;
    try {
      await api('/api/applications', { method: 'POST', body: { job_id: jobId, run_id: runId, status: '已投递' } });
      await loadState();
      toast('已记录投递');
      if (!$('#modal').hidden) closeModal();
      render();
    } catch (err) { toast(err.message, 'err'); }
    return;
  }

  if (action === 'copy') { copyText(el.dataset.copy || ''); return; }

  if (action === 'toggle-edit') {
    S.editing = !S.editing;
    renderTailorResult();
    return;
  }

  if (action === 'save-resume') { saveResumeEdits(); return; }

  if (action === 'edit-note') {
    const app = (S.state.applications || []).find((a) => a.id === el.dataset.id) || {};
    openModal(`
      <div class="modal-head"><div><h2>备注</h2><p>记下面试时间、HR 名字、待办。</p></div>
        <button class="icon-btn" data-action="close-modal">✕</button></div>
      <form id="note-form"><div class="modal-body">
        <textarea name="note" rows="5">${esc(app.note || '')}</textarea>
      </div><div class="modal-foot">
        <button type="button" class="btn" data-action="close-modal">取消</button>
        <button class="btn primary" type="submit">保存</button>
      </div></form>`);
    $('#note-form').addEventListener('submit', async (ev) => {
      ev.preventDefault();
      try {
        await api('/api/applications', { method: 'POST', body: { job_id: el.dataset.job, status: app.status || '已投递', note: $('#note-form [name=note]').value.trim() } });
        closeModal(); await loadState(); toast('已保存'); render();
      } catch (err) { toast(err.message, 'err'); }
    });
    return;
  }

  if (action === 'add-application') {
    const jobs = S.state.jobs || [];
    const applied = new Set((S.state.applications || []).map((a) => a.job_id));
    const options = jobs.filter((j) => !applied.has(j.id));
    openModal(`
      <div class="modal-head"><div><h2>记录一次投递</h2><p>适用于手动投递，或补记历史投递。</p></div>
        <button class="icon-btn" data-action="close-modal">✕</button></div>
      <form id="app-form"><div class="modal-body">
        <div class="form-grid">
          <label class="field full"><span>岗位</span>
            <select name="job_id">${options.map((j) => `<option value="${j.id}">${esc(j.title || '未命名')}${j.company ? ' · ' + esc(j.company) : ''}</option>`).join('')}</select>
          </label>
          <label class="field"><span>状态</span><select name="status">${STATUSES.slice(1, 6).map((s) => `<option>${s}</option>`).join('')}</select></label>
          <label class="field"><span>投递日期</span><input type="date" name="applied_at" value="${new Date().toISOString().slice(0, 10)}"></label>
          <label class="field full"><span>备注（可选）</span><textarea name="note" rows="3"></textarea></label>
        </div>
        ${!options.length ? '<p class="muted small" style="margin-top:10px">所有岗位都已有记录。先去岗位库添加新岗位。</p>' : ''}
      </div><div class="modal-foot">
        <button type="button" class="btn" data-action="close-modal">取消</button>
        <button class="btn primary" type="submit" ${!options.length ? 'disabled' : ''}>保存</button>
      </div></form>`);
    $('#app-form').addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const fd = new FormData(ev.target);
      if (!fd.get('job_id')) { toast('没有可记录的岗位', 'err'); return; }
      try {
        await api('/api/applications', { method: 'POST', body: {
          job_id: fd.get('job_id'), status: fd.get('status'), applied_at: fd.get('applied_at'), note: fd.get('note'),
        } });
        closeModal(); await loadState(); toast('已记录'); render();
      } catch (err) { toast(err.message, 'err'); }
    });
    return;
  }

  if (action === 'test-key') {
    const out = $('#test-result');
    if (out) { out.textContent = '测试中…'; out.style.color = ''; }
    try {
      const res = await api('/api/settings/test', { method: 'POST' });
      if (out) { out.textContent = `连接正常 · ${res.model} · ${res.latency_ms}ms`; out.style.color = 'var(--ok)'; }
      toast('连接正常');
    } catch (err) {
      if (out) { out.textContent = err.message; out.style.color = 'var(--danger)'; }
      toast('连接失败，可勾选「强制离线模式」继续使用', 'err');
    }
    return;
  }
});

document.addEventListener('change', async (e) => {
  const el = e.target;
  if (el.id === 'job-select') {
    location.hash = `#/tailor?job=${el.value}`;
    return;
  }
  if (el.matches('[data-action="change-status"]')) {
    try {
      await api('/api/applications', { method: 'POST', body: { job_id: el.dataset.job, status: el.value } });
      await loadState();
      toast('状态已更新');
      render();
    } catch (err) { toast(err.message, 'err'); }
  }
});

document.addEventListener('focusout', (e) => {
  const el = e.target.closest('[data-edit-path]');
  if (!el || !S.currentRun) return;
  const path = el.dataset.editPath;
  if (!path || path.includes('.x')) return;
  const current = getPath(S.currentRun.resume, path);
  if (current !== el.innerText.trim()) {
    setPath(S.currentRun.resume, path, el.innerText.trim());
    S.dirtyResume = true;
    const btn = $('[data-action="save-resume"]');
    if (btn) { btn.disabled = false; btn.classList.add('accent'); }
  }
});

$('#file-input').addEventListener('change', (e) => {
  const f = e.target.files && e.target.files[0];
  e.target.value = '';
  importFile(f);
});

document.addEventListener('change', (e) => {
  const el = e.target;
  if (el && el.id === 'photo-input') {
    const f = el.files && el.files[0];
    el.value = '';
    if (f) uploadPhoto(f);
  }
});

/* 拖拽导入 */
['dragenter', 'dragover'].forEach((ev) => document.addEventListener(ev, (e) => {
  if (!e.target.closest('#dropzone')) return;
  e.preventDefault();
  $('#dropzone').classList.add('drag');
}));
['dragleave', 'drop'].forEach((ev) => document.addEventListener(ev, (e) => {
  if (!e.target.closest('#dropzone')) return;
  e.preventDefault();
  $('#dropzone').classList.remove('drag');
}));
document.addEventListener('drop', (e) => {
  if (!e.target.closest('#dropzone')) return;
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) importFile(f);
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('#modal').hidden) closeModal();
});

/* 启动 */
boot();