#!/usr/bin/env sh
# macOS / Linux 启动脚本
set -e
cd "$(dirname "$0")"

echo
echo "  JobFit 简历工坊"
echo "  ------------------------------------"
echo

if [ ! -f "app/server.py" ]; then
  echo "找不到 app/server.py，请在项目根目录运行本脚本。"
  exit 1
fi

PY=""
for cand in python3 python; do
  if command -v "$cand" >/dev/null 2>&1; then
    if "$cand" -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" 2>/dev/null; then
      PY="$cand"
      break
    fi
  fi
done

if [ -z "$PY" ]; then
  echo "没有找到 Python 3.8+。"
  echo
  echo "  macOS:  brew install python"
  echo "  Ubuntu: sudo apt install python3 python3-pip"
  echo
  exit 1
fi

if ! "$PY" -c "import docx" >/dev/null 2>&1; then
  echo "当前解释器缺少依赖：$PY"
  echo
  echo "请先执行："
  echo "  $PY -m pip install -r requirements.txt"
  echo
  exit 1
fi

echo "  使用解释器：$PY"
echo "  启动后浏览器会自动打开；按 Ctrl+C 停止服务。"
echo

exec "$PY" app/server.py