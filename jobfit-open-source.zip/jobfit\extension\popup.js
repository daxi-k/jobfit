/* 简历工坊 · 扩展弹窗 */
const $ = (s) => document.querySelector(s);
const storageGet = (keys) => new Promise((res) => chrome.storage.local.get(keys, res));
const storageSet = (obj) => new Promise((res) => chrome.storage.local.set(obj, res));

let state = null;

async function cfg() {
  const s = await storageGet(['port', 'jobId']);
  return { port: Number(s.port) || 8765, jobId: s.jobId || '' };
}

async function load() {
  const { port, jobId } = await cfg();
  $('#port').value = port;
  $('#openlink').href = `http://127.0.0.1:${port}/`;
  $('#openlink').textContent = `http://127.0.0.1:${port}`;
  try {
    const res = await fetch(`http://127.0.0.1:${port}/api/state`, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    state = await res.json();
    const name = (state.profile && state.profile.name) || '';
    $('#status').textContent = name ? `已连接 · ${name}` : '已连接';
    const jobs = state.jobs || [];
    const sel = $('#job');
    sel.innerHTML = jobs.length
      ? jobs.map((j) => `<option value="${j.id}">${esc(j.title || '未命名')}${j.company ? ' · ' + esc(j.company) : ''}</option>`).join('')
      : '<option value="">（岗位库为空）</option>';
    if (jobId && jobs.some((j) => j.id === jobId)) sel.value = jobId;
    const current = jobs.find((j) => j.id === sel.value);
    $('#hint').textContent = current
      ? `当前：${current.title || ''}${current.company ? ' · ' + current.company : ''}`
      : '还没有岗位：先到简历工坊添加。';
    $('#fill').disabled = !jobs.length;
  } catch (e) {
    $('#status').textContent = '未连接';
    $('#err').style.display = 'block';
    $('#err').textContent = '读不到本机服务：请确认简历工坊已启动，端口一致。';
    $('#fill').disabled = true;
  }
}

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

$('#job').addEventListener('change', async () => {
  await storageSet({ jobId: $('#job').value });
  const jobs = (state && state.jobs) || [];
  const cur = jobs.find((j) => j.id === $('#job').value);
  $('#hint').textContent = cur ? `当前：${cur.title || ''}${cur.company ? ' · ' + cur.company : ''}` : '—';
});

$('#save').addEventListener('click', async () => {
  const port = Number($('#port').value) || 8765;
  await storageSet({ port });
  $('#err').style.display = 'none';
  notifyTab({ type: 'jobfit-settings' });
  await load();
});

$('#fill').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'jobfit-fill' });
    if (resp && resp.ok) window.close();
  } catch (e) {
    $('#err').style.display = 'block';
    $('#err').textContent = '当前页面无法填充（可能是浏览器内部页面，或扩展尚未刷新）。请打开岗位页面后重试。';
  }
});

$('#open').addEventListener('click', async () => {
  const { port } = await cfg();
  chrome.tabs.create({ url: `http://127.0.0.1:${port}/` });
});

function notifyTab(msg) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (tab && tab.id) {
      try { chrome.tabs.sendMessage(tab.id, msg, () => void chrome.runtime.lastError); } catch (e) { /* ignore */ }
    }
  });
}

load();