# -*- coding: utf-8 -*-
"""大模型调用：只依赖标准库，兼容 DeepSeek / OpenAI 兼容接口。"""
import json
import socket
import time
import urllib.error
import urllib.request

import config


class LLMError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def endpoint(base_url):
    base = (base_url or "https://api.deepseek.com").rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    if base.endswith("/v1"):
        return base + "/chat/completions"
    return base + "/v1/chat/completions"


def _post(url, payload, api_key, timeout):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + api_key)
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
    return json.loads(raw)


def chat(messages, settings, json_mode=True, max_tokens=6000, temperature=None, timeout=240):
    key = (settings.get("api_key") or "").strip()
    if not key:
        raise LLMError("还没有配置 API Key：请到「设置」里填入 DeepSeek Key")
    payload = {
        "model": settings.get("model") or "deepseek-chat",
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": settings.get("temperature", 0.4) if temperature is None else temperature,
        "stream": False,
    }
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    url = endpoint(settings.get("base_url"))
    last_err = None
    for attempt in range(3):
        try:
            data = _post(url, payload, key, timeout)
            choices = data.get("choices") or []
            if not choices:
                raise LLMError("模型没有返回内容（可能触发限流）")
            content = (choices[0].get("message") or {}).get("content") or ""
            if not content.strip():
                raise LLMError("模型返回为空")
            return content
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = e.read().decode("utf-8", "replace")[:600]
            except Exception:
                pass
            msg = _explain_http(e.code, detail)
            last_err = LLMError(msg, e.code)
            # 有些 OpenAI 兼容接口不认 response_format，去掉再试一次
            if e.code in (400, 422) and "response_format" in payload and ("response_format" in detail or "json" in detail.lower()):
                payload.pop("response_format", None)
                if attempt < 2:
                    continue
            if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                time.sleep(1.5 * (attempt + 1))
                continue
            raise last_err
        except (urllib.error.URLError, socket.timeout, TimeoutError) as e:
            last_err = LLMError("网络请求失败：%s（检查网络/代理或 base_url）" % getattr(e, "reason", e))
            if attempt < 2:
                time.sleep(1.5 * (attempt + 1))
                continue
            raise last_err
        except json.JSONDecodeError:
            last_err = LLMError("接口返回的不是合法 JSON，请检查 base_url 是否正确")
            raise last_err
    raise last_err or LLMError("调用失败")


def _explain_http(code, detail):
    hints = {
        401: "API Key 无效或已过期",
        402: "账户余额不足",
        403: "没有访问权限",
        404: "接口地址不存在，检查 base_url（DeepSeek 一般是 https://api.deepseek.com）",
        422: "请求参数不合法",
        429: "请求过于频繁，请稍后再试",
        500: "服务端错误，稍后重试",
        503: "服务繁忙，稍后重试",
    }
    base = hints.get(code, "接口返回 HTTP %s" % code)
    return base + ("；" + detail.strip() if detail.strip() else "")


def parse_json_reply(content):
    """容错解析：去掉代码围栏、截取首个 JSON 对象。"""
    text = (content or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
        raise


def test_connection(settings):
    started = time.time()
    reply = chat(
        [{"role": "user", "content": "只回复两个字：正常"}],
        settings, json_mode=False, max_tokens=20, temperature=0.0, timeout=60,
    )
    return {
        "ok": True,
        "model": settings.get("model"),
        "latency_ms": int((time.time() - started) * 1000),
        "reply": reply.strip()[:40],
    }