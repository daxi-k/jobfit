# -*- coding: utf-8 -*-
"""生成测试用的示例简历。

仓库里不放真实的个人简历：需要时用本脚本现场生成一份结构相同的假数据简历。
运行：python tests/make_fixture.py
"""
import os

from docx import Document
from docx.shared import Pt

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "fixtures", "resume.docx")

# 结构照真实简历还原，内容全部为示例假数据
LINES = [
    "张 三   硬件工程师 / FPGA 开发",
    "示例大学 · 电子信息工程（本科）· 2027 届",
    "电话 13800000000   ｜   邮箱 zhangsan@example.com   ｜   求职方向 硬件工程师",
    "教 育 背 景",
    "示例大学\t2023.09 – 2027.06",
    "电子信息工程（本科）   ·   主修课程：模拟电子技术、数字电路、CPLD/FPGA 设计及应用、"
    "C 语言程序设计、嵌入式系统、信号与系统、通信原理、计算机网络",
    "专 业 技 能",
    "▪ 硬件设计：Altium Designer 独立完成原理图绘制、封装库调用与 PCB Layout 自查，"
    "输出 BOM 清单；了解叠层与阻抗控制的基本概念。",
    "▪ FPGA 开发：熟悉 Verilog 可综合写法（组合/时序逻辑、状态机、移位寄存器、时钟分频、"
    "数码管动态扫描）；掌握 Vivado 全流程——RTL 编码 → Testbench 仿真 → XDC 引脚约束 → "
    "综合与布局布线 → 比特流下载 → 板级调试。",
    "▪ 测试实操：用万用表、示波器测量 IO 电平与波形，以仿真波形对照板级现象定位故障；"
    "可手工焊接 0402/0603 阻容与 SOP/QFN 封装器件，能排查虚焊、短路、驱动异常。",
    "▪ 编程基础：C 语言（熟练）；Python（NumPy / Matplotlib，基础数据处理与脚本）；Linux 常用命令。",
    "项 目 经 历",
    "基于 FPGA 的 16 位流水灯与数码管动态显示系统   ｜ 项目负责人\t2025（月份待补）",
    "▪ 平台与流程：Xilinx Artix-7 XC7A35T，在 Vivado 内完成工程搭建、RTL 编码、功能仿真、"
    "引脚约束、综合布线与比特流下载全流程。",
    "▪ 逻辑设计：将 100MHz 系统时钟分频为 2Hz 驱动显示节奏，用移位寄存器实现 16 位 LED 循环流水；"
    "共阴极数码管动态扫描 + BCD 译码，读取拨码开关做十六进制显示，按键切换显示模式并做软件消抖。",
    "▪ 硬件实现：Altium Designer 完成原理图与 PCB 布局检查、器件封装核对与 BOM 整理；"
    "0603 阻容与 SOP 芯片手工焊接，独立完成上电调试。",
    "▪ 调试验证：以仿真波形对照板级实测，用示波器测 IO 电平与波形，定位并修复虚焊、短路导致的"
    "数码管与 LED 驱动异常，全部功能通过验证。",
    "电子电路综合实训   ｜ 小组成员\t2025（月份待补）",
    "▪ 搭建模拟/数字电路实验平台，完成放大电路与逻辑电路的焊接、参数调整与性能测试，"
    "记录实验数据并撰写实训报告。",
    "▪ 根据测试现象反推电路参数问题（如工作点偏移、驱动不足），调整后复测通过。",
    "校 内 实 践",
    "电子技术创新兴趣小组   ｜ 成员\t2024（月份待补）– 至今",
    "▪ 自主完成 Verilog 语法练习与经典时序案例复现，学习 VCS、DC 综合、STA 静态时序分析等 ASIC 流程概念。",
    "▪ 用 Python 完成数据分析小实验与可视化，并在小组内做技术分享。",
    "自 我 评 价",
    "电子信息工程本科，动手能力强于纸面：能自己画图、焊板、上电、用示波器找故障，"
    "遇到问题习惯先分段隔离再定位根因。对数字硬件与 FPGA 方向有持续兴趣，"
    "希望从硬件测试岗做起，把板级调试经验做扎实。",
]


def build(path=OUT):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(10.5)
    for line in LINES:
        doc.add_paragraph(line)
    doc.save(path)
    return path


if __name__ == "__main__":
    print("已生成：", build())