# -*- coding: utf-8 -*-
"""路径与默认配置。"""
import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # jobfit/
APP_DIR = os.path.join(BASE_DIR, "app")
WEB_DIR = os.path.join(BASE_DIR, "web")
DATA_DIR = os.environ.get("JOBFIT_DATA_DIR") or os.path.join(BASE_DIR, "data")
OUT_DIR = os.path.join(DATA_DIR, "output")
UP_DIR = os.path.join(DATA_DIR, "uploads")
DB_PATH = os.path.join(DATA_DIR, "jobfit.db")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")

APP_NAME = "简历工坊 JobFit"
VERSION = "1.0.0"
DEFAULT_PORT = 8765

DEFAULT_SETTINGS = {
    "provider": "deepseek",
    "base_url": "https://api.deepseek.com",
    "model": "deepseek-chat",
    "api_key": "",
    "temperature": 0.4,
    "mock": False,
    "port": DEFAULT_PORT,
    "key_ok": None,
}


def ensure_dirs():
    for d in (DATA_DIR, OUT_DIR, UP_DIR):
        os.makedirs(d, exist_ok=True)


def load_settings():
    ensure_dirs()
    data = dict(DEFAULT_SETTINGS)
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8-sig") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                data.update({k: v for k, v in saved.items() if k in DEFAULT_SETTINGS or k == "port"})
        except Exception:
            pass
    env_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if env_key and not data.get("api_key"):
        data["api_key"] = env_key
    return data


def save_settings(patch):
    data = load_settings()
    for k in ("provider", "base_url", "model", "api_key", "mock", "port", "key_ok"):
        if k in patch and patch[k] is not None:
            data[k] = patch[k]
    if "temperature" in patch and patch["temperature"] is not None:
        try:
            data["temperature"] = max(0.0, min(1.5, float(patch["temperature"])))
        except (TypeError, ValueError):
            pass
    data["base_url"] = str(data.get("base_url") or "").rstrip("/")
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return data


def public_settings(settings=None):
    s = settings or load_settings()
    return {
        "provider": s.get("provider"),
        "base_url": s.get("base_url"),
        "model": s.get("model"),
        "mock": bool(s.get("mock")),
        "has_key": bool(s.get("api_key")),
        "key_ok": s.get("key_ok"),
        "temperature": s.get("temperature"),
        "port": s.get("port"),
    }