# -*- coding: utf-8 -*-
"""技能重写模块：根据 JD 动态生成/排序专业技能条目，确保不编造。"""

import json
import re
import time
from typing import List, Dict, Optional, Tuple

import config
import llm
import materials as mat
import tailor


# 工具/关键词白名单（用于离线模式匹配）
TOOL_HINTS = [
    "Altium Designer", "Vivado", "Quartus", "ModelSim",
    "Verilog", "VHDL", "C", "C++", "Python", "MATLAB",
    "示波器", "万用表", "频谱仪", "信号发生器",
    "Git", "Linux", "Shell", "Makefile",
    "EMC", "PCB", "BOM", "FPGA", "DSP",
    "I2C", "SPI", "UART", "CAN", "USB",
    "自动化测试", "pytest", "Jenkins",
]

KEYWORD_LEXICON = {
    "Altium Designer": ["原理图", "PCB", "Layout", "封装库", "BOM"],
    "Vivado": ["RTL", "综合", "布局布线", "比特流", "时序约束", "STA"],
    "Verilog": ["可综合", "状态机", "移位寄存器", "时钟分频", "仿真"],
    "FPGA": ["逻辑设计", "板级调试", "硬件加速", "IP核"],
    "自动化测试": ["脚本", "pytest", "CI/CD", "回归测试"],
    "EMC": ["辐射", "传导", "整改", "滤波"],
}

def _score_keyword_match(text: str, keywords: List[str]) -> int:
    """计算文本中关键词匹配强度"""
    score = 0
    for kw in keywords:
        if kw.lower() in text.lower():
            score += 2
            # 近义词加分
            if any(syn in text.lower() for syn in ("design", "layout", "debug", "test")):
                score += 1
    return score

def _rewrite_skills_llm(skills: List[Dict], jd: Dict, profile: Dict) -> List[Dict]:
    """调用 LLM 重写技能，JSON mode 输出"""
    # 构建上下文
    context = {
        "profile": {
            "name": profile.get("name"),
            "education": [e.get("major") for e in profile.get("education", [])],
            "skills": [s.get("text") for s in skills],
        },
        "jd": {
            "title": jd.get("title"),
            "keywords": jd.get("keywords", []),
            "responsibilities": jd.get("responsibilities", []),
            "must_have": jd.get("must_have", []),
        },
    }

    prompt = f"""你是一位资深 HR 和技术招聘专家。请根据以下岗位要求（JD）和候选人档案，重写「专业技能」部分，使其精准匹配 JD，同时严格遵守事实——所有内容必须能在档案或实验报告中找到依据，禁止编造新工具、新项目或新成果.

候选人的档案摘要：
{json.dumps(context, ensure_ascii=False, indent=2)}

请输出 JSON 格式：
{{
  "skills": [
    {{
      "label": "技能类别（如：硬件设计）",
      "text": "重写后的技能描述，突出与 JD 匹配的部分，≤70 字",
      "source": "来源路径（如 'profile.skills[0]' 或 'materials[0].bullets[2]'）"
    }}
  ]
}}

要求：
- 按 JD 关键词重要性排序（JD 中出现的词优先）
- 若 JD 提到 'Altium Designer'，则第一条技能必须是它
- 不新增任何未在档案/素材中出现的工具名、协议名、方法名
- 保持每条技能为一个完整句子，无列表符号
- 若无法重写，返回原技能列表（source 仍需标注）

现在开始输出 JSON："""

    try:
        reply = llm.chat([{"role": "user", "content": prompt}], config.load_settings(), json_mode=True, max_tokens=1200)
        data = json.loads(reply.strip())
        skills_out = data.get("skills", [])
        # 标记为 AI 重写
        for s in skills_out:
            s["ai"] = True
        return skills_out
    except Exception:
        return skills  # fallback


def _rewrite_skills_offline(skills: List[Dict], jd: Dict) -> List[Dict]:
    """离线规则版：按关键词权重重排 + 补充常见搭配"""
    # 1. 计算每条技能对 JD 的匹配分
    jd_kws = set(kw.lower() for kw in jd.get("keywords", []))
    jd_must = set(kw.lower() for kw in jd.get("must_have", []))
    jd_all = jd_kws | jd_must

    scored = []
    for i, s in enumerate(skills):
        text = s.get("text", "").lower()
        label = s.get("label", "").lower()
        score = 0
        # 必须项强匹配
        for must in jd_must:
            if must in text or must in label:
                score += 5
        # 关键词匹配
        for kw in jd_all:
            if kw in text or kw in label:
                score += 2
        # 工具匹配
        for tool in TOOL_HINTS:
            if tool.lower() in text:
                score += 1
        # 来源标记
        source = f"profile.skills[{i}]"
        scored.append((score, i, s, source))

    # 2. 排序：高分在前；同分按原始顺序
    scored.sort(key=lambda x: (-x[0], x[1]))

    # 3. 补充常见搭配（仅当 JD 有相关词且档案中存在依据）
    new_skills = []
    used_sources = set()
    for score, idx, orig, src in scored:
        item = dict(orig)
        item["source"] = src
        new_skills.append(item)
        used_sources.add(src)

    # 4. 补充（谨慎）：若 JD 有 "FPGA" 但无对应技能，且档案中有 Verilog，则加一条
    if "fpga" in jd_all and not any("fpga" in s.get("text", "").lower() for s in new_skills):
        verilog_items = [s for s in skills if "verilog" in s.get("text", "").lower()]
        if verilog_items:
            v = verilog_items[0]
            new_skills.insert(0, {
                "label": "FPGA 开发",
                "text": f"{v['text'].split('。')[0]}；熟悉 RTL 设计流程。",
                "source": v.get("source", f"profile.skills[{skills.index(v)}]")
            })

    return new_skills


def rewrite_skills(skills: List[Dict], jd: Dict, profile: Dict, settings: Dict) -> List[Dict]:
    """主入口：LLM 优先，失败则离线兜底"""
    if not skills:
        return []

    # 尝试 LLM
    try:
        out = _rewrite_skills_llm(skills, jd, profile)
        if out and len(out) > 0:
            return out
    except Exception:
        pass

    # 离线兜底
    return _rewrite_skills_offline(skills, jd)