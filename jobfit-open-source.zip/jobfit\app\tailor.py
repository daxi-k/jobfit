# -*- coding: utf-8 -*-
"""简历定制核心：JD 解析 → 定制改写 → 防编造校验 → 打分 → 投递物料。"""
import difflib
import json
import re

import docx_io
import llm
import materials as mat
import skills as skls

KEYWORD_LEXICON = [
    # 硬件 / 电路
    "原理图", "PCB", "Layout", "Altium Designer", "AD", "Cadence", "OrCAD", "PADS", "器件选型", "BOM",
    "模拟电路", "数字电路", "放大电路", "电源", "DC-DC", "LDO", "EMC", "EMI", "阻抗", "叠层", "射频",
    "天线", "高速信号", "信号完整性", "热设计", "结构", "焊接", "SMT", "贴片", "QFN", "BGA", "封装",
    # 测试 / 仪器
    "示波器", "万用表", "电子负载", "信号发生器", "频谱仪", "逻辑分析仪", "板级调试", "硬件测试",
    "可靠性", "失效分析", "老化", "温循", "测试用例", "测试报告", "良率", "产线",
    # 数字 / FPGA
    "FPGA", "Verilog", "VHDL", "Vivado", "Quartus", "ModelSim", "VCS", "时序", "综合", "约束", "状态机",
    "流水线", "移位寄存器", "分频", "数码管", "ADC", "DAC", "PLL", "DDR", "AXI", "UART", "I2C", "SPI",
    "CAN", "USB", "以太网", "Ethernet", "PCIe",
    # 嵌入式 / 软件
    "单片机", "STM32", "ARM", "Cortex", "嵌入式", "RTOS", "FreeRTOS", "Linux", "驱动", "C语言", "C++",
    "Python", "MATLAB", "Simulink", "脚本", "自动化", "上位机", "Qt",
    # 通信 / 电子
    "通信原理", "信号与系统", "数字信号处理", "DSP", "5G", "物联网", "传感器", "无线", "蓝牙", "WiFi",
    "电子信息工程", "电子信息", "电子科学与技术", "微电子", "集成电路",
]

MUST_PREFIX = ("熟悉", "掌握", "具备", "要求", "了解", "熟练", "能够", "能独立", "负责")
RESP_PREFIX = ("负责", "参与", "协助", "配合", "完成", "执行", "设计", "开发", "编写", "搭建", "维护", "支持", "跟进", "测试")

STRENGTH_SCORE = {"strong": 1.0, "partial": 0.55, "none": 0.0}

SYNONYMS = {
    "模拟电路": ["模拟电子技术", "模电", "放大电路"],
    "数字电路": ["数字电子技术", "数电", "逻辑电路"],
    "测试用例": ["测试", "用例", "验证方案"],
    "测试报告": ["测试记录", "实验报告", "验证报告"],
    "PCB": ["印制板", "板卡", "Layout"],
    "示波器": ["示波"],
    "万用表": ["万用"],
    "嵌入式": ["单片机", "嵌入式系统"],
    "通信原理": ["通信"],
    "信号与系统": ["信号"],
    "硬件测试": ["板级测试", "单板测试", "测试实操"],
    "器件选型": ["选型", "器件"],
    "原理图": ["SCH", "原理"],
    "焊接": ["焊"],
    "调试": ["板级调试", "上电调试", "定位故障"],
}


class TailorError(Exception):
    pass


# ---------------------------------------------------------------- 工具

def _contains(text, kw):
    if not kw:
        return False
    text = text or ""
    if re.search(r"[A-Za-z]", kw):
        t, k = text.lower(), kw.lower()
        # 短英文缩写（AD / PCB / C 等）按词边界匹配，避免 "Vivado" 命中 "AD"
        if len(k) <= 3 and re.fullmatch(r"[a-z0-9+#.]+", k):
            return re.search(r"(?<![a-z])" + re.escape(k) + r"(?![a-z])", t) is not None
        return k in t
    return kw in text


def _contains_any(text, kw):
    """关键词命中（含同义词/课程名等宽松匹配），仅用于打分与证据判断。"""
    if _contains(text, kw):
        return True
    for alt in SYNONYMS.get(kw, []):
        if _contains(text, alt):
            return True
    return False


def _split_sentences(text):
    return [s.strip() for s in re.split(r"[。；;\n]+", text or "") if s.strip()]


def _clamp(text, limit):
    text = (text or "").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _strip_topic(text):
    """去掉 bullet 开头的「主题：」标签，用于生成概述/求职信。"""
    t = (text or "").strip()
    m = re.match(r"^([^：:]{2,10})[：:]\s*(.+)$", t)
    return m.group(2) if m else t


def _headline(title, family):
    """岗位标题 + 必要的岗位族补充；标题已经体现方向时不再赘述。"""
    title = (title or "目标岗位").strip()
    family = (family or "").strip()
    if not family:
        return title
    parts = [p.strip() for p in re.split(r"[/、，,]", family) if p.strip()]
    if any(_contains(title, p) for p in parts):
        return title
    return f"{title}（{family}）"


def _requirement_strength(req, corpus):
    req = (req or "").strip()
    if not req:
        return "none"
    kws = [k for k in KEYWORD_LEXICON if _contains(req, k)]
    if not kws:
        kws = re.findall(r"[\u4e00-\u9fa5]{2,6}|[A-Za-z][A-Za-z0-9+#.]{2,}", req)[:6]
    if not kws:
        return "none"
    hit = [k for k in kws if _contains_any(corpus, k)]
    ratio = len(hit) / len(kws)
    if ratio >= 0.75 and len(hit) >= 2:
        return "strong"
    if ratio >= 0.34:
        return "partial"
    return "none"


def flatten_resume(resume):
    parts = [resume.get("headline", ""), resume.get("summary", ""), resume.get("self_eval", "")]
    for s in resume.get("skills") or []:
        parts.append(s.get("text", ""))
        parts.append(s.get("label", ""))
    for group in ("internships", "projects", "campus"):
        for e in resume.get(group) or []:
            parts.append(e.get("title", ""))
            parts.append(e.get("role", ""))
            parts.extend(e.get("bullets") or [])
    parts.extend(resume.get("courses") or [])
    for e in resume.get("labs") or []:
        parts.append(e.get("title", ""))
        parts.append(e.get("course", ""))
        parts.extend(e.get("bullets") or [])
    parts.extend(resume.get("awards") or [])
    parts.extend(resume.get("certificates") or [])
    return "\n".join([p for p in parts if p])


def all_bullets(resume):
    items = []
    for group in ("internships", "projects", "campus", "labs"):
        for e in resume.get(group) or []:
            for b in e.get("bullets") or []:
                items.append((e.get("title", ""), b))
    return items


# ---------------------------------------------------------------- JD 解析

_JD_HEADER = re.compile(r"^(?:工作职责|岗位职责|职位描述|岗位描述|任职要求|职位要求|岗位要求|任职资格|加分项|我们提供|福利待遇)")


def _tidy_jd(text):
    """把从网页复制来的 JD 理顺：句末内联编号换行、断行句子接回去。"""
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[。；;]\s*(?=(?:\d{1,2}|[（(]\d{1,2}[）)])\s*[.、)）])", "。\n", text)
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        is_item = re.match(r"^(?:\d{1,2}\s*[.、)）]|[（(]\d{1,2}[）)]|[-•·*])", line)
        if out and not is_item and not _JD_HEADER.match(line):
            prev = out[-1]
            soft = re.search(r"[，、,（(]$", prev)
            hard = (not re.search(r"[。！？!?；;：:]$", prev)) and len(prev) >= 18
            if soft or hard:
                out[-1] = prev + line
                continue
        out.append(line)
    return "\n".join(out)


def parse_jd(jd_text, settings=None, title_hint="", company_hint=""):
    jd_text = _tidy_jd((jd_text or "").strip())
    if not jd_text:
        raise TailorError("岗位 JD 是空的：先把招聘页面的岗位描述粘进来")
    settings = settings or {}
    if settings.get("api_key") and not settings.get("mock"):
        try:
            return _llm_parse_jd(jd_text, settings, title_hint, company_hint)
        except llm.LLMError:
            pass
    return heuristic_jd(jd_text, title_hint, company_hint)


def heuristic_jd(jd_text, title_hint="", company_hint=""):
    jd_text = _tidy_jd(jd_text)
    lines = [l.strip(" ·-—*#\t") for l in jd_text.splitlines() if l.strip()]
    title = title_hint or ""
    if not title:
        for line in lines[:4]:
            if 2 <= len(line) <= 24 and not re.search(r"[：:]", line):
                title = line
                break
    company = company_hint
    if not company:
        m = re.search(r"(?:公司名称|公司|企业)[：:]\s*([^\n]{2,24})", jd_text)
        if m:
            company = m.group(1).strip(" ：:·|｜")
        else:
            m = re.search(r"([\u4e00-\u9fa5A-Za-z0-9（）()]{2,24}(?:有限公司|股份有限公司|集团))", jd_text)
            if m:
                company = m.group(1)
    must, nice, resp = [], [], []
    for line in lines:
        clean = re.sub(r"^[\d.、)（\s]+", "", line)
        if any(clean.startswith(p) for p in RESP_PREFIX) and len(clean) >= 6:
            resp.append(_clamp(clean, 80))
        elif any(clean.startswith(p) for p in MUST_PREFIX) and len(clean) >= 6:
            must.append(_clamp(clean, 80))
        if re.search(r"优先|加分|有.*经验者", clean):
            nice.append(_clamp(clean, 80))
    keywords = []
    low = jd_text.lower()
    for kw in sorted(KEYWORD_LEXICON, key=lambda x: -len(x)):
        if _contains(low, kw) and kw.lower() not in [k.lower() for k in keywords]:
            keywords.append(kw)
    keywords = keywords[:14]
    if not keywords:
        keywords = [w for w in re.findall(r"[A-Za-z][A-Za-z0-9+#.]{2,}", jd_text)][:8]
    family = "电子/硬件"
    title_low = (title or "").lower()
    if any(_contains(title_low, k) for k in ("FPGA", "Verilog", "Vivado", "数字逻辑", "数字电路")):
        family = "FPGA / 数字逻辑"
    elif any(_contains(title_low, k) for k in ("测试", "验证")):
        family = "硬件测试"
    elif any(_contains(title_low, k) for k in ("嵌入式", "单片机", "STM32", "驱动")):
        family = "嵌入式"
    elif ("测试" in (title or "") or "测试" in jd_text[:120]) and any(_contains(low, k) for k in ("测试", "示波器", "万用表", "可靠性")):
        family = "硬件测试"
    elif any(_contains(low, k) for k in ("FPGA", "Verilog", "Vivado")):
        family = "FPGA / 数字逻辑"
    elif any(_contains(low, k) for k in ("嵌入式", "单片机", "STM32", "驱动")):
        family = "嵌入式"
    hay = f"{title}\n{jd_text}"
    seniority = "实习" if "实习" in hay else ("校招" if re.search(r"校招|应届|20\d{2}\s*届", hay) else "不限")
    return {
        "company": company,
        "title": title or "目标岗位",
        "role_family": family,
        "seniority": seniority,
        "location": "",
        "language": "zh",
        "must_have": must[:8],
        "nice_to_have": nice[:5],
        "keywords": keywords,
        "responsibilities": resp[:8],
        "focus": "围绕岗位关键词组织项目细节与技能表述，突出可上手的实操证据。",
        "source": "heuristic",
    }


JD_SYSTEM = """你是招聘信息解析器，只输出 JSON。从岗位 JD 中抽取结构化信息，不确定的字段留空字符串或空数组，不要编造公司名。
字段：
company（公司名）、title（岗位名）、role_family（岗位族，如 硬件工程师/FPGA/嵌入式/硬件测试/工艺）、
seniority（实习/校招/社招/不限）、location（地点）、language（zh 或 en）、
must_have（硬性要求数组）、nice_to_have（加分项数组）、
keywords（ATS 关键词数组：技能、工具、方法论、领域术语，8-15 个，英文保留原文）、
responsibilities（职责数组）、focus（一句话：这个岗位真正在考察什么）。"""


def _llm_parse_jd(jd_text, settings, title_hint, company_hint):
    hint = ""
    if title_hint or company_hint:
        hint = f"\n（已知信息：岗位={title_hint}；公司={company_hint}，可直接采用）"
    content = llm.chat(
        [{"role": "system", "content": JD_SYSTEM},
         {"role": "user", "content": f"请解析以下 JD：\n\n{jd_text[:6000]}{hint}"}],
        settings, json_mode=True, max_tokens=1600, temperature=0.1,
    )
    data = llm.parse_json_reply(content)
    out = heuristic_jd(jd_text, title_hint, company_hint)
    for key in ("company", "title", "role_family", "seniority", "location", "language", "focus"):
        if isinstance(data.get(key), str) and data.get(key).strip():
            out[key] = data[key].strip()
    for key in ("must_have", "nice_to_have", "keywords", "responsibilities"):
        val = data.get(key)
        if isinstance(val, list) and val:
            out[key] = [str(v).strip() for v in val if str(v).strip()][:15]
    out["source"] = "llm"
    return out


# ---------------------------------------------------------------- 定制改写

TAILOR_SYSTEM = """你是资深硬件/电子方向校招简历顾问，服务对象是电子信息工程本科生，目标岗位为实习或秋招。
你根据候选人的真实档案（profile）为指定岗位定制一份中文简历。

铁律（违反即失败）：
1. 事实只能来自 profile：不得新增公司、学校、项目、奖项、工具、数字、成果。profile 里没有的工具，即使 JD 要求，也绝不能写进简历。
2. 允许重写措辞、调整顺序、合并同类条目、把已有事实中的结果显性化，但不得改变事实本身。
3. 每条 bullet 用「动作 + 对象 + 方法/工具 + 结果或规模」结构，动词开头，18–60 字；禁止「负责/参与/协助」开头的空话。
4. 技能条目按岗位相关性排序，保留原有细节量；用「熟悉/掌握/能/可」等可验证表述开头，不要写「精通」。
5. headline 与 summary 必须贴合岗位：summary 两句话以内，说清「我是谁 + 我能解决什么 + 与岗位的匹配点」，不堆形容词。
6. 只为通过 ATS 而自然嵌入关键词，不堆砌；时间和学校/项目名称保持原样，不要补造缺失的月份。
7. 只输出 JSON，不要 Markdown 代码块，不要任何解释。"""


def _profile_for_prompt(profile, limit=7000):
    slim = {k: v for k, v in profile.items() if k not in ("raw_text", "gaps", "id", "updated_at")}
    text = json.dumps(slim, ensure_ascii=False)
    if len(text) > limit:
        text = text[:limit] + "…"
    return text


def _resume_schema():
    return {
        "headline": "岗位方向标题，如：硬件工程师（FPGA / 板级测试）",
        "summary": "两句话以内，60–90 字",
        "skills": [{"label": "硬件设计", "text": "保留原细节，按相关性排序"}],
        "education": [{"school": "", "major": "", "degree": "", "period": "", "detail": "主修课程"}],
        "projects": [{"title": "原项目名，不可改", "role": "", "period": "原时间，不可编造", "bullets": ["", ""]}],
        "internships": [{"title": "", "role": "", "period": "", "bullets": [""]}],
        "campus": [{"title": "", "role": "", "period": "", "bullets": [""]}],
        "awards": ["原有奖项"],
        "certificates": ["原有证书"],
        "self_eval": "三句话以内",
        "cover_letter": "180–260 字，正式但不说空话，提到一个具体项目证据",
        "greeting": "招聘平台开场白，50 字以内，口语化",
        "jd_evidence": [{"requirement": "JD 要求", "evidence": "档案中的对应证据", "strength": "strong|partial|none"}],
        "keywords_hit": ["已覆盖的关键词"],
        "gap_notes": ["候选人相对岗位的短板，直说"],
        "risk_notes": ["改写中需要本人确认的地方"],
    }


def _llm_tailor(profile, jd, options, settings):
    focus = options.get("focus") or jd.get("focus") or ""
    max_bullets = int(options.get("max_bullets") or 4)
    schema = json.dumps(_resume_schema(), ensure_ascii=False, indent=1)
    user = f"""## 候选人档案（事实来源，唯一依据）
{_profile_for_prompt(profile)}

## 岗位解析
{json.dumps(jd, ensure_ascii=False)}

## 定制要求
- 目标岗位：{jd.get('title')}（{jd.get('company') or '公司未注明'}，{jd.get('seniority')}）
- 本次侧重：{focus or '按 JD 主要要求'}
- 每个项目保留 2–{max_bullets} 条 bullet；与岗位无关的条目可以整段删除，但不得新增
- 简历总 bullet 控制在 8–14 条，保证一页
- 如果档案中缺失月份/时间，保持原样，不要编造
- 奖项/证书/实习经历若档案中没有，就输出空数组
- 覆盖 JD 的 must_have 与 keywords，覆盖不了的写入 gap_notes

只输出如下结构的 JSON（字段名不可变）：
{schema}"""
    content = llm.chat(
        [{"role": "system", "content": TAILOR_SYSTEM}, {"role": "user", "content": user}],
        settings, json_mode=True, max_tokens=6000, temperature=0.45,
    )
    data = llm.parse_json_reply(content)
    if not isinstance(data, dict):
        raise TailorError("模型返回格式不正确")
    return data


def build(profile, job, settings, options, out_path):
    options = dict(options or {})
    jd = job.get("parsed")
    if not jd:
        jd = parse_jd(job.get("jd_text", ""), settings, job.get("title", ""), job.get("company", ""))
    mode = "offline" if (settings.get("mock") or not settings.get("api_key")) else "llm"
    llm_error = ""
    if mode == "llm":
        try:
            resume = _llm_tailor(profile, jd, options, settings)
        except (llm.LLMError, TailorError) as e:
            # 大模型不可用（Key 失效/网络/额度）时退回离线规则，并明确告知用户
            llm_error = str(e)
            mode = "offline"
            resume = mock_tailor(profile, jd, options)
        resume["skills"] = skls.rewrite_skills(resume.get("skills", []), jd, profile, settings)
    else:
        resume = mock_tailor(profile, jd, options)
        resume["skills"] = skls.rewrite_skills(resume.get("skills", []), jd, profile, settings)
        resume["skills"] = skls.rewrite_skills(resume.get("skills", []), jd, profile, settings)

    resume = normalize_resume(resume, profile)
    courses, labs = mat.select_for_jd(profile, jd)
    if courses:
        edu = resume.get("education") or []
        if edu and (edu[0].get("detail") or "").strip():
            # 教育背景里已经有「主修课程」，把相关课程并进去，避免重复占一行
            existing = [c.strip() for c in re.split(r"[、，,;；]", edu[0]["detail"]) if c.strip()]
            merged = existing + [c for c in courses if c not in existing]
            edu[0]["detail"] = "、".join(merged[:12])
        else:
            resume["courses"] = courses
    if labs:
        resume["labs"] = labs
    warnings = guard(profile, resume, jd)
    score = score_resume(profile, resume, jd, warnings)
    density = options.get("density", "normal")
    info = docx_io.render_docx(profile, resume, out_path, density)
    # 一页纸优先：先试紧凑排版（保住素材），实在放不下再从低价值内容开始砍
    if info.get("pages", 1) > 1.12 and density != "compact":
        compact = docx_io.render_docx(profile, resume, out_path, "compact")
        if compact.get("pages", 1) <= 1.12:
            info = compact
            density = "compact"
            info["auto_compact"] = True
    for _ in range(5):
        if info.get("pages", 1) <= 1.12:
            break
        labs = resume.get("labs") or []
        if len(labs) > 1:
            resume["labs"] = labs[:1]
        elif any(len(e.get("bullets") or []) > 2 for e in labs):
            resume["labs"] = [dict(e, bullets=list(e.get("bullets") or [])[:2]) for e in labs]
        elif len(resume.get("courses") or []) > 4:
            resume["courses"] = resume["courses"][:4]
        elif labs:
            resume["labs"] = []
        elif resume.get("courses"):
            resume["courses"] = []
        else:
            break
        score = score_resume(profile, resume, jd, warnings)
        info = docx_io.render_docx(profile, resume, out_path, density)
    payload = {
        "mode": mode,
        "llm_error": (llm_error[:280] + "…") if len(llm_error) > 280 else llm_error,
        "job": {"id": job.get("id"), "title": job.get("title") or jd.get("title"),
                "company": job.get("company") or jd.get("company"), "url": job.get("url", "")},
        "jd": jd,
        "resume": resume,
        "score": score,
        "warnings": warnings,
        "docx": info,
        "options": {k: v for k, v in options.items() if not k.startswith("_")},
        "generated_at": _now_text(),
    }
    return payload


def _now_text():
    import time
    return time.strftime("%Y-%m-%d %H:%M")


# ---------------------------------------------------------------- 离线模式

def mock_tailor(profile, jd, options):
    """不调用大模型：按关键词重排、补模板化概述，绝不新增事实。"""
    text = "\n".join([
        jd.get("title", ""), " ".join(jd.get("keywords") or []), " ".join(jd.get("must_have") or []),
    ])

    def relevance(entry):
        body = " ".join([entry.get("title", ""), " ".join(entry.get("bullets") or []), " ".join(entry.get("tags") or [])])
        return sum(1 for kw in (jd.get("keywords") or []) if _contains(body, kw)) * 2 + \
               sum(1 for kw in (jd.get("keywords") or []) if _contains(entry.get("title", ""), kw))

    projects = sorted([dict(e) for e in (profile.get("projects") or [])], key=relevance, reverse=True)
    internships = sorted([dict(e) for e in (profile.get("internships") or [])], key=relevance, reverse=True)
    campus = sorted([dict(e) for e in (profile.get("campus") or [])], key=relevance, reverse=True)
    skills = sorted([dict(s) for s in (profile.get("skills") or [])],
                    key=lambda s: sum(1 for kw in (jd.get("keywords") or []) if _contains(s.get("text", ""), kw)),
                    reverse=True)

    edu = profile.get("education") or []
    major = edu[0].get("major", "") if edu else ""
    degree = edu[0].get("degree", "") if edu else ""
    grad = (profile.get("graduation") or "")[:4]
    title = jd.get("title") or profile.get("objective") or profile.get("headline") or "目标岗位"
    top_labels = "、".join([s.get("label", "") for s in skills[:3] if s.get("label")])
    summary = f"{major}{degree}{grad}届，求职{title}。"
    if top_labels:
        summary += f"能上手{top_labels}相关的实际工作。"
    summary += "希望在实习/校招中把板级调试与工程化能力做扎实。"

    seen_kw = [kw for kw in (jd.get("keywords") or []) if _contains_any(text + flatten_profile_text(profile), kw)]
    profile_text = flatten_profile_text(profile)
    evidence, used = [], set()
    reqs = list(jd.get("must_have") or []) + ["关键词：" + k for k in (jd.get("keywords") or [])[:8]]
    for req in reqs:
        key = re.sub(r"\s+", "", req)[:12]
        if key in used:
            continue
        used.add(key)
        strength = _requirement_strength(req.replace("关键词：", ""), profile_text)
        evidence.append({
            "requirement": req,
            "evidence": "档案中有课程/项目/技能描述" if strength != "none" else "",
            "strength": strength,
        })
        if len(evidence) >= 8:
            break

    edu_line = f"{profile.get('education', [{}])[0].get('school', '')}{major}{degree}".strip()
    first_project = projects[0].get("title", "") if projects else ""
    top2 = "、".join([s.get("label", "") for s in skills[:2] if s.get("label")])
    greeting = f"您好，我是{major}{grad}届的{profile.get('name') or '应届生'}，熟悉{top2 or '电路与调试'}，" \
               f"想投递{title}岗位，期待进一步沟通。"
    cover_lines = [
        f"您好，我是{profile.get('name') or ''}，{edu_line}，{grad} 届，求职方向为{title}。",
    ]
    if projects:
        e = projects[0]
        b = _strip_topic((e.get("bullets") or [""])[0])
        cover_lines.append(f"在「{first_project}」中担任{e.get('role') or '主要成员'}，{b}")
    if top2:
        cover_lines.append(f"我的技术基础集中在{top2}，与该岗位要求的技术栈有直接对应。")
    cover_lines.append(f"随信附上针对「{title}」调整过的简历，期待有机会进一步沟通。")
    cover = "\n\n".join(cover_lines)
    return {
        "headline": _headline(title, jd.get("role_family")),
        "summary": _clamp(summary, 120),
        "skills": skills,
        "education": [{k: e.get(k, "") for k in ("school", "major", "degree", "period", "detail", "gpa")} for e in edu],
        "projects": [{**docx_io._entry_for_render(e), "bullets": list(e.get("bullets") or [])} for e in projects],
        "internships": [{**docx_io._entry_for_render(e), "bullets": list(e.get("bullets") or [])} for e in internships],
        "campus": [{**docx_io._entry_for_render(e), "bullets": list(e.get("bullets") or [])} for e in campus],
        "awards": [a.get("text", "") for a in (profile.get("awards") or [])],
        "certificates": [c.get("text", "") for c in (profile.get("certificates") or [])],
        "self_eval": profile.get("self_eval", ""),
        "cover_letter": cover,
        "greeting": _clamp(greeting, 70),
        "jd_evidence": evidence,
        "keywords_hit": seen_kw,
        "gap_notes": [],
        "risk_notes": ["离线模式只做排序与模板化，未改写 bullet；配置 API Key 后可生成针对性改写。"],
    }


def flatten_profile_text(profile):
    parts = []
    for key in ("skills", "projects", "internships", "campus"):
        for item in profile.get(key) or []:
            parts.append(json.dumps(item, ensure_ascii=False))
    parts.append(profile.get("self_eval", ""))
    parts.append(profile.get("raw_text", ""))
    return "\n".join(parts)


# ---------------------------------------------------------------- 规范化

def normalize_resume(resume, profile):
    out = {}
    out["headline"] = _clamp(str(resume.get("headline") or profile.get("headline") or ""), 40)
    out["summary"] = _clamp(str(resume.get("summary") or ""), 160)
    out["skills"] = []
    for s in resume.get("skills") or []:
        if isinstance(s, str):
            s = {"label": "", "text": s}
        label = str(s.get("label") or "").strip(" ：:")
        text = _clean(str(s.get("text", "")))
        if label and text.startswith(label + "："):
            text = text[len(label) + 1:]
        out["skills"].append({"label": label, "text": text})
    out["education"] = []
    for e in resume.get("education") or profile.get("education") or []:
        if not isinstance(e, dict):
            continue
        out["education"].append({
            "school": e.get("school", ""), "major": e.get("major", ""), "degree": e.get("degree", ""),
            "period": e.get("period", ""), "detail": e.get("detail", ""), "gpa": e.get("gpa", ""),
        })
    for key in ("projects", "internships", "campus"):
        items = []
        for e in resume.get(key) or []:
            if not isinstance(e, dict) or not (e.get("title") or e.get("bullets")):
                continue
            bullets = []
            for b in e.get("bullets") or []:
                b = _clean(str(b))
                if b and b not in bullets:
                    bullets.append(b)
            item = {
                "title": str(e.get("title") or "").strip(),
                "role": str(e.get("role") or "").strip(),
                "period": str(e.get("period") or "").strip(),
                "meta": str(e.get("meta") or "").strip(),
                "bullets": bullets[:6],
            }
            if item["title"] or item["bullets"]:
                items.append(item)
        out[key] = items
    out["awards"] = [_clean(str(a)) for a in (resume.get("awards") or []) if str(a).strip()]
    out["courses"] = [_clean(str(c)) for c in (resume.get("courses") or []) if str(c).strip()][:8]
    out["labs"] = []
    for e in resume.get("labs") or []:
        if not isinstance(e, dict):
            continue
        bullets = []
        for b in e.get("bullets") or []:
            b = _clean(str(b))
            if b and b not in bullets:
                bullets.append(b)
        if not bullets:
            continue
        out["labs"].append({"title": str(e.get("title") or "").strip()[:40],
                            "course": str(e.get("course") or "").strip()[:20],
                            "bullets": bullets[:3]})
    out["labs"] = out["labs"][:3]
    out["certificates"] = [_clean(str(c)) for c in (resume.get("certificates") or []) if str(c).strip()]
    out["self_eval"] = _clamp(_clean(str(resume.get("self_eval") or "")), 300)
    out["cover_letter"] = str(resume.get("cover_letter") or "").strip()
    out["greeting"] = _clamp(_clean(str(resume.get("greeting") or "")), 90)
    out["jd_evidence"] = [e for e in (resume.get("jd_evidence") or []) if isinstance(e, dict)]
    out["keywords_hit"] = [str(k) for k in (resume.get("keywords_hit") or []) if str(k).strip()]
    out["gap_notes"] = [str(g) for g in (resume.get("gap_notes") or []) if str(g).strip()]
    out["risk_notes"] = [str(r) for r in (resume.get("risk_notes") or []) if str(r).strip()]
    return out


def _clean(text):
    t = (text or "").strip()
    t = re.sub(r"^[▪•·●○◆◇■□▫◦‣*\-–\s]+", "", t)
    t = re.sub(r"\s+", " ", t)
    return t


# ---------------------------------------------------------------- 防编造校验

NUM_RE = re.compile(r"\d+(?:\.\d+)?")
EN_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9+#./_-]{1,}")


def _profile_corpus(profile):
    return json.dumps(profile, ensure_ascii=False)


def guard(profile, resume, jd=None):
    warnings = []
    corpus = _profile_corpus(profile)
    corpus_nums = set(NUM_RE.findall(corpus))
    corpus_low = corpus.lower()

    for title, bullet in all_bullets(resume):
        nums = [n for n in NUM_RE.findall(bullet) if n not in corpus_nums]
        if nums:
            warnings.append({
                "level": "high", "type": "number",
                "text": bullet,
                "detail": "出现档案中不存在的数据：" + "、".join(nums) + "（确认后手动修改，或删掉）",
            })
    for text, where in ((resume.get("summary", ""), "个人概述"), (resume.get("self_eval", ""), "自我评价")):
        for n in NUM_RE.findall(text or ""):
            if n not in corpus_nums:
                warnings.append({"level": "mid", "type": "number", "text": where,
                                 "detail": f"「{where}」里出现了档案中不存在的数据：{n}"})

    # 新增英文术语（可能是虚构工具）
    known = {t.lower() for t in EN_TOKEN_RE.findall(corpus)}
    jd_text = ""
    if jd:
        jd_text = " ".join([jd.get("title", "")] + (jd.get("keywords") or []) + (jd.get("must_have") or []))
    jd_terms = {t.lower() for t in EN_TOKEN_RE.findall(jd_text)}
    new_terms = []
    for token in EN_TOKEN_RE.findall(flatten_resume(resume)):
        low = token.lower()
        if low in known or low in new_terms or len(low) <= 2:
            continue
        if low in jd_terms:
            new_terms.append(token)
    if new_terms:
        warnings.append({
            "level": "mid", "type": "term",
            "text": "、".join(new_terms[:8]),
            "detail": "这些是岗位关键词但档案里没有出现：只有你确实掌握时才保留，否则删掉（面试会追问）",
        })

    # 项目/学校是否被改名或新增
    titles = [e.get("title", "") for e in (profile.get("projects") or []) + (profile.get("internships") or [])
              + (profile.get("campus") or []) if e.get("title")]
    for e in resume.get("projects") or []:
        t = e.get("title", "")
        if t and titles and not _fuzzy_match(t, titles):
            warnings.append({"level": "high", "type": "project", "text": t,
                             "detail": "这个项目名在档案里找不到，疑似新增或改名；请核对"})
    schools = [e.get("school", "") for e in (profile.get("education") or []) if e.get("school")]
    for e in resume.get("education") or []:
        if e.get("school") and schools and not _fuzzy_match(e.get("school", ""), schools):
            warnings.append({"level": "high", "type": "school", "text": e.get("school"),
                             "detail": "学校名与档案不一致"})
    return warnings


def _fuzzy_match(text, candidates, threshold=0.62):
    text = re.sub(r"\s+", "", text or "")
    for c in candidates:
        c2 = re.sub(r"\s+", "", c or "")
        if not c2:
            continue
        if text == c2 or text in c2 or c2 in text:
            return True
        if difflib.SequenceMatcher(None, text, c2).ratio() >= threshold:
            return True
    return False


# ---------------------------------------------------------------- 打分

def score_resume(profile, resume, jd, warnings):
    text = flatten_resume(resume)
    keywords = [k for k in (jd.get("keywords") or []) if k]
    hit = [k for k in keywords if _contains_any(text, k)]
    missing = [k for k in keywords if k not in hit]
    coverage = len(hit) / len(keywords) if keywords else 0.5

    evidence_items = resume.get("jd_evidence") or []
    if not evidence_items:
        evidence_items = [{"requirement": k, "strength": "strong" if k in hit else "none"} for k in keywords[:8]]
    ev = [STRENGTH_SCORE.get(str(e.get("strength", "")).lower(), 0.0) for e in evidence_items]
    evidence_ratio = sum(ev) / len(ev) if ev else 0.0

    bullets = [b for _, b in all_bullets(resume)]
    quant = [b for b in bullets if re.search(r"\d", b)]
    quality_ratio = len(quant) / len(bullets) if bullets else 0.0

    checks = []
    def check(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    check("联系方式完整", profile.get("phone") and profile.get("email"),
          "手机与邮箱都要有")
    check("有明确求职意向", bool(resume.get("headline")), "标题要与目标岗位一致")
    edu = resume.get("education") or []
    check("教育背景完整", bool(edu) and all(e.get("school") and e.get("period") for e in edu),
          "学校 + 专业 + 起止时间")
    check("技能分条清晰", len(resume.get("skills") or []) >= 3, "3 组以上，组名可扫读")
    check("项目含角色与时间", all(e.get("role") and e.get("period") for g in ("projects", "internships", "campus")
                              for e in (resume.get(g) or [])), "每段经历都要有角色和时间")
    check("个人概述存在", bool(resume.get("summary")), "2 句以内，直给匹配点")
    check("条目数量适中", 6 <= len(bullets) <= 16, f"当前 {len(bullets)} 条（建议 6–16）")
    avg_len = sum(len(b) for b in bullets) / len(bullets) if bullets else 0
    check("条目长度合理", 15 <= avg_len <= 75, f"平均 {avg_len:.0f} 字（建议 15–75）")
    check("量化条目占比", quality_ratio >= 0.5, f"{quality_ratio * 100:.0f}% 条目含具体数字/规模")
    bad_numbers = [w for w in warnings if w.get("type") == "number" and w.get("level") == "high"]
    check("无编造数据", not bad_numbers, "数字均能在档案中找到出处")
    ats_ratio = sum(1 for c in checks if c["ok"]) / len(checks)

    total = round(45 * coverage + 25 * evidence_ratio + 20 * ats_ratio + 10 * quality_ratio)
    return {
        "total": max(0, min(100, total)),
        "coverage": {"ratio": round(coverage, 3), "hit": hit, "missing": missing},
        "evidence": {"ratio": round(evidence_ratio, 3),
                     "items": [{"requirement": e.get("requirement", ""), "strength": e.get("strength", ""),
                                "evidence": e.get("evidence", "")} for e in evidence_items[:10]]},
        "ats": {"ratio": round(ats_ratio, 3), "checks": checks},
        "quality": {"ratio": round(quality_ratio, 3), "quantified": len(quant), "total": len(bullets)},
        "char_count": len(re.sub(r"\s", "", text)),
    }


# ---------------------------------------------------------------- 投递物料

PLATFORM_TIPS = {
    "boss": [
        "先把「在线简历」补全，再发附件；BOSS 的聊天窗口里先发 50 字内开场白，回复率更高。",
        "打招呼直接给证据：学校 + 专业 + 做过的板子/项目 + 想投的岗位，别只发「您好」。",
        "对方在线时投递、工作日上午 9:30–11:30 回复率最高。",
    ],
    "实习僧": [
        "实习岗最看到岗时间、每周天数、可实习时长——开场白第一句就写清。",
        "同一公司多个岗位不要重复投，选最匹配的一个。",
    ],
    "牛客": [
        "优先投有内推码的岗位；简历命名「姓名-学校-岗位-2027届」。",
        "投递后在讨论区找同公司同学确认进度，比等系统通知快。",
    ],
    "51job": [
        "51job 主要读在线简历，附件可能不被解析：把项目 bullet 同步进在线简历。",
    ],
    "智联": [
        "在线简历完整度影响曝光；把技能关键词写进「专业技能」栏。",
    ],
    "猎聘": [
        "猎聘偏社招，校招岗位少；投递前确认岗位是否接受应届。",
    ],
    "官网": [
        "官网 ATS 会解析附件：用单栏、无表格图片的 DOCX/PDF，字段与简历逐字一致。",
        "提交后保存岗位截图与投递编号，便于后续跟进。",
    ],
    "default": [
        "文件命名：「姓名-学校-岗位-2027届」。",
        "投递后 3–5 天无回复，可礼貌跟进一次，不要连发。",
        "每投一个岗位，在「投递」页记录状态，避免重复投递。",
    ],
}


def platform_key(source):
    s = (source or "").lower()
    if "boss" in s or "直聘" in s:
        return "boss"
    if "实习僧" in s or "shixiseng" in s:
        return "实习僧"
    if "牛客" in s or "nowcoder" in s:
        return "牛客"
    if "51" in s or "前程" in s:
        return "51job"
    if "智联" in s or "zhaopin" in s:
        return "智联"
    if "猎聘" in s or "liepin" in s:
        return "猎聘"
    if "官网" in s or "official" in s:
        return "官网"
    return "default"


def application_fields(profile, job, resume, jd=None):
    edu = (profile.get("education") or [{}])[0]
    grad = profile.get("graduation") or ""
    skills = (profile.get("skills") or [])
    skill_line = "；".join([f"{s.get('label')}" for s in skills[:4] if s.get("label")])
    certs = "；".join([c.get("text", "") for c in (profile.get("certificates") or []) if c.get("text")])
    projects = profile.get("projects") or []
    highlight = ""
    if projects and projects[0].get("bullets"):
        highlight = _clamp(projects[0]["bullets"][0], 60)
    return [
        {"group": "基本信息", "items": [
            {"label": "姓名", "value": profile.get("name", "")},
            {"label": "手机", "value": profile.get("phone", "")},
            {"label": "邮箱", "value": profile.get("email", "")},
            {"label": "现居城市", "value": profile.get("location", ""), "hint": "按实际填写"},
        ]},
        {"group": "教育信息", "items": [
            {"label": "学校", "value": edu.get("school", "")},
            {"label": "专业", "value": edu.get("major", "")},
            {"label": "学历", "value": edu.get("degree", "")},
            {"label": "毕业时间", "value": grad},
            {"label": "就读时间", "value": edu.get("period", "")},
        ]},
        {"group": "求职信息", "items": [
            {"label": "应聘岗位", "value": job.get("title") or (jd or {}).get("title", "")},
            {"label": "目标城市", "value": (jd or {}).get("location", ""), "hint": "JD 未写就填意向城市"},
            {"label": "到岗时间", "value": "", "hint": "如：随时到岗 / 2027-07"},
            {"label": "可实习时长", "value": "", "hint": "如：每周 5 天，可实习 6 个月"},
            {"label": "期望薪资", "value": "", "hint": "校招可填「面议」"},
            {"label": "技能关键词", "value": skill_line},
            {"label": "证书/语言", "value": certs, "hint": "四六级等"},
            {"label": "项目亮点", "value": highlight},
        ]},
    ]


def pack(profile, job, run_payload):
    resume = run_payload.get("resume") or {}
    jd = run_payload.get("jd") or job.get("parsed") or {}
    return {
        "job": {"id": job.get("id"), "title": job.get("title") or jd.get("title"),
                "company": job.get("company") or jd.get("company"), "url": job.get("url", ""),
                "source": job.get("source", "")},
        "fields": application_fields(profile, job, resume, jd),
        "greeting": resume.get("greeting") or "",
        "cover_letter": resume.get("cover_letter") or "",
        "tips": PLATFORM_TIPS.get(platform_key(job.get("source") or ""), PLATFORM_TIPS["default"]),
        "score": (run_payload.get("score") or {}).get("total"),
        "resume": resume,
        "run_id": run_payload.get("run_id") or "",
    }


# ---------------------------------------------------------------- 档案结构化（导入增强）

STRUCTURE_SYSTEM = """你是简历信息抽取器，只输出 JSON。把给定的中文简历纯文本整理成结构化档案。
规则：只抽取文本中存在的信息，不得编造；缺失字段留空字符串或空数组；bullet 保留原句（可去掉行首符号）。
输出结构：
{"name":"","headline":"","phone":"","email":"","location":"","objective":"","graduation":"",
 "education":[{"school":"","major":"","degree":"","period":"","detail":"","gpa":""}],
 "skills":[{"label":"","text":""}],
 "internships":[{"title":"","role":"","period":"","bullets":[""]}],
 "projects":[{"title":"","role":"","period":"","bullets":[""]}],
 "campus":[{"title":"","role":"","period":"","bullets":[""]}],
 "awards":[{"text":"","period":""}],
 "certificates":[{"text":"","period":""}],
 "self_eval":""}"""


def structure_profile(raw_text, settings):
    if not settings.get("api_key") or settings.get("mock"):
        raise TailorError("智能解析需要先配置 API Key")
    content = llm.chat(
        [{"role": "system", "content": STRUCTURE_SYSTEM},
         {"role": "user", "content": raw_text[:8000]}],
        settings, json_mode=True, max_tokens=4000, temperature=0.1,
    )
    data = llm.parse_json_reply(content)
    if not isinstance(data, dict):
        raise TailorError("模型返回格式不正确")
    return data