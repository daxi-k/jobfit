/* 简历工坊 · 投递助手 — content script
 * 只做「填充」，不点提交。所有提交动作留给用户。
 */
(() => {
  if (window.__jobfitInjected) return;
  window.__jobfitInjected = true;
  if (location.hostname === '127.0.0.1' && location.port === '8765') return;

  const RULES = [
    { label: '姓名', keys: ['真实姓名', '姓名', '名字'] },
    { label: '手机', keys: ['手机号码', '手机号', '手机', '联系电话', '电话'] },
    { label: '邮箱', keys: ['电子邮箱', '邮箱', '邮件', 'email', 'e-mail'] },
    { label: '学校', keys: ['毕业院校', '学校名称', '学校', '院校'] },
    { label: '专业', keys: ['所学专业', '专业'] },
    { label: '学历', keys: ['最高学历', '学历'] },
    { label: '毕业时间', keys: ['毕业时间', '毕业年份', '毕业日期'] },
    { label: '应聘岗位', keys: ['应聘岗位', '求职意向', '期望职位', '意向岗位', '岗位名称'] },
    { label: '技能关键词', keys: ['专业技能', '技能', '专长', '擅长'] },
    { label: '现居城市', keys: ['现居城市', '所在城市', '期望城市', '城市'] },
  ];

  const S = { data: null, port: 8765, jobId: '', panel: null, shadow: null };

  /* ---------------- 样式与面板 ---------------- */
  const host = document.createElement('div');
  host.id = 'jobfit-extension-root';
  document.documentElement.appendChild(host);
  S.shadow = host.attachShadow({ mode: 'open' });
  S.shadow.innerHTML = `
    <style>
      :host { all: initial; }
      .wrap { position: fixed; right: 22px; bottom: 26px; z-index: 2147483000;
        font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; }
      .orb { width: 42px; height: 42px; border-radius: 14px; border: 0; cursor: pointer;
        background: #17191c; color: #fff; font-family: "Songti SC", serif; font-size: 19px;
        box-shadow: 0 8px 24px -8px rgba(0,0,0,.5); display: grid; place-items: center; }
      .orb:hover { background: #0f6b5c; }
      .panel { position: absolute; right: 0; bottom: 52px; width: 292px; background: #fff;
        border: 1px solid #e4e5df; border-radius: 14px; box-shadow: 0 18px 50px -18px rgba(0,0,0,.35);
        padding: 12px; color: #17191c; }
      .panel[hidden] { display: none; }
      .head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 8px; }
      .head b { font-size: 13px; letter-spacing: .02em; }
      .head .dot { font-size: 11px; color: #727a83; }
      .job { font-size: 12px; color: #3c4248; background: #f7f7f2; border-radius: 8px; padding: 7px 9px; margin-bottom: 9px; }
      .job b { color: #17191c; }
      .acts { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
      button.act { border: 1px solid #e4e5df; background: #fff; border-radius: 8px; padding: 7px 6px;
        font-size: 12px; cursor: pointer; color: #17191c; }
      button.act:hover { background: #f7f7f2; }
      button.act.primary { background: #0f6b5c; border-color: #0f6b5c; color: #fff; }
      button.act.primary:hover { background: #0a4c41; }
      button.act[disabled] { opacity: .45; cursor: not-allowed; }
      .res { margin-top: 9px; font-size: 11.5px; color: #727a83; max-height: 130px; overflow: auto; white-space: pre-wrap; }
      .res b { color: #17191c; }
      .foot { margin-top: 9px; display: flex; justify-content: space-between; align-items: center; }
      .foot a { color: #0f6b5c; font-size: 11.5px; text-decoration: none; }
      .foot a:hover { text-decoration: underline; }
      .tip { font-size: 11px; color: #9aa1a8; }
      .toast { position: absolute; right: 0; bottom: 52px; background: #17191c; color: #fff;
        border-radius: 8px; padding: 7px 10px; font-size: 12px; opacity: 0; transition: opacity .2s; pointer-events: none; }
      .toast.show { opacity: 1; }
    </style>
    <div class="wrap">
      <div class="panel" hidden>
        <div class="head"><b>简历工坊</b><span class="dot" id="status">未连接</span></div>
        <div class="job" id="job">—</div>
        <div class="acts">
          <button class="act primary" data-act="fill">填充表单</button>
          <button class="act" data-act="upload">上传简历</button>
          <button class="act" data-act="greet">复制开场白</button>
          <button class="act" data-act="reload">重新读取</button>
        </div>
        <div class="res" id="res"></div>
        <div class="foot">
          <a href="#" target="_blank" id="openapp">打开简历工坊</a>
          <span class="tip">提交由你确认</span>
        </div>
      </div>
      <button class="orb" title="简历工坊 · 投递助手">简</button>
      <div class="toast" id="toast"></div>
    </div>`;

  const el = (sel) => S.shadow.querySelector(sel);
  S.panel = el('.panel');

  function toast(text) {
    const t = el('#toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(S._toastTimer);
    S._toastTimer = setTimeout(() => t.classList.remove('show'), 1800);
  }

  function setResult(html) { el('#res').innerHTML = html; }

  el('.orb').addEventListener('click', () => {
    S.panel.hidden = !S.panel.hidden;
    if (!S.panel.hidden && !S.data) load();
  });

  S.shadow.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;
    if (act === 'fill') doFill();
    if (act === 'upload') doUpload();
    if (act === 'greet') copyGreeting();
    if (act === 'reload') load(true);
  });

  /* ---------------- 数据 ---------------- */
  async function load(force) {
    if (S.data && !force) return;
    el('#status').textContent = '读取中…';
    try {
      const stored = await new Promise((res) => chrome.storage.local.get(['port', 'jobId'], res));
      S.port = Number(stored.port) || 8765;
      S.jobId = stored.jobId || '';
      const url = `http://127.0.0.1:${S.port}/api/extension/bootstrap?job_id=${encodeURIComponent(S.jobId)}`;
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      S.data = await res.json();
      const p = S.data.profile || {};
      el('#status').textContent = p.name ? `已连接 · ${p.name}` : '已连接';
      const jobs = S.data.jobs || [];
      el('#job').innerHTML = S.data.job && S.data.job.title
        ? `当前岗位：<b>${escapeHtml(S.data.job.title)}</b>${S.data.job.company ? ' · ' + escapeHtml(S.data.job.company) : ''}<br><span style="color:#9aa1a8">共 ${jobs.length} 个岗位，可在扩展弹窗切换</span>`
        : '还没有岗位。先到简历工坊添加岗位。';
      el('#openapp').href = `http://127.0.0.1:${S.port}/`;
      setResult('');
    } catch (e) {
      el('#status').textContent = '未连接';
      setResult('读不到本机服务：确认简历工坊正在运行，且设置里的端口一致。');
    }
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function fieldValue(label) {
    const groups = (S.data && S.data.fields) || [];
    for (const g of groups) {
      for (const it of g.items || []) {
        if (it.label === label && it.value) return it.value;
      }
    }
    return '';
  }

  /* ---------------- 填充 ---------------- */
  function contextOf(elm) {
    const parts = [];
    const id = elm.id;
    if (id) {
      try {
        const lab = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (lab) parts.push(lab.innerText);
      } catch (e) { /* ignore */ }
    }
    const wrap = elm.closest('label');
    if (wrap) parts.push(wrap.innerText);
    let p = elm.parentElement;
    let depth = 0;
    while (p && depth < 3) {
      const t = (p.innerText || '').trim();
      if (t && t.length < 80) parts.push(t);
      p = p.parentElement;
      depth++;
    }
    parts.push(elm.getAttribute('placeholder') || '', elm.getAttribute('aria-label') || '',
      elm.name || '', elm.id || '', elm.getAttribute('title') || '');
    return parts.join(' ').toLowerCase();
  }

  function bestRule(ctx) {
    let best = null;
    let bestScore = 0;
    for (const rule of RULES) {
      let score = 0;
      for (const k of rule.keys) {
        if (ctx.includes(k.toLowerCase())) score += k.length;
      }
      if (score > bestScore) { bestScore = score; best = rule; }
    }
    return bestScore >= 2 ? best : null;
  }

  function setValue(elm, value) {
    if (elm.tagName === 'SELECT') {
      const opts = Array.from(elm.options || []);
      const hit = opts.find((o) => (o.textContent || '').trim() === value)
        || opts.find((o) => (o.textContent || '').includes(value))
        || opts.find((o) => value.includes((o.textContent || '').trim()));
      if (!hit) return false;
      elm.value = hit.value;
      elm.dispatchEvent(new Event('input', { bubbles: true }));
      elm.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    const proto = elm.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value');
    if (!setter || !setter.set) return false;
    setter.set.call(elm, value);
    elm.dispatchEvent(new Event('input', { bubbles: true }));
    elm.dispatchEvent(new Event('change', { bubbles: true }));
    elm.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function visible(elm) {
    const r = elm.getBoundingClientRect();
    const cs = getComputedStyle(elm);
    return r.width > 4 && r.height > 4 && cs.visibility !== 'hidden' && cs.display !== 'none' && !elm.disabled;
  }

  async function ensureData() {
    if (!S.data) await load();
    if (!S.data) throw new Error('未连接到简历工坊');
  }

  async function doFill() {
    try {
      await ensureData();
      const filled = [];
      const skipped = [];
      const unknown = [];
      const seen = new Set();
      const inputs = Array.from(document.querySelectorAll('input, textarea, select'));
      for (const elm of inputs) {
        const type = (elm.getAttribute('type') || '').toLowerCase();
        if (['hidden', 'password', 'file', 'checkbox', 'radio', 'submit', 'button', 'search', 'reset'].includes(type)) continue;
        if (!visible(elm) || elm.readOnly) continue;
        const ctx = contextOf(elm);
        if (!ctx.trim()) continue;
        const rule = bestRule(ctx);
        if (!rule) {
          if (ctx.length < 60 && elm.tagName !== 'SELECT') unknown.push(ctx.slice(0, 24));
          continue;
        }
        if (seen.has(rule.label)) continue;
        const value = fieldValue(rule.label);
        if (!value) continue;
        if (elm.value && elm.value.trim()) { skipped.push(rule.label); seen.add(rule.label); continue; }
        if (setValue(elm, value)) { filled.push(rule.label); seen.add(rule.label); }
      }
      setResult(`<b>已填 ${filled.length} 项</b>${filled.length ? '：' + filled.join('、') : ''}`
        + (skipped.length ? `<br>已有内容，跳过：${skipped.join('、')}` : '')
        + `<br><span style="color:#9aa1a8">提交前请逐项核对，尤其是学历/时间。</span>`);
      toast(`已填充 ${filled.length} 项`);
    } catch (e) {
      setResult(escapeHtml(e.message));
      toast('填充失败');
    }
  }

  async function doUpload() {
    try {
      await ensureData();
      if (!S.data.resume_url) { setResult('还没有生成该岗位的定制简历。'); return; }
      const res = await fetch(S.data.resume_url, { cache: 'no-store' });
      if (!res.ok) throw new Error('简历下载失败 HTTP ' + res.status);
      const blob = await res.blob();
      const name = `${(S.data.profile && S.data.profile.name) || '简历'}-${(S.data.job && S.data.job.title) || '岗位'}.docx`;
      const file = new File([blob], name, { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
      const dt = new DataTransfer();
      dt.items.add(file);
      const fileInputs = Array.from(document.querySelectorAll('input[type=file]'));
      for (const inp of fileInputs) {
        if (!visible(inp)) continue;
        try {
          inp.files = dt.files;
          inp.dispatchEvent(new Event('input', { bubbles: true }));
          inp.dispatchEvent(new Event('change', { bubbles: true }));
          setResult(`已上传：<b>${escapeHtml(name)}</b><br><span style="color:#9aa1a8">如果页面没反应，请点页面的上传按钮手动选择。</span>`);
          toast('已上传简历');
          return;
        } catch (e) { /* try next */ }
      }
      setResult('页面里没有可用的文件上传框：请点站点的「上传附件」，手动选择刚下载的 docx。');
    } catch (e) {
      setResult(escapeHtml(e.message));
    }
  }

  async function copyGreeting() {
    try {
      await ensureData();
      const text = (S.data && S.data.greeting) || '';
      if (!text) { setResult('还没有开场白，先在简历工坊生成定制简历。'); return; }
      await navigator.clipboard.writeText(text);
      setResult(`已复制开场白：<br>${escapeHtml(text)}`);
      toast('已复制');
    } catch (e) {
      setResult('复制失败，请在弹窗里手动复制。');
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'jobfit-fill') {
      S.panel.hidden = false;
      doFill().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
      return true;
    }
    if (msg && msg.type === 'jobfit-settings') {
      S.data = null;
      load(true);
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });
})();