# -*- coding: utf-8 -*-
"""简历工坊测试：解析、渲染、定制、防编造、API 全链路。

运行：python -m unittest discover -s tests -v
"""
import base64
import json
import os
import shutil
import sys
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
APP = os.path.join(ROOT, "app")
TMP = os.path.join(HERE, ".tmp")
shutil.rmtree(TMP, ignore_errors=True)
os.makedirs(TMP, exist_ok=True)
os.environ["JOBFIT_DATA_DIR"] = TMP
os.environ["JOBFIT_NO_BROWSER"] = "1"
sys.path.insert(0, APP)

import config  # noqa: E402
import docx_io  # noqa: E402
import materials as mat  # noqa: E402
import practice  # noqa: E402
import store  # noqa: E402
import tailor  # noqa: E402
import server  # noqa: E402

FIXTURE = os.path.join(HERE, "fixtures", "resume.docx")
if not os.path.exists(FIXTURE):  # 仓库不放真实简历，缺了就现场生成一份假数据的
    import make_fixture

    make_fixture.build(FIXTURE)
PNG_1x1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")

LAB_TEXT = """基于 74LS00 的四人表决电路设计
一、实验目的：掌握组合逻辑电路的设计方法，熟悉 74LS00 与非门的使用。
二、实验器材：74LS00 四二输入与非门、直流稳压电源、逻辑电平开关、LED 指示灯、万用表、面包板。
三、实验步骤：按真值表化简得到逻辑表达式，用 74LS00 搭建表决电路，逐组拨动开关测量输出电平，记录真值表。
四、实验结果：四种输入组合下输出与真值表一致，三人及以上同意时输出高电平，测得高电平 4.98V，低电平 0.12V。
五、结论：电路工作正常，验证了设计与理论一致。
"""

JD = """硬件测试实习生（2027 届）
岗位职责：
1. 负责硬件单板测试，使用示波器、万用表完成信号与电源测试；
2. 编写测试用例与测试报告，跟踪问题闭环；
3. 协助硬件工程师完成原理图与 PCB 评审，维护 BOM。
任职要求：
1. 电子信息工程、通信工程等相关专业，本科及以上，2027 届优先；
2. 熟悉模拟电路、数字电路基础，能看懂原理图；
3. 会使用 Altium Designer 者优先；
4. 熟悉 Verilog / FPGA 者优先。
"""


def load_profile():
    return docx_io.parse_resume(docx_io.read_docx(FIXTURE))


class ParserTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = load_profile()

    def test_basic_fields(self):
        self.assertEqual(self.p["name"], "张三")
        self.assertIn("13800000000", self.p["phone"])
        self.assertIn("@", self.p["email"])

    def test_education(self):
        edu = self.p["education"]
        self.assertTrue(edu)
        self.assertIn("示例大学", edu[0]["school"])
        self.assertIn("电子信息工程", edu[0]["major"])
        self.assertIn("本科", edu[0]["degree"])
        self.assertTrue(self.p["graduation"].startswith("2027"))

    def test_experience(self):
        self.assertGreaterEqual(len(self.p["projects"]), 2)
        self.assertGreaterEqual(len(self.p["skills"]), 3)
        blob = " ".join(s.get("label", "") + " " + s["text"] for s in self.p["skills"])
        self.assertIn("FPGA", blob)
        self.assertTrue(all(e.get("bullets") for e in self.p["projects"]))

    def test_gaps_reported(self):
        self.assertTrue(self.p["gaps"])
        self.assertTrue(all("text" in g and "level" in g for g in self.p["gaps"]))

    def test_jd_inline_numbering_and_line_breaks(self):
        jd = ("工作职责\n1.参与整车硬件项目的特性测试与功能调试，协助定位并\n解决硬件问题。\n"
              "任职要求\n1.电子信息、通信工程等相关专业本科及以上，985/211院校优先。"
              "2.掌握硬件基础知识，能独立完成简单硬件操作。")
        parsed = tailor.parse_jd(jd)
        self.assertTrue(any("解决硬件问题" in x for x in parsed["responsibilities"]), parsed)
        self.assertTrue(any("掌握硬件基础知识" in x for x in parsed["must_have"]), parsed)
        self.assertTrue(any("985/211" in x for x in parsed["nice_to_have"]), parsed)
        self.assertEqual(parsed["seniority"], "不限")


class MaterialsTest(unittest.TestCase):
    def test_split_courses(self):
        courses = mat.split_courses("模拟电子技术、数字电路；信号与系统\n1.FPGA 与 Verilog 2.单片机原理")
        self.assertEqual(courses, ["模拟电子技术", "数字电路", "信号与系统", "FPGA 与 Verilog", "单片机原理"])

    def test_parse_lab_strips_labels_and_keeps_results(self):
        parsed = mat.parse_lab(LAB_TEXT, None, "")
        self.assertEqual(parsed["title"], "基于 74LS00 的四人表决电路设计")
        self.assertTrue(2 <= len(parsed["bullets"]) <= 3, parsed["bullets"])
        blob = " ".join(parsed["bullets"])
        self.assertIn("74LS00", blob)
        self.assertIn("4.98V", blob)
        self.assertNotIn("实验目的", blob)
        self.assertNotIn("一、", blob)

    def test_select_prefers_matching_material(self):
        profile = {"courses": ["模拟电子技术", "数字电路", "马克思主义基本原理"],
                   "materials": [
                       {"id": "a", "title": "四人表决电路", "course": "数字电路", "tags": ["万用表"],
                        "bullets": ["用 74LS00 搭建表决电路，实测高电平 4.98V。"], "ts": 1},
                       {"id": "b", "title": "市场营销调研", "course": "", "tags": [],
                        "bullets": ["发放问卷 200 份并统计。"], "ts": 2},
                   ]}
        jd = tailor.parse_jd("硬件测试实习生\n负责单板硬件测试，使用万用表、示波器，熟悉数字电路与原理图。")
        courses, labs = mat.select_for_jd(profile, jd)
        self.assertTrue(labs)
        self.assertEqual(labs[0]["title"], "四人表决电路")
        self.assertLessEqual(len(courses), 7)


class PracticeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        store.init()
        cls.profile = load_profile()
        cls.jd = tailor.parse_jd(JD)

    def test_analyze_lists_missing_requirement(self):
        gaps = practice.analyze(self.profile, self.jd)
        self.assertTrue(gaps)
        self.assertIn("strength", gaps[0])
        self.assertEqual(gaps[0]["strength"], "none", "缺的先排前面")

    def test_plan_offline_has_tasks_and_acceptance(self):
        plan = practice.plan_for("自动化测试", self.profile, self.jd, {"mock": True})
        self.assertGreaterEqual(len(plan["tasks"]), 4)
        self.assertGreaterEqual(len(plan["acceptance"]), 2)
        self.assertLessEqual(plan["hours"], 24)
        self.assertTrue(plan["hint"])

    def test_complete_requires_evidence(self):
        job = store.create_job({"title": "测试岗", "company": "X", "jd_text": JD, "parsed": self.jd})
        plan, _ = practice.start(job["id"], "关键词：信号发生器", "keyword",
                                 self.profile, self.jd, {"mock": True})
        with self.assertRaises(ValueError):
            practice.complete(plan["id"], "做完了", "", self.profile)
        entry = practice.complete(plan["id"], "用信号发生器输出 1kHz 方波，接示波器测幅值与频率，"
                                              "记录 5 组数据并核对误差均在 2% 以内。", "2026.11", self.profile)
        self.assertEqual(entry["role"], "独立完成")
        self.assertEqual(entry["period"], "2026.11")
        saved = store.get_profile()
        self.assertTrue(any(p.get("source") == "practice" for p in saved["projects"]))

    def test_gap_plan_dedupes(self):
        job = store.create_job({"title": "去重岗", "company": "Y", "jd_text": JD, "parsed": self.jd})
        a, created_a = practice.start(job["id"], "关键词：频谱分析仪", "keyword", self.profile, self.jd, {"mock": True})
        b, created_b = practice.start(job["id"], "关键词：频谱分析仪", "keyword", self.profile, self.jd, {"mock": True})
        self.assertTrue(created_a)
        self.assertFalse(created_b)
        self.assertEqual(a["id"], b["id"])


class RenderTest(unittest.TestCase):
    def test_render_and_read_back(self):
        from docx import Document
        p = load_profile()
        resume = docx_io.profile_to_resume(p)
        out = os.path.join(TMP, "render.docx")
        info = docx_io.render_docx(p, resume, out, "normal")
        self.assertTrue(os.path.exists(out))
        self.assertGreater(info["pages"], 0.5)
        self.assertLess(info["pages"], 1.6)
        doc = Document(out)
        self.assertEqual(len(doc.tables), 0)
        text = "\n".join(par.text for par in doc.paragraphs)
        self.assertIn("张三", text)
        self.assertIn("示例大学", text)
        self.assertIn("求职意向", text)
        self.assertIn("Verilog", text)


class TailorTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = load_profile()
        cls.job = {"id": "j_test", "title": "硬件测试实习生", "company": "测试公司",
                   "jd_text": JD, "url": ""}
        cls.settings = {"mock": True}
        cls.out = os.path.join(TMP, "tailored.docx")
        cls.payload = tailor.build(cls.p, cls.job, cls.settings,
                                   {"density": "normal", "max_bullets": 4, "focus": "偏硬件测试"}, cls.out)

    def test_offline_mode_and_score(self):
        self.assertEqual(self.payload["mode"], "offline")
        self.assertGreaterEqual(self.payload["score"]["total"], 60)
        self.assertLessEqual(self.payload["score"]["total"], 100)
        self.assertEqual(self.payload["warnings"], [])

    def test_resume_structure(self):
        r = self.payload["resume"]
        self.assertTrue(r["headline"])
        self.assertTrue(r["summary"])
        self.assertTrue(r["skills"])
        self.assertTrue(r["projects"])
        self.assertTrue(all(len(e["bullets"]) <= 4 for e in r["projects"]))

    def test_jd_keywords(self):
        jd = tailor.parse_jd(JD)
        kws = [k.lower() for k in jd["keywords"]]
        self.assertTrue(any("fpga" in k for k in kws))
        self.assertTrue(any("示波器" in k for k in kws))
        self.assertTrue(jd["must_have"])

    def test_short_token_needs_boundary(self):
        jd = tailor.parse_jd("熟悉 Vivado 与 FPGA 开发")
        self.assertNotIn("AD", jd["keywords"])
        jd2 = tailor.parse_jd("会用 AD 画原理图，熟悉 Altium Designer")
        self.assertIn("AD", jd2["keywords"])

    def test_role_family_follows_title(self):
        jd = tailor.parse_jd("FPGA 开发实习生\n负责 FPGA 逻辑设计与 Vivado 调试，参与板级测试。")
        self.assertEqual(jd["role_family"], "FPGA / 数字逻辑")
        resume = tailor.mock_tailor(self.p, jd, {})
        self.assertEqual(resume["headline"], "FPGA 开发实习生")

    def test_llm_failure_falls_back_to_offline(self):
        original = tailor._llm_tailor

        def boom(*args, **kwargs):
            raise tailor.llm.LLMError("Key 无效")

        tailor._llm_tailor = boom
        try:
            payload = tailor.build(self.p, self.job, {"api_key": "sk-bad", "mock": False},
                                   {"density": "normal"}, os.path.join(TMP, "fallback.docx"))
        finally:
            tailor._llm_tailor = original
        self.assertEqual(payload["mode"], "offline")
        self.assertIn("Key 无效", payload["llm_error"])
        self.assertTrue(payload["resume"]["summary"])
        self.assertTrue(os.path.exists(os.path.join(TMP, "fallback.docx")))

    def test_guard_catches_new_number(self):
        r = json.loads(json.dumps(self.payload["resume"]))
        r["projects"][0]["bullets"][0] += "，效率提升 47%。"
        warnings = tailor.guard(self.p, r, tailor.parse_jd(JD))
        self.assertTrue(any(w["type"] == "number" and "47" in w["detail"] for w in warnings))

    def test_guard_clean_resume(self):
        warnings = tailor.guard(self.p, self.payload["resume"], tailor.parse_jd(JD))
        self.assertEqual(warnings, [])

    def test_pack_fields(self):
        pack = tailor.pack(self.p, self.job, self.payload)
        self.assertTrue(pack["fields"])
        self.assertTrue(pack["greeting"])
        self.assertIn("硬件测试实习生", pack["greeting"])


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        store.init()
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.Handler)
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = "http://127.0.0.1:%d" % cls.httpd.server_address[1]
        cls.req("POST", "/api/settings", {"mock": True, "keep_key": True})

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    @classmethod
    def req(cls, method, path, body=None, raw=False):
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        request = urllib.request.Request(cls.base + path, data=data, method=method,
                                         headers={"Content-Type": "application/json; charset=utf-8"})
        with urllib.request.urlopen(request, timeout=180) as resp:
            payload = resp.read()
            if raw:
                return resp.status, payload
            return json.loads(payload.decode("utf-8"))

    def test_keepalive_bodies_do_not_leak(self):
        import http.client
        conn = http.client.HTTPConnection("127.0.0.1", self.httpd.server_address[1], timeout=30)
        try:
            payload = json.dumps({"mock": True, "keep_key": True}).encode("utf-8")
            for _ in range(2):
                conn.request("POST", "/api/settings", body=payload,
                             headers={"Content-Type": "application/json"})
                resp = conn.getresponse()
                body = json.loads(resp.read().decode("utf-8"))
                self.assertEqual(resp.status, 200)
                self.assertIn("settings", body)
            conn.request("GET", "/api/state")
            resp = conn.getresponse()
            self.assertEqual(resp.status, 200)
            self.assertIn("meta", json.loads(resp.read().decode("utf-8")))
        finally:
            conn.close()

    def test_flow(self):
        state = self.req("GET", "/api/state")
        self.assertEqual(state["meta"]["app"], "简历工坊 JobFit")
        self.assertIn("extension", state["paths"])

        with open(FIXTURE, "rb") as fh:
            raw = fh.read()
        imported = self.req("POST", "/api/profile/import", {
            "filename": os.path.basename(FIXTURE),
            "data_b64": base64.b64encode(raw).decode("ascii"),
            "mode": "heuristic",
        })
        self.assertEqual(imported["profile"]["name"], "张三")

        courses = self.req("POST", "/api/courses", {
            "text": "模拟电子技术、数字电路、信号与系统、FPGA 与 Verilog",
        })
        self.assertEqual(len(courses["courses"]), 4)

        photo = self.req("POST", "/api/profile/photo", {
            "data_b64": base64.b64encode(PNG_1x1).decode("ascii"), "filename": "photo.png",
        })
        self.assertTrue(photo["photo"].endswith(".png"))
        status, blob = self.req("GET", "/api/profile/photo", raw=True)
        self.assertEqual(status, 200)
        self.assertEqual(blob, PNG_1x1)

        saved = self.req("POST", "/api/materials", {"text": LAB_TEXT, "course": "数字电路"})
        self.assertTrue(saved["material"]["bullets"])
        state = self.req("GET", "/api/state")
        self.assertEqual(len(state["profile"]["materials"]), 1)
        self.assertNotIn("text", state["profile"]["materials"][0])  # 正文不上前端，省带宽

        job = self.req("POST", "/api/jobs", {
            "title": "硬件测试实习生", "company": "测试公司", "source": "Boss直聘",
            "url": "https://example.com/j", "jd_text": JD, "autoparse": True,
        })["job"]
        self.assertTrue(job["parsed"]["keywords"])

        out = self.req("POST", "/api/jobs/%s/tailor" % job["id"], {"density": "normal"})
        self.assertIn("payload", out)
        self.assertTrue(out["docx_url"].startswith("/files/") or out["docx_url"].startswith("/api/"))
        self.assertGreater(out["payload"]["score"]["total"], 0)
        resume = out["payload"]["resume"]
        self.assertTrue(resume.get("labs"), resume)
        self.assertIn("74LS00", json.dumps(resume, ensure_ascii=False))
        self.assertFalse([w for w in out["payload"]["warnings"] if w.get("type") == "number"])

        doc = docx_io.Document(out["payload"]["docx"]["path"])
        self.assertEqual(len(doc.tables), 1, "有证件照时头部应是左右两栏")
        self.assertEqual(len(doc.inline_shapes), 1)
        self.assertIn("张三", doc.tables[0].rows[0].cells[0].text)

        status, blob = self.req("GET", out["docx_url"], raw=True)
        self.assertEqual(status, 200)
        self.assertTrue(blob.startswith(b"PK"))

        pack = self.req("GET", "/api/jobs/%s/pack" % job["id"])["pack"]
        self.assertTrue(pack["fields"])
        self.assertTrue(pack["tips"])

        self.req("POST", "/api/applications", {"job_id": job["id"], "run_id": out["run_id"], "status": "已投递"})
        state = self.req("GET", "/api/state")
        self.assertEqual(state["applications"][0]["status"], "已投递")
        self.assertTrue(state["stats"]["avg_score"] > 0)

        backup = self.req("GET", "/api/backup")
        self.assertIn("profile", backup)

        # 差距补强：分析缺口 → 生成练习计划 → 未填成果记录不给写 → 写完进档案
        gaps = self.req("GET", "/api/jobs/%s/gaps" % job["id"])
        self.assertTrue(gaps["gaps"])
        target = [g for g in gaps["gaps"] if g["strength"] != "strong"][0]
        made = self.req("POST", "/api/practice", {
            "job_id": job["id"], "requirement": target["requirement"], "kind": target["kind"],
        })
        pid = made["plan"]["id"]
        self.assertTrue(made["plan"]["plan"]["tasks"])
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.req("POST", "/api/practice/%s/complete" % pid, {"evidence": "做完了", "period": "2026.11"})
        self.assertEqual(ctx.exception.code, 400)
        done = self.req("POST", "/api/practice/%s/complete" % pid, {
            "evidence": "用 Python 写脚本跑了 12 组输入，11 组通过，1 组超时并定位到串口读取阻塞。",
            "period": "2026.11",
        })
        self.assertTrue(done["project"]["bullets"])
        self.assertTrue(any(p.get("source") == "practice" for p in done["profile"]["projects"]))

        removed = self.req("DELETE", "/api/materials/%s" % saved["material"]["id"])
        self.assertEqual(removed["materials"], [])

        cleared = self.req("DELETE", "/api/profile/photo")
        self.assertNotIn("photo", cleared["profile"] or {})


if __name__ == "__main__":
    unittest.main(verbosity=2)