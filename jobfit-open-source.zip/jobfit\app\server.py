# -*- coding: utf-8 -*-
"""本地服务：静态页面 + JSON API。只监听 127.0.0.1，数据全部在本机。"""
import base64
import io
import json
import os
import re
import socket
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

try:
    import docx  # noqa: F401
except ImportError:
    print("缺少依赖 python-docx。")
    print("  1) 用 run.bat 启动（会优先使用自带运行时）")
    print("  2) 或为当前 Python 安装：pip install python-docx")
    sys.exit(1)

import config  # noqa: E402
import docx_io  # noqa: E402
import llm  # noqa: E402
import materials as mat  # noqa: E402
import practice  # noqa: E402
import store  # noqa: E402
import tailor  # noqa: E402

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/markdown; charset=utf-8",
}
MAX_BODY = 24 * 1024 * 1024


class ApiError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def log_error(text):
    try:
        with open(os.path.join(config.DATA_DIR, "error.log"), "a", encoding="utf-8") as f:
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {text}\n")
    except Exception:
        pass


def _download_name(name):
    safe = re.sub(r'[\\/:*?"<>|\r\n]+', "-", name or "resume.docx")
    return "attachment; filename=resume.docx; filename*=UTF-8''" + urllib.parse.quote(safe)


class QuietServer(ThreadingHTTPServer):
    daemon_threads = True
    # Windows 的 SO_REUSEADDR 允许绑定「已被占用」的端口，会出现两个进程抢同一个端口、
    # 请求随机落到其中一个（两个进程还共用一个 SQLite）。所以 Windows 上关掉复用。
    allow_reuse_address = os.name != "nt"

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
            return  # 浏览器提前断开/刷新，属正常情况，不刷红屏
        super().handle_error(request, client_address)


class Handler(BaseHTTPRequestHandler):
    server_version = "JobFit/1.0"
    protocol_version = "HTTP/1.1"

    # ---------- 基础 ----------
    def log_message(self, fmt, *args):
        if os.environ.get("JOBFIT_VERBOSE"):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _send(self, status, body, content_type="application/json; charset=utf-8", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        for key, val in (extra or {}).items():
            self.send_header(key, val)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, data, status=200):
        self._send(status, json.dumps(data, ensure_ascii=False))

    def _error(self, message, status=400):
        self._json({"error": str(message)}, status)

    def _body(self):
        raw = getattr(self, "_raw", b"")
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ApiError("请求体不是合法 JSON")

    def do_OPTIONS(self):
        self._send(204, b"")

    def do_HEAD(self):
        self.do_GET()

    # ---------- 路由 ----------
    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def _dispatch(self, method):
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)
        query = urllib.parse.parse_qs(parsed.query)
        # 先把请求体读干净，避免 keep-alive 连接里残留的 body 被当成下一个请求行
        self._raw = b""
        length = int(self.headers.get("Content-Length") or 0)
        if length > 0:
            if length > MAX_BODY:
                self.close_connection = True
                self._error("文件太大（上限 24MB）", 413)
                return
            self._raw = self.rfile.read(length)
        try:
            if path.startswith("/api/"):
                self._api(method, path, query)
            elif path.startswith("/files/"):
                self._serve_output(path[len("/files/"):])
            else:
                self._serve_static(path)
        except ApiError as e:
            self._error(e, e.status)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            log_error(traceback.format_exc())
            if path.startswith("/api/"):
                self._error("服务内部错误：%s" % e, 500)
            else:
                self._send(500, "internal error", "text/plain; charset=utf-8")

    def _api(self, method, path, query):
        settings = config.load_settings()

        if method == "GET" and path == "/api/health":
            return self._json({"ok": True, "app": config.APP_NAME, "version": config.VERSION})

        if method == "GET" and path == "/api/state":
            return self._json(self._state())

        if path == "/api/profile":
            if method == "GET":
                return self._json({"profile": store.get_profile()})
            if method in ("PUT", "POST"):
                data = self._body()
                profile = data.get("profile") if isinstance(data.get("profile"), dict) else data
                if not isinstance(profile, dict) or not (profile.get("name") or profile.get("education")):
                    raise ApiError("档案至少要有姓名和教育信息")
                old = store.get_profile() or {}
                if "materials" not in profile and old.get("materials"):
                    profile["materials"] = old["materials"]
                if "courses" not in profile and old.get("courses"):
                    profile["courses"] = old["courses"]
                profile["gaps"] = docx_io.detect_gaps(profile)
                saved = store.save_profile(profile)
                return self._json({"profile": saved})

        if path == "/api/profile/photo":
            if method == "GET":
                profile = store.get_profile() or {}
                name = os.path.basename(profile.get("photo") or "")
                full = os.path.join(config.UP_DIR, name)
                if not name or not os.path.exists(full):
                    raise ApiError("还没有上传人像照", 404)
                with open(full, "rb") as fh:
                    blob = fh.read()
                ctype = "image/png" if name.lower().endswith(".png") else "image/jpeg"
                return self._send(200, blob, ctype, {"Cache-Control": "no-cache"})
            if method == "DELETE":
                profile = store.get_profile() or {}
                name = os.path.basename(profile.get("photo") or "")
                if name:
                    try:
                        os.remove(os.path.join(config.UP_DIR, name))
                    except OSError:
                        pass
                profile.pop("photo", None)
                store.save_profile(profile)
                return self._json({"ok": True, "profile": profile})
            if method == "POST":
                data = self._body()
                try:
                    blob = base64.b64decode(data.get("data_b64") or "")
                except Exception:
                    raise ApiError("图片内容读取失败")
                if not blob:
                    raise ApiError("没有收到图片")
                if len(blob) > 6 * 1024 * 1024:
                    raise ApiError("图片超过 6MB，先用手机/微信压一下再传")
                if blob[:8] == b"\x89PNG\r\n\x1a\n":
                    ext = "png"
                elif blob[:2] == b"\xff\xd8":
                    ext = "jpg"
                else:
                    raise ApiError("只支持 JPG / PNG 图片")
                config.ensure_dirs()
                name = "photo-%d.%s" % (int(time.time()), ext)
                with open(os.path.join(config.UP_DIR, name), "wb") as fh:
                    fh.write(blob)
                profile = store.get_profile() or {}
                old = os.path.basename(profile.get("photo") or "")
                profile["photo"] = name
                saved = store.save_profile(profile)
                if old and old != name:
                    try:
                        os.remove(os.path.join(config.UP_DIR, old))
                    except OSError:
                        pass
                return self._json({"ok": True, "photo": name, "profile": saved})

        if method == "POST" and path == "/api/profile/import":
            return self._json(self._import_profile(settings))

        if path == "/api/courses" and method == "POST":
            data = self._body()
            courses = mat.split_courses(data.get("text") or "")
            if not courses:
                raise ApiError("没有识别到课程名，用顿号或换行分隔，例如：模拟电子技术、数字电路")
            profile = store.get_profile() or {}
            profile["courses"] = courses
            store.save_profile(profile)
            return self._json({"ok": True, "courses": courses})

        if path == "/api/materials/import" and method == "POST":
            data = self._body()
            name = str(data.get("filename") or "report.docx")
            try:
                blob = base64.b64decode(data.get("data") or "")
            except Exception:
                raise ApiError("文件内容读取失败")
            if name.lower().endswith(".docx"):
                try:
                    text = docx_io.read_docx_bytes(blob)
                except Exception:
                    raise ApiError("这个 docx 打不开，可能是旧版 .doc 或已损坏，另存为 .docx 再试")
            else:
                text = blob.decode("utf-8", "ignore")
            text = text.strip()
            if len(text) < 20:
                raise ApiError("文件里没读到多少文字，可能是扫描件/图片版")
            return self._json({"ok": True, "text": text[:20000], "title": mat.lab_title(text, name)})

        if path.startswith("/api/materials"):
            profile = store.get_profile() or {}
            items = list(profile.get("materials") or [])
            if method == "POST" and path == "/api/materials":
                data = self._body()
                text = (data.get("text") or "").strip()
                if len(text) < 20:
                    raise ApiError("实验报告内容太短，至少几十个字")
                try:
                    parsed = mat.parse_lab(text, settings, data.get("title") or "")
                except Exception as e:
                    raise ApiError(str(e) or "解析失败")
                item = {
                    "id": mat.new_id(),
                    "title": parsed["title"][:40],
                    "course": (data.get("course") or "").strip()[:20],
                    "bullets": parsed["bullets"][:4],
                    "tags": parsed["tags"][:8],
                    "text": text[:8000],
                    "ts": int(time.time()),
                }
                items.append(item)
                profile["materials"] = items[-40:]
                store.save_profile(profile)
                return self._json({"ok": True, "material": item, "materials": profile["materials"]})
            if method == "PUT" and path == "/api/materials":
                data = self._body()
                mid = data.get("id")
                for m in items:
                    if m.get("id") == mid:
                        for key in ("title", "course", "bullets"):
                            if key in data:
                                m[key] = data[key] if key == "bullets" else str(data[key])[:40]
                profile["materials"] = items
                store.save_profile(profile)
                return self._json({"ok": True, "materials": items})
            if method == "DELETE" and path.startswith("/api/materials/"):
                mid = path.rsplit("/", 1)[-1]
                items = [m for m in items if m.get("id") != mid]
                profile["materials"] = items
                store.save_profile(profile)
                return self._json({"ok": True, "materials": items})

        if method == "POST" and path == "/api/settings":
            data = self._body()
            current = config.load_settings()
            if data.get("api_key") == "" and data.get("keep_key"):
                data.pop("api_key", None)
            if "api_key" in data and data["api_key"] and data["api_key"] != current.get("api_key"):
                data["api_key"] = str(data["api_key"]).strip()
                data["key_ok"] = None  # 换了新 Key，重新测试前不显示旧结论
            config.save_settings(data)
            return self._json({"settings": config.public_settings(), "ok": True})

        if method == "POST" and path == "/api/settings/test":
            try:
                result = llm.test_connection(settings)
            except llm.LLMError as e:
                config.save_settings({"key_ok": False})
                raise ApiError(str(e), 502)
            config.save_settings({"key_ok": True})
            return self._json(result)

        if path == "/api/jobs":
            if method == "GET":
                return self._json({"jobs": store.list_jobs()})
            if method == "POST":
                data = self._body()
                jd_text = (data.get("jd_text") or "").strip()
                if not jd_text:
                    raise ApiError("请粘入岗位 JD 文本")
                job = store.create_job(data)
                if data.get("autoparse", True):
                    try:
                        parsed = tailor.parse_jd(jd_text, settings, job.get("title", ""), job.get("company", ""))
                        job = store.update_job(job["id"], {"parsed": parsed})
                        if not job.get("title") and parsed.get("title"):
                            job = store.update_job(job["id"], {"title": parsed["title"]})
                    except tailor.TailorError:
                        pass
                return self._json({"job": job})

        m = re.match(r"^/api/jobs/([\w-]+)$", path)
        if m:
            job_id = m.group(1)
            if method == "GET":
                job = store.get_job(job_id)
                if not job:
                    raise ApiError("岗位不存在", 404)
                return self._json({"job": job, "runs": store.list_runs(job_id)})
            if method in ("PUT", "PATCH"):
                data = self._body()
                return self._json({"job": store.update_job(job_id, data)})
            if method == "DELETE":
                store.delete_job(job_id)
                return self._json({"ok": True})

        m = re.match(r"^/api/jobs/([\w-]+)/parse$", path)
        if m and method == "POST":
            job = store.get_job(m.group(1))
            if not job:
                raise ApiError("岗位不存在", 404)
            parsed = tailor.parse_jd(job.get("jd_text", ""), settings, job.get("title", ""), job.get("company", ""))
            patch = {"parsed": parsed}
            if not job.get("title") and parsed.get("title"):
                patch["title"] = parsed["title"]
            if not job.get("company") and parsed.get("company"):
                patch["company"] = parsed["company"]
            return self._json({"job": store.update_job(job["id"], patch)})

        m = re.match(r"^/api/jobs/([\w-]+)/gaps$", path)
        if m and method == "GET":
            job = store.get_job(m.group(1))
            if not job:
                raise ApiError("岗位不存在", 404)
            profile = store.get_profile()
            if not profile:
                raise ApiError("请先导入简历档案")
            jd = job.get("parsed") or tailor.parse_jd(job.get("jd_text", ""), settings,
                                                      job.get("title", ""), job.get("company", ""))
            gaps = practice.analyze(profile, jd)
            return self._json({"job": {"id": job["id"], "title": job.get("title"),
                                       "company": job.get("company")},
                               "gaps": gaps, "plans": store.list_practice(job["id"])})

        if path == "/api/practice" and method == "GET":
            qs = urllib.parse.urlparse(self.path).query
            job_id = (urllib.parse.parse_qs(qs).get("job_id") or [""])[0]
            return self._json({"plans": store.list_practice(job_id or None)})

        if path == "/api/practice" and method == "POST":
            data = self._body()
            job = store.get_job(data.get("job_id") or "")
            if not job:
                raise ApiError("岗位不存在", 404)
            profile = store.get_profile()
            if not profile:
                raise ApiError("请先导入简历档案")
            jd = job.get("parsed") or tailor.parse_jd(job.get("jd_text", ""), settings,
                                                      job.get("title", ""), job.get("company", ""))
            requirement = str(data.get("requirement") or "").strip()
            if not requirement:
                raise ApiError("缺少要补的条目")
            plan, created = practice.start(job["id"], requirement, data.get("kind") or "",
                                           profile, jd, settings)
            return self._json({"plan": plan, "created": created})

        m = re.match(r"^/api/practice/([\w-]+)/complete$", path)
        if m and method == "POST":
            data = self._body()
            profile = store.get_profile()
            if not profile:
                raise ApiError("请先导入简历档案")
            try:
                entry = practice.complete(m.group(1), data.get("evidence"), data.get("period"), profile)
            except ValueError as e:
                raise ApiError(str(e))
            return self._json({"project": entry, "profile": store.get_profile(),
                               "plans": store.list_practice()})

        m = re.match(r"^/api/practice/([\w-]+)$", path)
        if m and method == "DELETE":
            store.delete_practice(m.group(1))
            return self._json({"ok": True, "plans": store.list_practice()})

        m = re.match(r"^/api/jobs/([\w-]+)/tailor$", path)
        if m and method == "POST":
            return self._json(self._tailor(m.group(1), settings))

        m = re.match(r"^/api/jobs/([\w-]+)/pack$", path)
        if m and method == "GET":
            job = store.get_job(m.group(1))
            if not job:
                raise ApiError("岗位不存在", 404)
            profile = store.get_profile()
            if not profile:
                raise ApiError("请先导入简历档案")
            runs = store.list_runs(job["id"])
            payload = store.get_run(runs[0]["id"])["payload"] if runs else {}
            pack = tailor.pack(profile, job, payload)
            pack["job"]["url"] = job.get("url", "")
            return self._json({"pack": pack})

        m = re.match(r"^/api/runs/([\w-]+)$", path)
        if m and method == "GET":
            run = store.get_run(m.group(1))
            if not run:
                raise ApiError("定制记录不存在", 404)
            return self._json({"run": {"id": run["id"], "job_id": run["job_id"], "score": run["score"],
                                       "docx_path": run["docx_path"], "created_at": run["created_at"],
                                       "payload": run["payload"]}})

        m = re.match(r"^/api/runs/([\w-]+)/export$", path)
        if m and method == "POST":
            return self._json(self._export_run(m.group(1), settings))

        m = re.match(r"^/api/runs/([\w-]+)/update$", path)
        if m and method == "POST":
            return self._json(self._update_run(m.group(1)))

        m = re.match(r"^/api/runs/([\w-]+)/download$", path)
        if m and method == "GET":
            run = store.get_run(m.group(1))
            if not run or not run.get("docx_path") or not os.path.exists(run["docx_path"]):
                raise ApiError("简历文件还没生成", 404)
            return self._serve_file(run["docx_path"], download_name=os.path.basename(run["docx_path"]))

        if path == "/api/applications":
            if method == "GET":
                return self._json({"applications": store.list_applications()})
            if method == "POST":
                data = self._body()
                job_id = data.get("job_id")
                if not job_id:
                    raise ApiError("缺少 job_id")
                app = store.upsert_application(job_id, data.get("run_id"), data.get("status"),
                                               data.get("note"), data.get("applied_at"))
                if data.get("status"):
                    store.update_job(job_id, {"status": data["status"]})
                return self._json({"application": app})

        if path == "/api/extension/bootstrap":
            return self._json(self._extension_bootstrap(query))

        if path == "/api/tips":
            return self._json({"tips": tailor.PLATFORM_TIPS})

        if path == "/api/backup":
            return self._backup()

        if path == "/api/stats":
            return self._json(self._stats())

        raise ApiError("接口不存在：%s" % path, 404)

    # ---------- 业务 ----------
    def _state(self):
        state = store.full_state()
        profile = state.get("profile") or {}
        if profile.get("materials"):
            profile = dict(profile)
            profile["materials"] = [
                {k: v for k, v in m.items() if k != "text"} for m in profile["materials"]
            ]
            state["profile"] = profile
        state["stats"] = self._stats()
        state["tips"] = tailor.PLATFORM_TIPS
        state["paths"] = {
            "data": config.DATA_DIR,
            "output": config.OUT_DIR,
            "extension": os.path.join(config.BASE_DIR, "extension"),
        }
        return state

    def _stats(self):
        jobs = store.list_jobs()
        apps = store.list_applications()
        runs = store.list_runs(limit=200)
        scores = [r["score"] for r in runs if r.get("score")]
        status_count = {}
        for a in apps:
            status_count[a.get("status") or "已投递"] = status_count.get(a.get("status") or "已投递", 0) + 1
        return {
            "jobs": len(jobs),
            "applications": len(apps),
            "avg_score": round(sum(scores) / len(scores), 1) if scores else 0,
            "status_count": status_count,
            "runs": len(runs),
        }

    def _import_profile(self, settings):
        data = self._body()
        b64 = data.get("data_b64") or ""
        filename = data.get("filename") or "resume.docx"
        if not b64:
            raise ApiError("没有收到文件内容")
        try:
            raw = base64.b64decode(b64.split(",")[-1])
        except Exception:
            raise ApiError("文件解码失败")
        if len(raw) > MAX_BODY:
            raise ApiError("文件太大")
        config.ensure_dirs()
        stamp = time.strftime("%Y%m%d-%H%M%S")
        safe = docx_io.safe_filename(os.path.splitext(filename)[0], "resume")
        path = os.path.join(config.UP_DIR, f"{stamp}-{safe}.docx")
        with open(path, "wb") as f:
            f.write(raw)
        try:
            blocks = docx_io.read_docx(path)
        except Exception as e:
            raise ApiError("这个 docx 读不出来：%s（如果是旧版 .doc，请先另存为 .docx）" % e)
        profile = docx_io.parse_resume(blocks)
        profile["source_file"] = os.path.basename(path)
        old = store.get_profile() or {}
        profile["id"] = old.get("id") or store.new_id("p_")
        # 素材库（课程/实验）独立于简历正文，导入新简历不能把它清掉
        if old.get("materials"):
            profile["materials"] = old["materials"]
        if old.get("courses"):
            profile["courses"] = old["courses"]

        mode = data.get("mode") or "heuristic"
        if mode == "llm" and settings.get("api_key") and not settings.get("mock"):
            try:
                enriched = tailor.structure_profile(profile.get("raw_text", ""), settings)
                profile = _merge_profile(profile, enriched)
            except (tailor.TailorError, llm.LLMError) as e:
                profile["import_warning"] = "智能解析失败，已用规则解析：%s" % e
        profile["gaps"] = docx_io.detect_gaps(profile)
        saved = store.save_profile(profile)
        return {
            "profile": saved,
            "preview": {"paragraphs": len(blocks["paragraphs"]), "tables": len(blocks["tables"]),
                        "chars": len(blocks["raw_text"])},
        }

    def _tailor(self, job_id, settings):
        job = store.get_job(job_id)
        if not job:
            raise ApiError("岗位不存在", 404)
        profile = store.get_profile()
        if not profile:
            raise ApiError("请先在「档案」页导入或填写简历")
        if not (job.get("jd_text") or "").strip():
            raise ApiError("这个岗位还没有 JD 文本")
        data = {}
        try:
            data = self._body()
        except ApiError:
            data = {}
        options = {
            "focus": data.get("focus") or "",
            "density": data.get("density") or "normal",
            "max_bullets": data.get("max_bullets") or 4,
        }
        if data.get("force_offline"):
            settings = dict(settings, mock=True)
        rid = store.new_id("r_")
        name = docx_io.safe_filename(
            f"{profile.get('name', '简历')}-{(job.get('title') or '岗位')}-{(job.get('company') or '')}-{time.strftime('%m%d')}",
            "resume")
        out_path = os.path.join(config.OUT_DIR, f"{name}-{rid}.docx")
        try:
            payload = tailor.build(profile, job, settings, options, out_path)
        except tailor.TailorError as e:
            raise ApiError(str(e), 502)
        if payload.get("llm_error") and settings.get("api_key"):
            # 记下「Key 不好用」，界面上不再假装是大模型改写模式
            try:
                config.save_settings({"key_ok": False})
            except Exception:
                pass
        payload["run_id"] = rid
        if data.get("save_jd_parse", True) and payload.get("jd"):
            store.update_job(job_id, {"parsed": payload["jd"]})
        store.create_run(job_id, profile.get("id"), payload, payload["score"]["total"], out_path, run_id=rid)
        return {"run_id": rid, "payload": payload, "docx_url": f"/api/runs/{rid}/download"}

    def _export_run(self, run_id, settings):
        run = store.get_run(run_id)
        if not run:
            raise ApiError("定制记录不存在", 404)
        payload = run["payload"]
        profile = store.get_profile()
        if not profile:
            raise ApiError("档案不存在", 404)
        density = (self._body() or {}).get("density") or "normal"
        name = docx_io.safe_filename(
            f"{profile.get('name', '简历')}-{payload.get('job', {}).get('title', '岗位')}-"
            f"{payload.get('job', {}).get('company', '')}-{time.strftime('%m%d')}", "resume")
        out_path = os.path.join(config.OUT_DIR, f"{name}-{run_id}-{density}.docx")
        info = docx_io.render_docx(profile, payload["resume"], out_path, density)
        payload["docx"] = info
        store.update_run_docx(run_id, out_path, payload, payload.get("score", {}).get("total"))
        return {"docx": info, "docx_url": f"/api/runs/{run_id}/download"}

    def _update_run(self, run_id):
        run = store.get_run(run_id)
        if not run:
            raise ApiError("定制记录不存在", 404)
        profile = store.get_profile()
        if not profile:
            raise ApiError("档案不存在", 404)
        data = self._body()
        resume = data.get("resume")
        if not isinstance(resume, dict):
            raise ApiError("缺少简历内容")
        payload = run["payload"]
        payload["resume"] = tailor.normalize_resume(resume, profile)
        payload["warnings"] = tailor.guard(profile, payload["resume"], payload.get("jd"))
        payload["score"] = tailor.score_resume(profile, payload["resume"], payload.get("jd") or {}, payload["warnings"])
        density = (payload.get("options") or {}).get("density", "normal")
        info = docx_io.render_docx(profile, payload["resume"], run["docx_path"], density)
        payload["docx"] = info
        store.update_run_docx(run_id, run["docx_path"], payload, payload["score"]["total"])
        return {"run_id": run_id, "payload": payload}

    def _extension_bootstrap(self, query):
        job_id = (query.get("job_id") or [""])[0]
        profile = store.get_profile()
        jobs = store.list_jobs()
        job = store.get_job(job_id) if job_id else (jobs[0] if jobs else None)
        run = None
        if job:
            runs = store.list_runs(job["id"], limit=1)
            if runs:
                run = store.get_run(runs[0]["id"])
        fields = []
        greeting = ""
        resume_url = ""
        title = ""
        if profile:
            payload = (run or {}).get("payload") or {}
            pack = tailor.pack(profile, job or {}, payload)
            fields = pack["fields"]
            greeting = pack["greeting"]
            if run and run.get("docx_path"):
                host = self.headers.get("Host") or f"127.0.0.1:{config.load_settings().get('port')}"
                resume_url = f"http://{host}/api/runs/{run['id']}/download"
        if job:
            title = job.get("title") or ""
        return {
            "ok": True,
            "app": config.APP_NAME,
            "job": {"id": (job or {}).get("id", ""), "title": title,
                    "company": (job or {}).get("company", ""), "url": (job or {}).get("url", "")},
            "jobs": [{"id": j["id"], "title": j.get("title", ""), "company": j.get("company", "")} for j in jobs[:30]],
            "fields": fields,
            "greeting": greeting,
            "resume_url": resume_url,
            "profile": {
                "name": (profile or {}).get("name", ""),
                "phone": (profile or {}).get("phone", ""),
                "email": (profile or {}).get("email", ""),
            } if profile else None,
        }

    def _backup(self):
        data = {
            "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "app": config.APP_NAME,
            "profile": store.get_profile(),
            "jobs": store.list_jobs(),
            "applications": store.list_applications(),
            "runs": [],
        }
        for r in store.list_runs(limit=500):
            full = store.get_run(r["id"])
            if full:
                data["runs"].append({"id": full["id"], "job_id": full["job_id"], "created_at": full["created_at"],
                                     "payload": full["payload"]})
        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        name = f"jobfit-backup-{time.strftime('%Y%m%d')}.json"
        self._send(200, body, "application/json; charset=utf-8",
                   {"Content-Disposition": _download_name(name)})

    # ---------- 静态文件 ----------
    def _serve_static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        rel = path.lstrip("/")
        full = os.path.abspath(os.path.join(config.WEB_DIR, rel))
        if not full.startswith(os.path.abspath(config.WEB_DIR) + os.sep) and full != os.path.abspath(config.WEB_DIR):
            raise ApiError("非法路径", 403)
        if not os.path.isfile(full):
            raise ApiError("页面不存在", 404)
        with open(full, "rb") as f:
            body = f.read()
        ctype = MIME.get(os.path.splitext(full)[1].lower(), "application/octet-stream")
        self._send(200, body, ctype, {"Cache-Control": "no-store"})

    def _serve_output(self, name):
        name = os.path.basename(name)
        full = os.path.join(config.OUT_DIR, name)
        if not os.path.exists(full):
            raise ApiError("文件不存在", 404)
        self._serve_file(full, download_name=name)

    def _serve_file(self, full, download_name=None):
        if not os.path.exists(full):
            raise ApiError("文件不存在", 404)
        with open(full, "rb") as f:
            body = f.read()
        extra = {}
        if download_name:
            extra["Content-Disposition"] = _download_name(download_name)
        self._send(200, body, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", extra)


def _merge_profile(base, extra):
    """用模型结果覆盖规则解析结果（只覆盖非空字段）。"""
    merged = dict(base)
    for key in ("name", "headline", "phone", "email", "location", "objective", "graduation", "self_eval"):
        val = extra.get(key)
        if isinstance(val, str) and val.strip() and not merged.get(key):
            merged[key] = val.strip()
    for key in ("education", "skills", "internships", "projects", "campus", "awards", "certificates"):
        val = extra.get(key)
        if isinstance(val, list) and val:
            merged[key] = val
    return merged


def _port_free(port):
    """真的去连一下：能连上说明有服务在听，别用它。"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.25)
        if s.connect_ex(("127.0.0.1", int(port))) == 0:
            return False
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", int(port)))
        return True
    except OSError:
        return False


def _pick_port(preferred):
    for port in range(int(preferred), int(preferred) + 30):
        if _port_free(port):
            return port
    return int(preferred)


def main():
    config.ensure_dirs()
    try:
        # 控制台是 GBK 时保留原编码（中文才不乱码），只避免不可编码字符导致崩溃
        sys.stdout.reconfigure(errors="replace")
        sys.stderr.reconfigure(errors="replace")
    except Exception:
        pass
    store.init()
    settings = config.load_settings()
    port = _pick_port(settings.get("port") or config.DEFAULT_PORT)
    if port != settings.get("port"):
        config.save_settings({"port": port})
    server = QuietServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    url = f"http://127.0.0.1:{port}/"
    banner = f"""
  {config.APP_NAME} v{config.VERSION}
  地址：{url}
  数据：{config.DATA_DIR}
  模式：{'离线（规则版）' if (settings.get('mock') or not settings.get('api_key')) else '大模型改写（%s）' % settings.get('model')}
  按 Ctrl+C 退出
"""
    print(banner, flush=True)
    if not os.environ.get("JOBFIT_NO_BROWSER"):
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出。")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()