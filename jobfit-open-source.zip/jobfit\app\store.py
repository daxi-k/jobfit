# -*- coding: utf-8 -*-
"""SQLite 存储层：档案、岗位、定制记录、投递流水。"""
import json
import os
import sqlite3
import threading
import time
import uuid

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS profile (
  id TEXT PRIMARY KEY,
  json TEXT NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  title TEXT,
  company TEXT,
  url TEXT,
  source TEXT,
  jd_text TEXT,
  parsed_json TEXT,
  status TEXT DEFAULT '待投',
  created_at REAL,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY,
  job_id TEXT,
  profile_id TEXT,
  json TEXT,
  score REAL,
  docx_path TEXT,
  created_at REAL
);
CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  job_id TEXT,
  run_id TEXT,
  status TEXT,
  applied_at TEXT,
  note TEXT,
  events TEXT,
  updated_at REAL
);
CREATE TABLE IF NOT EXISTS practice (
  id TEXT PRIMARY KEY,
  job_id TEXT,
  requirement TEXT,
  kind TEXT,
  plan_json TEXT,
  status TEXT DEFAULT 'planned',
  evidence TEXT,
  period TEXT,
  created_at REAL,
  done_at REAL
);
CREATE INDEX IF NOT EXISTS idx_runs_job ON runs(job_id, created_at);
CREATE INDEX IF NOT EXISTS idx_apps_job ON applications(job_id);
CREATE INDEX IF NOT EXISTS idx_practice_job ON practice(job_id, created_at);
"""

_lock = threading.Lock()


def _conn():
    config.ensure_dirs()
    conn = sqlite3.connect(config.DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init():
    with _lock, _conn() as conn:
        conn.executescript(SCHEMA)


def _now():
    return time.time()


def new_id(prefix=""):
    return f"{prefix}{uuid.uuid4().hex[:12]}"


# ---------- 档案 ----------

def get_profile():
    with _conn() as conn:
        row = conn.execute("SELECT id, json, updated_at FROM profile ORDER BY updated_at DESC LIMIT 1").fetchone()
    if not row:
        return None
    data = json.loads(row["json"])
    data.setdefault("id", row["id"])
    data["updated_at"] = row["updated_at"]
    return data


def save_profile(profile):
    pid = profile.get("id") or new_id("p_")
    profile["id"] = pid
    payload = json.dumps(profile, ensure_ascii=False)
    with _lock, _conn() as conn:
        conn.execute(
            "INSERT INTO profile (id, json, updated_at) VALUES (?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET json=excluded.json, updated_at=excluded.updated_at",
            (pid, payload, _now()),
        )
    return profile


# ---------- 岗位 ----------

def _job_row(row):
    if not row:
        return None
    d = dict(row)
    d["parsed"] = json.loads(d.pop("parsed_json") or "null")
    return d


def list_jobs():
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()
    return [_job_row(r) for r in rows]


def get_job(job_id):
    with _conn() as conn:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    return _job_row(row)


def create_job(data):
    jid = new_id("j_")
    now = _now()
    with _lock, _conn() as conn:
        conn.execute(
            "INSERT INTO jobs (id,title,company,url,source,jd_text,parsed_json,status,created_at,updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (
                jid,
                (data.get("title") or "").strip(),
                (data.get("company") or "").strip(),
                (data.get("url") or "").strip(),
                (data.get("source") or "").strip(),
                data.get("jd_text") or "",
                json.dumps(data.get("parsed"), ensure_ascii=False) if data.get("parsed") else None,
                data.get("status") or "待投",
                now,
                now,
            ),
        )
    return get_job(jid)


def update_job(job_id, patch):
    fields, values = [], []
    for key in ("title", "company", "url", "source", "jd_text", "status"):
        if key in patch:
            fields.append(f"{key}=?")
            values.append(patch[key])
    if "parsed" in patch:
        fields.append("parsed_json=?")
        values.append(json.dumps(patch["parsed"], ensure_ascii=False) if patch["parsed"] else None)
    if not fields:
        return get_job(job_id)
    fields.append("updated_at=?")
    values.append(_now())
    values.append(job_id)
    with _lock, _conn() as conn:
        conn.execute(f"UPDATE jobs SET {', '.join(fields)} WHERE id=?", values)
    return get_job(job_id)


def delete_job(job_id):
    with _lock, _conn() as conn:
        conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
        conn.execute("DELETE FROM runs WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM applications WHERE job_id=?", (job_id,))


# ---------- 定制记录 ----------

def create_run(job_id, profile_id, payload, score, docx_path=None, run_id=None):
    rid = run_id or new_id("r_")
    with _lock, _conn() as conn:
        conn.execute(
            "INSERT INTO runs (id,job_id,profile_id,json,score,docx_path,created_at) VALUES (?,?,?,?,?,?,?)",
            (rid, job_id, profile_id, json.dumps(payload, ensure_ascii=False), float(score or 0), docx_path, _now()),
        )
    return rid


def list_runs(job_id=None, limit=50):
    sql = "SELECT id,job_id,score,docx_path,created_at,json FROM runs"
    args = []
    if job_id:
        sql += " WHERE job_id=?"
        args.append(job_id)
    sql += " ORDER BY created_at DESC LIMIT ?"
    args.append(limit)
    with _conn() as conn:
        rows = conn.execute(sql, args).fetchall()
    out = []
    for r in rows:
        payload = json.loads(r["json"] or "{}")
        out.append({
            "id": r["id"],
            "job_id": r["job_id"],
            "score": r["score"],
            "docx_path": r["docx_path"],
            "created_at": r["created_at"],
            "headline": payload.get("resume", {}).get("headline", ""),
            "mode": payload.get("mode", ""),
            "warnings": len(payload.get("warnings") or []),
        })
    return out


def get_run(run_id):
    with _conn() as conn:
        row = conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["payload"] = json.loads(d.pop("json") or "{}")
    return d


def update_run_docx(run_id, docx_path, payload=None, score=None):
    with _lock, _conn() as conn:
        if payload is not None:
            conn.execute(
                "UPDATE runs SET docx_path=?, json=?, score=? WHERE id=?",
                (docx_path, json.dumps(payload, ensure_ascii=False), float(score or 0), run_id),
            )
        else:
            conn.execute("UPDATE runs SET docx_path=? WHERE id=?", (docx_path, run_id))


# ---------- 投递流水 ----------

def list_applications():
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM applications ORDER BY updated_at DESC").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["events"] = json.loads(d.get("events") or "[]")
        out.append(d)
    return out


def get_application_by_job(job_id):
    with _conn() as conn:
        row = conn.execute("SELECT * FROM applications WHERE job_id=? ORDER BY updated_at DESC LIMIT 1", (job_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["events"] = json.loads(d.get("events") or "[]")
    return d


def upsert_application(job_id, run_id=None, status=None, note=None, applied_at=None):
    now = _now()
    existing = get_application_by_job(job_id)
    status = status or "已投递"
    applied_at = applied_at or time.strftime("%Y-%m-%d", time.localtime(now))
    event = {"at": time.strftime("%Y-%m-%d %H:%M", time.localtime(now)), "status": status}
    if note:
        event["note"] = note
    if existing:
        events = existing["events"] + [event]
        with _lock, _conn() as conn:
            conn.execute(
                "UPDATE applications SET status=?, note=?, events=?, run_id=?, updated_at=? WHERE id=?",
                (status, note if note is not None else existing.get("note"), json.dumps(events, ensure_ascii=False),
                 run_id or existing.get("run_id"), now, existing["id"]),
            )
        with _conn() as conn:
            row = conn.execute("SELECT * FROM applications WHERE id=?", (existing["id"],)).fetchone()
        d = dict(row)
        d["events"] = json.loads(d["events"] or "[]")
        return d
    aid = new_id("a_")
    with _lock, _conn() as conn:
        conn.execute(
            "INSERT INTO applications (id,job_id,run_id,status,applied_at,note,events,updated_at) VALUES (?,?,?,?,?,?,?,?)",
            (aid, job_id, run_id, status, applied_at, note or "", json.dumps([event], ensure_ascii=False), now),
        )
    return get_application_by_job(job_id)


# ---------- 差距补强 ----------

def _practice_row(row):
    if not row:
        return None
    d = dict(row)
    d["plan"] = json.loads(d.pop("plan_json") or "{}")
    return d


def list_practice(job_id=None):
    with _conn() as conn:
        if job_id:
            rows = conn.execute("SELECT * FROM practice WHERE job_id=? ORDER BY created_at DESC", (job_id,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM practice ORDER BY created_at DESC").fetchall()
    return [_practice_row(r) for r in rows]


def get_practice(pid):
    with _conn() as conn:
        row = conn.execute("SELECT * FROM practice WHERE id=?", (pid,)).fetchone()
    return _practice_row(row)


def create_practice(job_id, requirement, kind, plan):
    pid = new_id("pr_")
    with _lock, _conn() as conn:
        conn.execute(
            "INSERT INTO practice (id,job_id,requirement,kind,plan_json,status,created_at) VALUES (?,?,?,?,?,?,?)",
            (pid, job_id, requirement, kind or "", json.dumps(plan, ensure_ascii=False), "planned", _now()),
        )
    return get_practice(pid)


def complete_practice(pid, evidence, period):
    with _lock, _conn() as conn:
        conn.execute(
            "UPDATE practice SET status='done', evidence=?, period=?, done_at=? WHERE id=?",
            (evidence, period, _now(), pid),
        )
    return get_practice(pid)


def delete_practice(pid):
    with _lock, _conn() as conn:
        conn.execute("DELETE FROM practice WHERE id=?", (pid,))


def full_state():
    jobs = list_jobs()
    apps = list_applications()
    return {
        "profile": get_profile(),
        "jobs": jobs,
        "applications": apps,
        "runs": list_runs(limit=60),
        "settings": config.public_settings(),
        "meta": {"app": config.APP_NAME, "version": config.VERSION},
    }