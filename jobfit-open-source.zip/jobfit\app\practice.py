# -*- coding: utf-8 -*-
"""差距补强：把 JD 上「你还缺的那几条」变成能真做出来的小项目。

设计原则：这里只产出**待执行的任务**，不产出虚构经历。
只有当你真的做完、并把成果记录写进来，系统才会把它写进档案。
"""
import json
import re
import time

import llm
import store
import tailor

# 每个模板：关键词触发 → 一个真能做完的练习项目
TEMPLATES = [
    {
        "keys": ["自动化", "测试用例", "pytest", "脚本", "回归"],
        "title": "用 Python 把一组手工测试做成自动化脚本",
        "hours": 10, "level": "入门",
        "tools": ["Python 3", "pytest", "串口助手/开发板（有则用）", "Markdown"],
        "tasks": [
            "挑一个你已有的实验（74LS00 表决电路、FPGA 流水灯都行），把它整理成 10 组「输入 → 期望输出」的表格",
            "写 Python 脚本逐组执行：有板子就走串口，没有就用本地数据源模拟，把实测值落盘成 CSV",
            "用 pytest 组织用例，失败时自动保存日志，统计通过率",
            "生成一份 Markdown 测试报告：用例数、通过率、每个失败项的现象与初步定位",
        ],
        "acceptance": [
            "一条命令跑完全部用例并打印通过率",
            "报告里每组都有输入/期望/实测/结论四列",
            "能讲清至少一个失败用例是怎么定位的",
        ],
        "hint": "用 Python + pytest 把 {n} 组手工测试自动化，输出含通过率与失败定位的测试报告。",
        "why": "JD 要求「测试用例 / 自动化」时，这条能直接证明你会写脚本、会设计用例，而不是只会手工点。",
    },
    {
        "keys": ["fpga", "verilog", "vivado", "rtl", "时序", "数字电路"],
        "title": "在 Vivado 里做一个 UART 收发模块，仿真 + 上板",
        "hours": 16, "level": "中等",
        "tools": ["Vivado", "Artix-7 开发板", "串口助手", "示波器/逻辑分析仪"],
        "tasks": [
            "画状态机：空闲 / 起始位 / 8 位数据 / 停止位，算清波特率分频系数与误差",
            "用 Verilog 写收发模块 + testbench，仿真一帧收发并看波形",
            "加 XDC 引脚约束，综合、布局布线、下载比特流",
            "上板和 PC 串口助手互联，连续收发 100 帧，统计误码",
        ],
        "acceptance": [
            "仿真波形能看到起始位到停止位的完整时序",
            "上板连续 100 帧无错码",
            "能解释波特率误差来自哪里、怎么改善",
        ],
        "hint": "独立完成 UART 收发模块的 RTL 设计、testbench 仿真与上板验证，连续 {n} 帧通信无误码。",
        "why": "JD 写 FPGA / Verilog 时，一个能讲清时序和误差的模块，比十个课程名都有说服力。",
    },
    {
        "keys": ["altium", "原理图", "pcb", "layout", "bom"],
        "title": "用 Altium 画一块最小系统板并跑通 DRC",
        "hours": 20, "level": "中等",
        "tools": ["Altium Designer", "立创商城元件库", "DRC 规则集"],
        "tasks": [
            "选型：MCU + 电源 + 下载口 + 一个外设，列出 BOM 清单",
            "画原理图，核对每个封装与 datahseet 引脚是否一致",
            "两层板布局布线：电源走线加宽、地平面完整、晶振包地",
            "跑 DRC 清零，导出 Gerber 与 BOM，写一页设计说明",
        ],
        "acceptance": [
            "DRC 0 error，BOM 与原理图一一对应",
            "能说明关键走线（电源/晶振/复位）为什么这么走",
            "导出文件能被板厂直接下单",
        ],
        "hint": "用 Altium Designer 完成最小系统板原理图与 2 层 PCB，DRC 零错误并输出 BOM 与 Gerber。",
        "why": "JD 要 Altium / 原理图时，实物板＋DRC 结果是最硬的证据。",
    },
    {
        "keys": ["焊接", "虚焊", "返修", "贴片"],
        "title": "手工焊接一块练习板，并定位两类典型故障",
        "hours": 8, "level": "入门",
        "tools": ["恒温烙铁", "助焊剂/吸锡带", "万用表", "放大镜"],
        "tasks": [
            "练 0402/0603 阻容与 SOP/QFN 封装，各焊 10 个点位",
            "人为制造一处虚焊、一处短路，用目检 + 万用表定位",
            "返修后通电，测关键点电压/通断，记录过程",
            "写成「现象 → 假设 → 测量 → 结论」的排障记录",
        ],
        "acceptance": [
            "返修后电路工作正常",
            "能凭万用表读数区分虚焊与短路",
            "排障记录里每一步都有测量值",
        ],
        "hint": "完成 0402/0603 与 SOP/QFN 器件手工焊接，独立定位并返修虚焊与短路故障各一处。",
        "why": "硬件岗几乎都会问「你焊过什么、怎么找虚焊」，这段经历能撑住追问。",
    },
    {
        "keys": ["示波器", "万用表", "频谱", "信号发生器", "仪器", "测量"],
        "title": "用示波器测 I2C/UART 时序，写一份测量报告",
        "hours": 6, "level": "入门",
        "tools": ["示波器", "逻辑分析仪（有则用）", "开发板"],
        "tasks": [
            "设置触发（边沿/脉宽），把波形稳定在屏幕上",
            "测周期、脉宽、上升沿、占空比，和 datasheet 时序表逐项对照",
            "用协议解码功能读出地址、数据与 ACK",
            "整理成测量报告：参数表 + 波形截图 + 偏差结论",
        ],
        "acceptance": [
            "能读出波特率/器件地址并验证 ACK",
            "报告含至少 4 个时序参数与手册值对比",
            "能说出探头接地不良会带来什么假象",
        ],
        "hint": "用示波器与逻辑分析仪测量并解码 I2C/UART 时序，输出含参数对比表的测量报告。",
        "why": "JD 写「熟悉示波器」时，能报出具体参数和偏差，和只会开机是两回事。",
    },
    {
        "keys": ["stm32", "单片机", "嵌入式", "adc", "dma", "串口"],
        "title": "用 STM32 做一次 ADC + DMA 采集并通过串口上传",
        "hours": 12, "level": "中等",
        "tools": ["STM32 开发板", "CubeIDE/Keil", "串口助手"],
        "tasks": [
            "配置时钟、ADC、DMA、UART，先跑通单次采样",
            "改成定时器触发的连续采样（目标 1kHz），DMA 搬运",
            "定义一帧协议（帧头 + 通道 + 数据 + 校验），串口上传",
            "PC 端收数据画折线，检查有无丢点",
        ],
        "acceptance": [
            "采样率用定时器周期可验证（示波器或计数）",
            "连续 10 秒数据无丢帧、校验全过",
            "能解释 DMA 在这里省掉了什么",
        ],
        "hint": "基于 STM32 完成 ADC + DMA 连续采样与串口协议上传，{n} 秒数据无丢帧。",
        "why": "嵌入式/硬件岗常问「你怎么保证采样不丢点」，这段能答到点上。",
    },
    {
        "keys": ["emc", "滤波", "电源", "去耦", "地平面"],
        "title": "做一次板级地平面与去耦设计自查，出 3 条整改",
        "hours": 8, "level": "进阶",
        "tools": ["你画过的 PCB", "芯片 datasheet", "近场探头（有则用）"],
        "tasks": [
            "沿每条信号追一遍回流路径，标出被割裂的地平面",
            "核对去耦电容位置与容值组合，对照 datasheet 推荐电路",
            "检查接口处滤波与 TVS 是否缺位",
            "输出 3 条可执行整改，并说明预期改善的指标",
        ],
        "acceptance": [
            "指出至少 2 处回流路径问题并画图标出",
            "整改建议具体到器件位号与参数",
            "能解释为什么去耦电容要贴近电源引脚",
        ],
        "hint": "完成板级地平面与去耦设计自查，输出 3 条针对具体位号的整改建议。",
        "why": "EMC 是硬件岗高频问题，能讲清回流与去耦比背名词有用。",
    },
]

GENERIC = {
    "title": "围绕「{req}」做一个可验证的最小项目",
    "hours": 10, "level": "入门",
    "tools": ["你手边已有的开发板/软件", "记录模板（Markdown）"],
    "tasks": [
        "把「{req}」拆成 3 个能独立验证的小目标",
        "先做最小可跑通版本，留下截图或日志",
        "加一个可量化指标（时间、次数、误差），测出来",
        "写一页说明：做了什么、怎么验证、卡在哪、怎么解决",
    ],
    "acceptance": [
        "有一个能给别人演示的产物",
        "有一个可量化的结果数字",
        "能讲清过程中踩的坑",
    ],
    "hint": "围绕 {req} 完成一个最小可验证项目，输出可复现的过程记录与量化结果。",
    "why": "把抽象要求落成一个能演示的东西，面试时才有细节可讲。",
}

PLAN_SYSTEM = """你是硬件/嵌入式方向的实习导师。给学生一个「周末就能做完」的练习项目，用来补上他在某个岗位要求上的缺口。

要求：
- 只使用学生现有条件（学校实验室、自有开发板、免费软件），不要假设公司资源
- 总工时不超过 24 小时，任务 5–8 条，每条一句话、可执行、有明确产物
- 验收标准 3 条，必须可检验（能拿出文件、波形、读数、通过率）
- 绝不虚构学生已经做过的事：这是给他去做的任务，不是给他写的经历
- resume_hint 是「做完之后可以怎么写」的模板，用 {n} 之类占位符，不要写具体假数字
只输出 JSON，字段固定。"""


# 学历/资格类要求不是「能靠做项目补」的缺口
_EDU_RE = re.compile(r"学历|本科|硕士|博士|大专|专科|应届|在校生|毕业生|毕业时间|届|绩点|GPA|四六级|CET|英语四级|英语六级|相关专业|专业背景")


def analyze(profile, jd):
    """列出 JD 要求里档案证据不足的条目。"""
    corpus = tailor._profile_corpus(profile)
    reqs = []
    for m in jd.get("must_have") or []:
        reqs.append((m, "must"))
    for k in (jd.get("keywords") or [])[:10]:
        reqs.append(("关键词：" + k, "keyword"))
    out, seen = [], set()
    for req, kind in reqs:
        req = (req or "").strip()
        if not req:
            continue
        key = re.sub(r"\s+", "", req)[:14]
        if key in seen:
            continue
        seen.add(key)
        bare = req.replace("关键词：", "")
        if len(bare) <= 30 and _EDU_RE.search(bare):
            continue  # 学历/届别这类硬门槛，做项目补不了
        strength = tailor._requirement_strength(bare, corpus)
        out.append({
            "requirement": req,
            "bare": bare,
            "kind": kind,
            "strength": strength,
            "suggest": _template_for(bare).get("title", "").format(req=bare),
        })
    # 缺口优先：none 在前
    order = {"none": 0, "partial": 1, "strong": 2}
    out.sort(key=lambda g: order.get(g["strength"], 3))
    return out


def _hit(text, key):
    """关键词命中：短英文词（dma/adc 之类）按词边界，避免 roadmap 里命中 dma。"""
    low = (text or "").lower()
    k = (key or "").lower()
    if not k:
        return False
    if len(k) <= 4 and re.fullmatch(r"[a-z0-9+#]+", k):
        return re.search(r"(?<![a-z0-9])" + re.escape(k) + r"(?![a-z0-9])", low) is not None
    return k in low


def _template_for(text):
    for tpl in TEMPLATES:
        if any(_hit(text, k) for k in tpl["keys"]):
            return tpl
    return GENERIC


def plan_for(requirement, profile, jd, settings):
    """生成一个练习项目；大模型失败时用模板兜底。"""
    tpl = _template_for(requirement)
    plan = {
        "title": tpl["title"].format(req=requirement),
        "hours": tpl["hours"],
        "level": tpl["level"],
        "tools": list(tpl["tools"]),
        "tasks": [t.format(req=requirement) for t in tpl["tasks"]],
        "acceptance": [a.format(req=requirement) for a in tpl["acceptance"]],
        "hint": tpl["hint"].format(n="N", req=requirement),
        "why": tpl["why"],
        "source": "template",
    }
    if settings.get("mock") or not settings.get("api_key"):
        return plan
    try:
        user = json.dumps({
            "岗位": jd.get("title"),
            "公司": jd.get("company"),
            "缺口": requirement,
            "候选人现有条件": {
                "专业": (profile.get("education") or [{}])[0].get("major", ""),
                "技能": [s.get("label", "") for s in profile.get("skills") or []],
                "项目": [p.get("title", "") for p in profile.get("projects") or []],
                "素材": [m.get("title", "") for m in profile.get("materials") or []],
            },
            "参考模板": plan,
        }, ensure_ascii=False)
        content = llm.chat(
            [{"role": "system", "content": PLAN_SYSTEM},
             {"role": "user", "content": user + "\n\n输出 JSON：{title,hours,level,tools[],tasks[],acceptance[],hint,why}"}],
            settings, json_mode=True, max_tokens=900, temperature=0.5,
        )
        data = llm.parse_json_reply(content)
        got = {
            "title": str(data.get("title") or plan["title"])[:60],
            "hours": int(data.get("hours") or plan["hours"]),
            "level": str(data.get("level") or plan["level"]),
            "tools": [str(t)[:30] for t in (data.get("tools") or plan["tools"])][:6],
            "tasks": [str(t)[:120] for t in (data.get("tasks") or plan["tasks"])][:8],
            "acceptance": [str(a)[:100] for a in (data.get("acceptance") or plan["acceptance"])][:4],
            "hint": str(data.get("hint") or plan["hint"])[:120],
            "why": str(data.get("why") or plan["why"])[:200],
            "source": "llm",
        }
        if len(got["tasks"]) >= 3 and len(got["acceptance"]) >= 2:
            return got
    except Exception:
        pass
    return plan


def start(job_id, requirement, kind, profile, jd, settings):
    """生成并保存一份练习计划（同岗位同要求去重）。"""
    for p in store.list_practice(job_id):
        if p["requirement"] == requirement and p["status"] == "planned":
            return p, False
    plan = plan_for(requirement, profile, jd, settings)
    return store.create_practice(job_id, requirement, kind, plan), True


def complete(pid, evidence, period, profile):
    """做完之后写回档案：必须提供成果记录，这是唯一的真实性闸门。"""
    p = store.get_practice(pid)
    if not p:
        raise ValueError("这份练习计划不存在")
    if p["status"] == "done":
        raise ValueError("这份已经写进档案了")
    evidence = (evidence or "").strip()
    if len(evidence) < 20:
        raise ValueError("先写清楚你实际做了什么（至少 20 字），再写入档案")
    lines = []
    for raw in re.split(r"[\n；;]+", evidence):
        line = raw.strip(" -•·\t")
        if len(line) >= 8:
            lines.append(line[:90])
    if not lines:
        raise ValueError("成果记录太短，写具体一点：做了什么、测到什么数、结果如何")
    period = (period or "").strip() or time.strftime("%Y.%m")
    entry = {
        "title": p["plan"].get("title") or p["requirement"],
        "role": "独立完成",
        "period": period,
        "bullets": lines[:3],
        "source": "practice",
        "practice_id": p["id"],
    }
    profile = dict(profile or {})
    projects = list(profile.get("projects") or [])
    projects.insert(0, entry)
    profile["projects"] = projects[:8]
    store.save_profile(profile)
    store.complete_practice(pid, evidence, period)
    return entry