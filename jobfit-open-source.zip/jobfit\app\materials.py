# -*- coding: utf-8 -*-
"""课程清单 / 实验报告素材：解析、打标签、按岗位挑选并注入简历。

素材来自用户自己上传的内容（实验报告正文、课程名单），
所以它们和档案一样属于「可引用的事实」，可以进入简历，也可以进入防编造校验的语料。
"""
import re
import uuid

import llm


COURSE_SPLIT = re.compile(r"[、，,；;/\n\r\t]+|(?<=[。])|(?<=\s)(?=\d{1,2}\s*[.、)）])")
NUM_PREFIX = re.compile(r"^\s*(?:\d{1,2}|[一二三四五六七八九十]{1,3})\s*[.、)）]\s*")
TOOL_HINTS = (
    "示波器", "万用表", "信号发生器", "频谱仪", "直流电源", "逻辑分析仪", "烙铁", "热风枪",
    "Multisim", "Proteus", "LTspice", "PSpice", "Altium", "AD", "Cadence", "Keil", "Quartus",
    "Vivado", "ModelSim", "MATLAB", "Simulink", "Python", "C语言", "STM32", "51单片机", "Arduino",
    "FPGA", "Verilog", "VHDL", "PCB", "焊接", "面包板", "仿真",
)
RESULT_HINTS = ("测得", "实测", "误差", "一致", "符合", "通过", "成功", "达到", "验证", "结果为", "提升了")
ACTION_HINTS = ("搭建", "设计", "完成", "测试", "调试", "测量", "分析", "实现", "验证", "仿真", "焊接", "编写")
STOP_HEAD = ("实验目的", "实验原理", "实验器材", "实验步骤", "实验内容", "实验过程", "数据处理",
             "实验结果", "结论", "一、", "二、", "三、", "四、", "五、", "摘要")


def _clean(text):
    text = (text or "").replace("\u3000", " ")
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def split_courses(text):
    """把「课程名单」拆成干净的课程名列表。"""
    out = []
    for raw in COURSE_SPLIT.split(_clean(text)):
        name = NUM_PREFIX.sub("", (raw or "").strip())
        name = name.strip(" 　·-—*#：:。.、,，;；")
        if not (2 <= len(name) <= 26):
            continue
        if not re.search(r"[\u4e00-\u9fa5A-Za-z]", name):
            continue
        if name in out:
            continue
        out.append(name)
    return out[:40]


def lab_title(text, hint=""):
    if hint and hint.strip():
        return hint.strip()[:40]
    for line in _clean(text).splitlines():
        line = NUM_PREFIX.sub("", line.strip(" #·-—*"))
        if 4 <= len(line) <= 40 and not any(line.startswith(h) for h in STOP_HEAD):
            return line
    return "实验报告"


def tags_of(text, limit=8):
    from tailor import KEYWORD_LEXICON, _contains
    low = (text or "").lower()
    found = []
    for kw in sorted(KEYWORD_LEXICON, key=lambda x: -len(x)):
        if _contains(low, kw) and kw.lower() not in [f.lower() for f in found]:
            found.append(kw)
    return found[:limit]


def _sentences(text):
    out = []
    for line in _clean(text).splitlines():
        line = _strip_label(line.strip(" 　"))
        if not line:
            continue
        for part in re.split(r"(?<=[。！？!?；;])", line):
            part = _strip_label(part.strip(" 　，,。.；;"))
            if part:
                out.append(part)
    return out


LABEL_RE = re.compile(r"^\s*(?:[一二三四五六七八九十]{1,3}|\d{1,2})\s*[、.．)）]\s*[^：:]{0,10}[：:]\s*")


def _strip_label(text):
    text = LABEL_RE.sub("", text or "")
    text = re.sub(r"^(?:实验目的|实验原理|实验器材|实验步骤|实验内容|实验结果|数据处理|结论|分析)\s*[：:]\s*", "", text)
    return text.strip()


CHIP_RE = re.compile(r"\b\d{2}[A-Z]{2,}\d{2,}[A-Z]*\b")
PURPOSE_HINTS = ("掌握", "熟悉", "了解", "学会", "认识", "培养")


def _score_sentence(s):
    tools = sum(1 for t in TOOL_HINTS if t.lower() in s.lower())
    if CHIP_RE.search(s):
        tools += 1
    result = sum(1 for h in RESULT_HINTS if h in s)
    method = sum(1 for m in ("测量", "测试", "调试", "搭建", "仿真", "焊接", "编程") if m in s)
    digits = len(re.findall(r"\d", s))
    lists = len(re.findall(r"[、,]", s))
    score = tools * 2 + result * 3 + method * 2 + (1 if digits else 0)
    if 10 <= len(s) <= 60:
        score += 1
    if lists >= 3:  # 器材清单，信息密度低
        score -= 3
    if any(s.startswith(h) for h in ("电路工作正常", "实验完成", "通过本次", "综上")):
        score -= 2
    if any(h in s[:6] for h in PURPOSE_HINTS):  # 学习目标不是证据
        score -= 6
    return score


def _trim_sentence(s, limit=58):
    s = s.strip(" 　，,。；;·-—")
    s = re.sub(r"^(?:我们|本人|本次实验|本实验|实验中)[，,]?\s*", "", s)
    if len(s) > limit:
        cut = max(s.rfind("，", 0, limit), s.rfind("、", 0, limit), s.rfind(" ", 0, limit))
        s = s[: cut if cut >= limit * 0.6 else limit].rstrip("，,、 ")
    return s + "。" if s and not s.endswith(("。", "！", "？", "；")) else s


def parse_lab(text, settings=None, hint=""):
    """一份实验报告 → {title, bullets, tags, text}。有可用 Key 时交给模型压缩。"""
    text = _clean(text)
    if not text:
        raise ValueError("实验报告内容是空的")
    title = lab_title(text, hint)
    if settings and settings.get("api_key") and not settings.get("mock"):
        try:
            data = _llm_lab(text, title, settings)
            bullets = [_trim_sentence(str(b)) for b in (data.get("bullets") or []) if str(b).strip()][:4]
            if bullets:
                return {"title": str(data.get("title") or title)[:40], "bullets": bullets,
                        "tags": tags_of(text + " " + " ".join(bullets)), "text": text}
        except Exception:
            pass
    bullets = _heuristic_bullets(text, title)
    return {"title": title, "bullets": bullets, "tags": tags_of(text + " " + " ".join(bullets)), "text": text}


def _heuristic_bullets(text, title="", limit=3):
    sentences = _sentences(text)
    title_key = re.sub(r"\s", "", title or "")[:8]
    ranked = sorted(sentences, key=_score_sentence, reverse=True)
    picked, seen = [], ""
    for pool in (ranked, sentences):  # 先挑好句子，不够再从原文补
        for s in pool:
            if len(s) < 8 or len(s) > 120:
                continue
            if title_key and re.sub(r"\s", "", s).startswith(title_key):
                continue  # 标题行本身不是条目
            if len(re.findall(r"[、,]", s)) >= 4 and not any(h in s for h in RESULT_HINTS):
                continue  # 器材清单，写进简历没有信息量
            if s[:10] in seen:
                continue
            picked.append(_trim_sentence(s))
            seen += s[:10]
            if len(picked) >= limit:
                return picked
    return picked


LAB_SYSTEM = (
    "你是电子信息类专业的简历顾问。把用户提供的实验报告压缩成简历条目。"
    "铁律：只能使用原文出现过的事实、工具、器件型号和数字；原文没有的数字、器件、软件一律不许出现；"
    "不要写「实验目的」「实验原理」这类空话，直接写做了什么、用什么做的、结果如何。"
)


def _llm_lab(text, title, settings):
    schema = '{"title": "实验名称，不超过 20 字", "bullets": ["条目1", "条目2", "条目3"]}'
    user = (
        f"实验报告标题（可能是文件名）：{title}\n\n"
        f"报告正文：\n{text[:4000]}\n\n"
        "请输出 2-3 条简历用条目，每条 20-45 字，必须包含可验证的细节（器件型号/工具/参数/结果）。"
        "第一条写做了什么，第二条写怎么测/怎么验，第三条写结果或收获（没有就不写）。"
        f"只输出 JSON：{schema}"
    )
    content = _llm.chat(
        [{"role": "system", "content": LAB_SYSTEM}, {"role": "user", "content": user}],
        settings, json_mode=True, max_tokens=800, temperature=0.3,
    )
    data = _llm.parse_json_reply(content)
    if not isinstance(data, dict):
        raise ValueError("模型返回格式不正确")
    return data


# ---------------------------------------------------------------- 按岗位挑选

def _course_score(course, keywords):
    low = course.lower()
    score = 0
    for kw in keywords:
        k = (kw or "").lower()
        if not k or len(k) < 2:
            continue
        if k in low:
            score += len(k)
    return score


def select_for_jd(profile, jd, limit_labs=2, limit_courses=7):
    """从档案素材里挑与 JD 最相关的课程与实验；没有素材就返回空。"""
    keywords = [k for k in (jd.get("keywords") or []) if k]
    keywords += [m for m in (jd.get("must_have") or []) if m]
    courses = profile.get("courses") or []
    picked_courses = []
    if courses:
        ranked = sorted(courses, key=lambda c: (_course_score(c, keywords), -courses.index(c)), reverse=True)
        head = [c for c in ranked if _course_score(c, keywords) > 0][:limit_courses]
        if len(head) < min(4, len(courses)):
            for c in courses:
                if c not in head:
                    head.append(c)
                if len(head) >= min(limit_courses, 6):
                    break
        picked_courses = [c for c in courses if c in head][:limit_courses]

    mats = [m for m in (profile.get("materials") or []) if m.get("bullets")]
    picked_labs = []
    if mats:
        def score(m):
            blob = (m.get("title", "") + " " + " ".join(m.get("tags") or []) + " "
                    + " ".join(m.get("bullets") or [])).lower()
            return sum(len(k) for k in keywords if len(k) >= 2 and k.lower() in blob)

        ranked = sorted(mats, key=lambda m: (score(m), -(m.get("ts") or 0)), reverse=True)
        picked_labs = [m for m in ranked if score(m) > 0][:limit_labs]
        if not picked_labs:
            picked_labs = ranked[:1]
    labs = [{"title": m.get("title", ""), "course": m.get("course", ""),
             "bullets": list(m.get("bullets") or [])[:3]} for m in picked_labs]
    return picked_courses, labs


def material_corpus(profile):
    """素材原文，供防编造校验当作「事实来源」。"""
    parts = list(profile.get("courses") or [])
    for m in profile.get("materials") or []:
        parts.append(m.get("title", ""))
        parts.append(m.get("course", ""))
        parts.append(m.get("text", ""))
        parts.extend(m.get("bullets") or [])
    return "\n".join(p for p in parts if p)


def new_id(prefix="mat"):
    return f"{prefix}_{uuid.uuid4().hex[:10]}"